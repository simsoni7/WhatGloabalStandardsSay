"""Export default usable reference entries with complete JSONL provenance."""
from pathlib import Path
import csv,hashlib,json,sqlite3,zipfile,collections
ROOT=Path(__file__).resolve().parents[1]
def export():
 p=ROOT/'dist/data';p.mkdir(parents=True,exist_ok=True)
 with sqlite3.connect(ROOT/'datasets/derived/reference_index.sqlite') as db:
  rows=[json.loads(x[0]) for x in db.execute("SELECT payload FROM entries WHERE usable=1 AND source_target IS NOT NULL AND source_target!='' ORDER BY dataset_id,evidence_id")]
  cards=[json.loads(x[0]) for x in db.execute('SELECT payload FROM financial_concepts ORDER BY id')]
 (p/'financial_concepts.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cards))
 (p/'glossary_entries.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 fields=['evidence_id','dataset_id','dataset_version','dataset_state','source_concept_id','source_english','target_language','source_target','alignment_status','alignment_basis','equivalence_status','generation_eligible','approved_translation','integration_issue_ids','jurisdiction','review_status','record_type','category','context_required','source_json','quality_flags_json']
 with (p/'glossary_entries.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:
   s={k:v for k,v in r['source'].items() if isinstance(v,(str,int,float,bool,type(None))) and (not isinstance(v,str) or len(v)<2000)}
   s['full_provenance']='glossary_entries.jsonl#'+r['evidence_id'];o={k:r.get(k,'') for k in fields if not k.endswith('_json')};o['integration_issue_ids']=json.dumps(r.get('integration_issue_ids',[]));o['source_json']=json.dumps(s,ensure_ascii=False);o['quality_flags_json']=json.dumps(r.get('quality_flags',[]),ensure_ascii=False);w.writerow(o)
 c={'format_version':2,'entry_count':len(rows),'counts_by_dataset':dict(collections.Counter(r['dataset_id'] for r in rows)),'counts_by_language':dict(collections.Counter(r['target_language'] for r in rows)),'languages':sorted({r['target_language'] for r in rows}),'nepal_note':f"66 original records plus {sum(r.get('kind')=='financial_form_label' for r in rows)} source-backed bilingual form labels visually checked by AI. Not human-reviewed; originating form context required.",'csv_note':'Compact source locators in CSV; complete provenance in JSONL.','review_note':'Source matches do not establish contextual correctness. Candidate records and AI-assisted checks retain explicit status.','files':{}}
 registry=ROOT/'datasets/language_packs/registry.json'
 if registry.exists():
  c['reference_language_packs']=[]
  c['benchmarks']=[]
  for pack in json.loads(registry.read_text())['packs']:
   if pack['decision'] not in ['accepted_reference','accepted_benchmark']:continue
   manifest=json.loads((ROOT/pack['path']/'manifest.json').read_text())
   if pack['decision']=='accepted_reference':
    c['reference_language_packs'].append({'dataset_id':pack['dataset_id'],'entry_count':manifest['entry_count'],'state':pack['state'],'manifest':manifest})
   else:
    base=(ROOT/pack['path']).resolve()
    if not base.is_relative_to((ROOT/'datasets/language_packs').resolve()):raise ValueError('Benchmark path escapes language packs')
    for name,digest in manifest['files_sha256'].items():
     file=(base/name).resolve()
     if not file.is_relative_to(base) or hashlib.sha256(file.read_bytes()).hexdigest()!=digest:
      raise ValueError('Benchmark artifact checksum or path invalid')
    c['benchmarks'].append({'dataset_id':pack['dataset_id'],'state':pack['state'],'manifest':manifest})
 c['benchmark_note']='Reference terminology is not an independent translation-quality benchmark. No live-model accuracy score is claimed.'
 c['schema_version']=2;c['approved_translation_count']=0
 c['field_rules']='source_english/source_target preserve source observations. Alignment does not establish semantic equivalence; approved_translation is null without explicit review. Missing approvals in CSV are empty cells.'
 c['integration_report']=json.loads((ROOT/'datasets/derived/integration/report.json').read_text())
 c['financial_information_layer']={'candidate_cards':len(cards),'origin':'ai_written_explanations_independently_ai_reviewed','expert_approved':False,'does_not_fill_original_source_definition_coverage':True}
 commercial_policy=ROOT/'datasets/language_packs/commercial_policy.json'
 if commercial_policy.exists():
  c['commercial_use_policy']=json.loads(commercial_policy.read_text())
  c['whole_package_commercial_use_verified']=False
  c['commercial_only_download']='commercial-language-packs.zip'
 for name in ['glossary_entries.csv','glossary_entries.jsonl','financial_concepts.jsonl']:
  b=(p/name).read_bytes();c['files'][name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 (p/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
 with zipfile.ZipFile(ROOT/'dist/glossaries-data.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(p.iterdir()):
   if f.is_file():z.write(f,'glossaries-data/'+f.name)
  for file in (ROOT/'datasets/derived/integration').iterdir():
   if file.is_file():z.write(file,'glossaries-data/integration/'+file.name)
  for file in (ROOT/'datasets/derived/semantic_review').iterdir():
   if file.is_file():z.write(file,'glossaries-data/semantic_review/'+file.name)
  enrichment=ROOT/'datasets/enrichment'
  if enrichment.exists():
   for file in enrichment.rglob('*'):
    if file.is_file():z.write(file,'glossaries-data/enrichment/'+str(file.relative_to(enrichment)))
  if registry.exists():
   for pack in json.loads(registry.read_text())['packs']:
    if pack['decision']=='accepted_reference':
     base=ROOT/pack['path'];manifest=json.loads((base/'manifest.json').read_text())
     for name in ['manifest.json',*manifest['files_sha256']]:
      if name=='evidence.jsonl':continue
      z.write(base/name,'glossaries-data/reference_sources/'+pack['dataset_id']+'/'+name)
     continue
    if pack['decision']!='accepted_benchmark':continue
    base=ROOT/pack['path'];manifest=json.loads((base/'manifest.json').read_text())
    for name in ['manifest.json',*manifest['files_sha256']]:
     z.write(base/name,'glossaries-data/benchmarks/'+pack['dataset_id']+'/'+name)
 with (p/'glossary_entries.csv').open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==len(rows)
 print(json.dumps(c,ensure_ascii=False))
if __name__=='__main__':export()
