"""Probe official Nepal financial institutions, retaining response evidence."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,json,hashlib
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]
P=ROOT/'datasets/nepal_official/candidate';P.mkdir(parents=True,exist_ok=True)
HOSTS=['nabilbank.com','www.nabilbank.com','globalimebank.com','www.globalimebank.com','nimb.com.np','www.nimb.com.np','siddharthabank.com','www.siddharthabank.com','nicasiabank.com','www.nicasiabank.com','rbb.com.np','www.rbb.com.np','adbl.gov.np','www.adbl.gov.np','sebon.gov.np','www.sebon.gov.np','cdsc.com.np','www.cdsc.com.np','nepalstock.com','www.nepalstock.com','nia.gov.np','www.nia.gov.np']
def probe(host):
 f=P/(host+'.html');u='https://'+host+'/'
 r=subprocess.run(['curl','-L','-sS','--max-time','20','--proto','=https','--proto-redir','=https','-o',str(f),'-w','%{http_code}\n%{url_effective}',u],capture_output=True,text=True)
 out={'url':u,'result':r.stdout.strip(),'curl_code':r.returncode,'error':r.stderr.strip()[:300]}
 if r.returncode==0 and r.stdout.startswith('200'):
  out['sha256']=hashlib.sha256(f.read_bytes()).hexdigest();s=BeautifulSoup(f.read_text(errors='replace'),'html.parser');out['title']=s.title.get_text() if s.title else '';out['links']=[{'text':a.get_text(' ',strip=True),'href':a['href']} for a in s.find_all('a',href=True) if any(t in (a['href']+' '+a.get_text()).lower() for t in ['download','form','nepali','नेपाली','gloss','literacy','pdf','language','/ne','/np'])]
 print(host,out['result'].splitlines()[0] if out['result'] else 'failed',flush=True);return out
with ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(probe,HOSTS))
(P/'probe.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print('Probe finished',flush=True)
