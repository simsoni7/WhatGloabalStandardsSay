# cfpd용어집 v1

실행 가능한 **용어 조회·원문 용어 번역·출처 비교 API**를 추가했습니다. [실행 방법과 정확한 완성 범위](RUN.md)를 먼저 확인하세요. 자유 문장 생성·문맥 검수의 모델 어댑터는 구현했지만, 실제 모델은 연결되지 않아 이 기능의 실사용 검증은 아직 완료하지 못했습니다.

후속 작업에서 몽골어 숫자 항목 1개를 보완해 **3,644개**가 됐습니다. 네팔어 실패 페이지는 영어판과 네팔어판의 응답 차이로 원인을 좁혔습니다. 별도 품질 검토 목록과 용어집 간 영어 표기 연결 후보를 만들었으며, [현재 진행 상황과 다음 계획](docs/next-plan.md)에 순서와 완료 기준을 정리했습니다.

확장 수집 결과: 몽골은행 **영어–몽골어 3,643개 항목과 정의**, 네팔은행 **127개 페이지쌍에서 용어·표현 후보 107쌍 및 문장·목록 용례 후보 110쌍**을 별도 DB로 확보했습니다. [확장 수집 결과와 조회 방법](docs/expanded-collection.md)을 참고하세요. 두 데이터셋은 검수 전 후보이며, 아래의 cfpd 고정 버전과 분리합니다.

사용자 지정 이름은 **cfpd용어집**, 원본 기관명은 **CFPB**입니다. 현재 5개 언어 데이터를 `datasets/cfpd/v1/`에 고정했습니다. 이 버전은 추가·수정하지 않고, 향후 변경은 새 후보 버전으로 만듭니다. 고정은 데이터 버전의 확정이며 언어 검수 완료를 뜻하지 않습니다.

- 정식 DB: `datasets/cfpd/v1/glossary.sqlite`
- 고정 내역과 파일 해시: `datasets/cfpd/v1/manifest.json`
- AI 공통 근거 형식: `datasets/cfpd/v1/evidence.jsonl`
- 용어집 목록: `datasets/registry.json`
- 다음 후보: 몽골은행 영어–몽골어 용어집, 현재 미수집

검색 도구는 고정 버전을 읽습니다. 기존 `data/` 출력도 호환용으로 보존하며 재생성 덮어쓰기를 차단했습니다. 모든 파일을 운영체제 수준으로 쓰기 불가능하게 만든 것은 아니므로, 해시 확인으로 임의 변경을 탐지합니다.

```bash
python3 scripts/reference_glossaries.py --verify
python3 scripts/reference_glossaries.py 'Credit score' --language ko --dataset cfpd
python3 scripts/reference_glossaries.py 'Credit score' --language mn
```

몽골어 요청은 아직 목표 언어 근거 없음으로 반환하며, 미수집 후보는 근거로 사용하지 않습니다. [용어집 등록과 몽골은행 수집 계획](docs/glossary-registry.md)을 참고하세요.

웹 후보 수집은 API 키가 필요 없는 [무료 Playwright 수집](docs/playwright-collection.md)을 사용합니다. `python3 scripts/collect_playwright.py all`로 두 사이트를 시도하며 성공·실패 기록을 후보 폴더에 보존합니다. 현재 실제 사이트 수집은 인증서 검증 오류로 실패했습니다.

**2026-10-12 업데이트:** 인증서 검증이 정상인 apex 주소와 사이트의 언어 전환 세션을 이용한 [무료 자동수집 경로](docs/public-collection.md)를 확인했습니다. `python3 scripts/collect_public_glossaries.py nepalbank`로 영어–네팔어 후보 9쌍을 재수집할 수 있습니다. 몽골 사이트의 화면은 수집되지만 공개 용어 API는 내부 오류를 반환합니다. Playwright 오류와 별개로 HTTPS 원문 수집은 가능하므로 두 사이트 전체가 수집 불가한 것은 아닙니다.

사용자가 제공한 CFPB **2024년 3월판** PDF 다섯 개에서 추출한 영어–중국어 번체(`zh-Hant`)·스페인어(`es`)·한국어(`ko`)·베트남어(`vi`)·러시아어(`ru`) 용어집입니다.

- 영어 용어 **2,018개**, 출처 항목 **10,090개**, 실제 번역 **10,089개**
- 한국어 `Ghost mortgage, silent second mortgage`는 원본 PDF 36페이지의 번역 칸이 비어 있습니다. `translation=NULL`, `availability='missing_in_source'`로 보존하며 임의 번역하지 않습니다.
- `data/glossary.sqlite`: 바로 조회할 수 있는 SQLite DB
- `data/glossary.csv`: UTF-8 BOM CSV, 영어–언어별 번역을 한 행씩 제공
- `data/glossary.json`: 같은 데이터의 JSON
- `data/validation.json`: 페이지별 추출 수, 페이지 연결, 무결성 검사 결과
- `data/sources/`: 제공받은 원본 PDF. DB에 파일명, SHA-256, 발행월을 기록

## 데이터 구조

`terms`는 영어 표기를 저장하고, `translations`는 언어별 번역과 원문 텍스트·출처·페이지를 저장합니다. `sources`는 문서 정보를, `languages`는 언어 코드를 관리합니다. 조회용 `glossary_pairs` 뷰로 이 정보를 함께 읽을 수 있습니다. 한 용어·언어에 여러 출처나 번역을 추가할 수 있습니다.

영어 키는 NFC, 공백, 대소문자만 정규화합니다. 줄 끝 하이픈 뒤의 줄바꿈은 연결하되 하이픈은 보존합니다. 의미가 비슷한 다른 영어 표기를 임의로 합치지 않습니다. 동일 영어 표기를 연결한 것이므로, 별도의 의미별 개념 체계가 필요하면 나중에 `concepts`를 추가할 수 있습니다.

복수 번역, 품사, `(depending on context)` 같은 주석은 원문과 함께 보존합니다. 쉼표를 기준으로 번역을 임의로 나누지 않습니다. `english_raw`, `translation_raw`에는 추출한 줄바꿈도 유지하며, PDF가 최종 원본입니다. `pdf_page_*`는 표지 포함 1부터 시작하는 PDF 페이지, `printed_page_*`는 문서에 인쇄된 페이지입니다.

## 사용

기존 `/workspace/WhatGloabalStandardsSay` 체크아웃에서 작업합니다. 클라우드 작업 자체가 격리되어 있으므로 별도 Git worktree는 필요하지 않습니다. Python 3.12에서 검증했습니다. SQLite 조회는 Python 표준 라이브러리만 사용하며 별도 DB 서버나 인증 정보가 필요하지 않습니다.

```bash
cd /workspace/WhatGloabalStandardsSay
python3 scripts/search_glossary.py 'Credit score'
python3 scripts/search_glossary.py 'hipoteca' --language es --limit 10
python3 scripts/search_glossary.py '信用' --language zh-Hant
python3 scripts/search_glossary.py '신용' --language ko
python3 scripts/search_glossary.py 'tín dụng' --language vi
python3 scripts/search_glossary.py 'Кредит' --language ru
```

현재 검색은 부분 문자열 검색입니다. SQLite 기본 LIKE의 대소문자 무시는 ASCII 기준이며, 스페인어 악센트 제거 및 중국어 형태소 검색은 구현하지 않았습니다.

SQL 예시:

```sql
SELECT english, language_code, translation, source_filename,
       pdf_page_start, pdf_page_end
FROM glossary_pairs
WHERE english = 'Credit score';
```

## 재생성 및 검증

```bash
cd /workspace/WhatGloabalStandardsSay
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/build_glossary.py --output-dir /tmp/cfpd-rebuild-check
```

기존 출력 DB/CSV/JSON/검증 보고서를 다시 생성합니다. 원본 PDF는 변경하지 않습니다. 다른 위치에서 검증하려면 `--output-dir /tmp/cfpb-check`를 사용할 수 있습니다. 추출기는 이 다섯 판본의 표 좌표에 맞춰져 있어 다른 언어·판본에 바로 적용하면 안 됩니다. 재생성은 수동 검수 상태와 번역 편집도 초기화하므로, 편집한 DB를 먼저 보존해야 합니다. 향후 운영 DB에서는 원본 수집과 수동 검수를 별도 계층으로 관리해야 합니다.

검증은 표의 모든 텍스트가 행에 배정됐는지, 다섯 언어가 각 2,018행인지, 모든 영어 용어에 다섯 언어의 출처 항목이 연결됐는지, SQLite 무결성과 외래 키, 여러 줄·마지막 페이지·페이지 연결·원본 누락 사례를 확인합니다. 중국어 `Undocumented`는 PDF 77–78페이지, 러시아어 `Property inspection`은 61–62페이지, `Uniformed and Overseas Citizens Absentee Voting Act (UOCAVA)`는 78–79페이지에 걸쳐 있어 연결했습니다. CSV의 빈 번역은 `availability`로 원본 누락인지 식별할 수 있습니다.

```bash
python3 -m unittest discover -s tests -v
```

## 웹 표현 확인과 자동 생성에 활용

DB는 **출처가 있는 용어 근거**를 제공합니다. 일치 여부만으로 문장의 자연스러움, 문맥 적합성, 제도적 의미를 판정할 수는 없습니다. 이 자료는 미국 CFPB의 소비자 교육 번역 자료이므로, 사용 국가·금융상품·독자·표시 위치를 함께 판단해야 합니다.

`scripts/prepare_expression.py`는 영어 용어와 목표 언어로 근거를 찾고, 확인할 표현·상황을 포함한 JSON을 만듭니다. 입력은 구체적인 영어 용어가 필요하며 문장 전체에서 용어를 자동 식별하는 기능은 아직 없습니다.

```bash
python3 scripts/prepare_expression.py 'Credit score' --language ko \
  --expression '신용 점수' --context '미국 소비자 대상 대출 신청 화면의 항목명'
python3 scripts/prepare_expression.py 'Ability to repay' --language vi \
  --context '미국 소비자 대상 대출 안내의 쉬운 설명 문장'
```

`literal_glossary_match`는 공백·NFC·대소문자 정규화 후 원문 전체와 같은 경우이고, `source_contains_expression`은 원문에 해당 문자열이 포함된 경우입니다. 후자는 단어 일부나 주석과 일치할 수도 있습니다. `expression_not_found_in_source`도 표현이 틀렸다는 뜻은 아닙니다. 원본 누락은 `missing_in_source`, 영어 용어를 못 찾으면 `term_not_found`입니다. 문맥 판정과 생성 결과는 모두 `null`로 유지합니다.

미지원 언어는 `language_not_supported`로 구분합니다. 다른 언어의 자료는 `reference_evidence`로 따로 반환하며, 목표 언어의 직접 근거로 취급하지 않습니다. 지역 태그를 기본 언어로 자동 대체하지 않습니다. [미지원 언어 판단 설계](docs/unsupported-languages.md)에 공식 자료 수집, 문맥 판단, 검수 전 생성, DB 확장과 평가 방법을 정리했습니다.

다음 단계의 모델 연결은 이 JSON의 근거와 상황을 읽어 판정 또는 문장을 생성하고, 인용 출처·페이지, 판단 근거, 추가 확인할 문맥을 함께 반환하는 구조가 적합합니다. 생성 문장은 원본 번역과 별도로 저장하고, 모델·프롬프트 버전·사용한 근거·검수 상태를 기록해야 합니다. PDF 내용과 사용자 표현은 참고 데이터로 취급하며 실행 지시로 사용하지 않습니다.

현재 구현은 SQLite DB, 검색 CLI, 모델에 전달할 근거 구성 도구까지입니다. 웹 UI/API, 모델 호출, 문맥 적합성 자동 판정과 문장 생성은 아직 연결하지 않았습니다.

**자동 추출 초안이며 전체 언어 검수를 완료한 데이터는 아닙니다.** 모든 번역은 `review_status='unreviewed'`입니다. 추출 커버리지 검증은 번역의 의미나 적절성을 보증하지 않습니다. 문서 안내에 따르면 CFPB의 소비자 교육 번역용 용어집이며, 의무 규정이나 번역 요구사항은 아닙니다. 번역을 수정하거나 별도 설명을 추가할 때에는 원본과 구분해 관리해야 합니다.
