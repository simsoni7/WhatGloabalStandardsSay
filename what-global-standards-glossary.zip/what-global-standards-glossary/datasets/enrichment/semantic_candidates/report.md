# Source-definition semantic candidates

32 additional forward-conflict groups reviewed; source definitions and group IDs quoted below. AI triage only: no human review, no semantic approval, no automatic merging, no translation recommendation. All records remain original and no new quarantine is imposed. Non-quarantine is not a generation-safety approval: every decision has generation_safety_assessed:false. IDs2225/2226 carry a machine-readable definition-scope suspicion and specialist-review usage constraint. Commercial use remains determined separately; this review does not authorise Mongolbank commercial use.

Classification counts: {'same_sense_variants_candidate': 17, 'domain_scope_variants_candidate': 11, 'same_entity_variants_candidate': 1, 'polysemy_or_grammatical_role_candidate': 1, 'needs_language_specialist': 2}

## Annual payments oversight report

same_sense_variants_candidate — Both definitions describe an annual payment-system oversight report; ID2642 adds publication purpose and stakeholders. Groups8/2 differ but the core reporting object matches.

**mongolbank:candidate:20261012T231600970868Z:2** · group 8 · Төлбөрийн системийн хяналтын тайлан

> Төлбөрийн системд хяналт тавих нэгжээс жил бүр гаргадаг тайлан. Энэ тайлан олон нийтэд нээлттэй байдаг.

**mongolbank:candidate:20261012T231600970868Z:2642** · group 2 · Төлбөрийн системийн хяналтын жилийн тайлан

> Төлбөрийн системийн оператор, төлбөрийн үйлчилгээ үзүүлэгчид, дотоодын болон олон улсын зохицуулагч байгууллагууд, хэрэглэгчдэд Монголбанкнаас төлбөрийн системд тавих хяналтын талаарх мэдээллийг хүргэх, түүний ач холбогдлыг таниулах зорилгоор жил бүр гаргадаг тайлан. 

## Automated clearing house (ACH)

same_sense_variants_candidate — Both describe electronic exchange/netting of payment instructions between participants. ID155 adds processing-centre implementation; ID3 is shorter. Mixed Latin/Cyrillic target characters need orthographic review.

**mongolbank:candidate:20261012T231600970868Z:155** · group 10 · Автомат клиринг хаус

> Санхүүгийн байгууллага хоорондох төлбөрийн захиалгыг гүйцэтгэдэг электрон клирингийн систем бөгөөд харилцаа холбооны сүлжээгээр төлбөрийн захиалгыг дамжуулдаг. Автомат клиринг хаусын бүх үйл ажиллагааг дата процессын төвөөр хийж, оролцогч хоорондын өглөг, авлагын дүнг харилцан суутгаж, цэвэр үр дүнг тооцно.

**mongolbank:candidate:20261012T231600970868Z:3** · group 8 · Aвтoмaт клирингийн бaйгууллaгa

> Оролцогчдын хооронд төлбөрийн даалгавруудыг солилцож цахим хэлбэрээр харилцан суутгадаг систем.

## Clearing system

domain_scope_variants_candidate — ID11 describes operational/technical clearing infrastructure for funds or securities; ID1785 describes rules for exchanging transfer information/documents at a central location. Preserve infrastructure versus rules scope.

**mongolbank:candidate:20261012T231600970868Z:11** · group 8 · Клирингийн систем

> Нэг оролцогчоос нөгөө оролцогчид мөнгөн хөрөнгө, эсхүл үнэт цаас шилжүүлэхтэй холбогдох мэдээллийг клирингийн төвөөр дамжуулан солилцох, оролцогчдын төлбөр тооцооны үр дүнг тооцоолох үйл ажиллагаа, техник технологи, программ хангамжийн шийдэл бүхий дэд бүтэц.

**mongolbank:candidate:20261012T231600970868Z:1785** · group 3 · Клирингийн cиcтeм

> Нэг санхүүгийн байгууллагаас эх үүсвэр буюу үнэт цаасны шилжүүлэгтэй холбогдох мэдээлэл эсвэл баримт бичгийг төвлөрсөн байранд нөгөө санхүүгийн байгууллагад өгч солилцох дүрэм журам.

## Payment instrument

domain_scope_variants_candidate — ID38 explicitly lists regulator-authorised physical/nonphysical payment instruments, including cards and e-money; ID2257 defines transfer procedures/methods more broadly. Legal authorisation is not interchangeable with the generic definition.

**mongolbank:candidate:20261012T231600970868Z:2257** · group 3 · Төлбөpийн хэpэгcэл

> Төлбөр төлөгчөөс хүлээн авагчид эх үүсвэр шилжүүлгийг хийдэг дүрэм журам, арга хэрэгсэл. Төлбөр төлөгч, төлбөр хүлээн авагч нь нэг хүн байж болно.

**mongolbank:candidate:20261012T231600970868Z:38** · group 8 · Төлбөрийн хэрэгсэл

> Бэлэн мөнгө, мөнгөн хөрөнгө шилжүүлэх, хүлээн авах, төлбөр төлөх зориулалттай төлбөрийн карт, цахим мөнгө зэрэг Монголбанкны зөвшөөрөл бүхий биет, биет бус хэрэгслийг хэлнэ.

## Payment system

domain_scope_variants_candidate — ID2260 explicitly gives two uses (national bank-transfer arrangements and funds-transfer system); ID41 gives an integrated legal/technical infrastructure definition. Preserve scope and original sense enumeration.

**mongolbank:candidate:20261012T231600970868Z:2260** · group 3 · Төлбөрийн cиcтeм

> Энэ нэр тoмъëo xoëр утгатай: 1) Зарим тoxиoлдoлд энэ нь туxайн улсын мөнгөний эргэлт гүйлгээг дэмжиx банк xooрoндын эx үүсвэр шилжүүлгийг бий бoлгoгч санxүүгийн xэрэгслүүд, банкны дүрэм журам гэж үздэг; 2) Иxэнxи тoxиoлдoлд үүнийг “эx үүсвэр шилжүүлгийн систeм”-тэй зүйрлэж үзэx нь бий.

**mongolbank:candidate:20261012T231600970868Z:41** · group 8 · Төлбөрийн систем

> Төлбөр гүйцэтгэгчээс төлбөр хүлээн авагчид мөнгөн хөрөнгийн шилжүүлэг хийх, түүнтэй холбогдсон хууль тогтоомж, дүрэм, журам, гэрээ, техник технологи, дэд бүтэц, программ хангамж, төлбөрийн хэрэгсэл бүхий цогц бүтцийг хэлнэ.

## Net Zero

same_sense_variants_candidate — Both definitions balance greenhouse gas emissions entering the atmosphere against removals. ID3454 supplies slash-separated target alternatives; do not treat the slash as a single approved display string.

**mongolbank:candidate:20261012T231600970868Z:106** · group 11 · Хүлэмжийн хийн тэг тэнцэл

> Агаар мандалд орж буй хүлэмжийн хий ялгаруулалт нь агаар мандлаас арилгаж буй хүлэмжийн хийн хэмжээгээр тэнцвэржсэн байдал.

**mongolbank:candidate:20261012T231600970868Z:3454** · group 1 · Хүлэмжийн хийн тэг тэнцэл / Хүлэмжийн хийн цэвэр ялгаралт тэг байх цэг

> Агаар мандалд орж буй хүлэмжийн хий ялгаруулалт нь агаар мандлаас арилгаж буй хүлэмжийн хийн хэмжээгээр тэнцвэржсэн байхыг хэлнэ.

## Tradable permit system

same_sense_variants_candidate — Both definitions describe tradable permissions for emissions/pollution. ID3594 explicitly describes producer trading and reduction goals; wording in ID140 is less precise and needs a language specialist.

**mongolbank:candidate:20261012T231600970868Z:140** · group 11 · Арилжих зөвшөөрлийн тогтолцоо

> Тодорхой хэмжээний хүлэмжийн хийн ялгарлыг бусдад худалдан боловсруулахыг зөвшөөрдөг тогтолцоо.

**mongolbank:candidate:20261012T231600970868Z:3594** · group 1 · Арилжаалах боломжтой зөвшөөрөл / Квот борлуулалтын систем

> Арилжаалах боломжтой зөвшөөрөл нь нүүрстөрөгч ялгаруулах зэрэг тодорхой хэмжээний бохирдол гаргах эрхээ үйлдвэрлэгч нар хоорондоо худалдаалж болох тогтолцоо юм. Уг арга хэрэгслийн зорилго нь нийт бохирдлын хэмжээг бууруулахад чиглэдэг.

## Fiat currency

same_sense_variants_candidate — Both define government-declared legal tender not backed by gold/other assets. Both target labels mention paper currency; approved usage must not imply fiat currency is necessarily paper only.

**mongolbank:candidate:20261012T231600970868Z:196** · group 10 · Фиат валют буюу цаасан мөнгө 

> Алт, мөнгө гэх мэт үнэт металл эсвэл бусад биет хөрөнгөөр баталгаажаагүй, тэдгээрийг үйлдвэрлэхэд ашигласан материалын үнэ өртгөөс үл хамаарах мөнгөн тэмдэгт. Үнэ цэнтэй болгодог ганц шалтгаан нь тухайн улсын албан ёсны төлбөрийн хэрэгсэл хэмээн зарладагт оршино.  

**mongolbank:candidate:20261012T231600970868Z:3294** · group 1 · Цаасан мөнгө -Үндэсний мөнгөн тэмдэгт /Албан ёсны/

> Аливаа улсын Засгийн газраас тухайн улсын албан ёсны төлбөрийн хэрэгсэл хэмээн зарласан мөнгөн тэмдэгт. Энэхүү мөнгөн тэмдэгт нь алт эсвэл бусад хөрөнгөөр баталгааждаггүй.

## Asset

same_sense_variants_candidate — Both definitions cite civil-law tangible and intangible economic wealth held by natural/legal persons. Target labels are accounting loanword versus general property wording; select by context only after review.

**mongolbank:candidate:20261012T231600970868Z:1435** · group 4 · Актив

> Иргэн, хуулийн этгээдийн эзэмшиж байгаа эдийн засгийн үнэ цэн бүхий аливаа баялаг. Иргэний хуульд зааснаар хөрөнгө нь эдийн болон эдийн бус баялаг байна. Эдийн баялаг нь эд юмс, эдийн бус баялаг нь оюуны үнэт зүйлс, эрх болно.  

**mongolbank:candidate:20261012T231600970868Z:258** · group 9 · Хөрөнгө

> Иргэн, хуулийн этгээдийн эзэмшиж байгаа эдийн засгийн үнэ цэнэ бүхий аливаа баялаг. Иргэний хуульд зааснаар хөрөнгө нь эдийн болон эдийн бус баялаг байна. Эдийн баялаг нь эд юмс, эдийн бус баялаг нь оюуны үнэт зүйлс, эрх байна. 

## Financial Action Task Force (FATF)

same_entity_variants_candidate — Both definitions identify the intergovernmental FATF organisation and AML/CFT policy role; ID404 additionally mentions proliferation financing. The acronym-bearing target and expanded name are entity-label variants.

**mongolbank:candidate:20261012T231600970868Z:290** · group 9 · ФАТФ буюу Санхүүгийн хориг арга хэмжээ авах байгууллага

> Их 7-ийн санаачилгаар үүсгэн байгуулагдсан, мөнгө угаах, терроризмыг санхүүжүүлэхтэй тэмцэх бодлого боловсруулах чиг үүрэг бүхий засгийн газар хоорондын, хараат бус, олон улсын байгууллага юм.

**mongolbank:candidate:20261012T231600970868Z:404** · group 7 · Санхүүгийн хориг арга хэмжээ авах байгууллага

> Мөнгө угаах, терроризмыг санхүүжүүлэх болон үй олноор хөнөөх зэвсгийг дэлгэрүүлэхийг санхүүжүүлэхтэй тэмцэх, дэлхийн санхүүгийн системийг хамгаалах бодлого боловсруулж, хэрэгжүүлэх үүрэг бүхий Засгийн газар хоорондын хараат бус байгууллага бөгөөд эдгээр хууль бус үйлдлээс нийгэмд учирч болзошгүй хор уршгаас урьдчилан сэргийлэх зорилгоор олон улсын стандартыг тогтоодог.

## Force majeure

domain_scope_variants_candidate — Both address exceptional uncontrollable events affecting contractual obligations. ID2827 focuses release from responsibility and examples; ID292 also covers modification/postponement under civil law. Do not promise identical legal effects.

**mongolbank:candidate:20261012T231600970868Z:2827** · group 2 · Давагдашгүй хүчин зүйл

> Гэрээний үүргийг цаг хугацаанд нь биелүүлж чадахгүйд хүргэх аливаа онцгой үйл явдал, зайлшгүй шалтгаан (байгалийн гамшиг, үймээн самуун, ажил хаялт, тээвэр, эрчим хүчний саатал) тохиолдсон үед үүрэг хариуцлагаас чөлөөлөх заалт. 

**mongolbank:candidate:20261012T231600970868Z:292** · group 9 · Гэнэтийн буюу давагдашгүй хүчин зүйл

> Эрх зүйн харилцаанд оролцогчдын хяналт, хүсэл зоригоос хамаарахгүй онцгой нөхцөл байдал, үйл явдал тохиолдох үед оролцогчдыг үүрэг, хариуцлагаас чөлөөлөх, үүргийг өөрчлөх, хойшлуулах талаарх зохицуулалт. Холбогдох хууль- Иргэний хууль

## Guarantor

domain_scope_variants_candidate — ID1565 is explicitly loan-debt guarantor; ID300 is a broader natural/legal person undertaking responsibility for nonperformance under civil law. Shared guarantee function does not erase instrument-specific distinctions.

**mongolbank:candidate:20261012T231600970868Z:1565** · group 4 · Батлан даагч

> Зээлдэгч өрөө төлөөгүй тохиолдолд зээлдэгчийн өмнөөс өрийг төлөхийг зөвшөөрсөн талыг хэлнэ.

**mongolbank:candidate:20261012T231600970868Z:300** · group 9 · Баталгаа гаргагч

> Үүрэг гүйцэтгэгч хүн эсхүл хуулийн этгээд хүлээсэн үүргээ гүйцэтгэхгүй бол өөрөө хариуцах үүрэг хүлээсэн хүн эсхүл хуулийн этгээд. Холбогдох хууль- Иргэний хууль

## Insider trading

domain_scope_variants_candidate — Both describe securities trading using nonpublic privileged information; ID2025 emphasises company insiders and profit, while ID303 cites securities law and wider securities. Keep legal scope separate.

**mongolbank:candidate:20261012T231600970868Z:2025** · group 3 · Мэдээлэлд ойр байдлаа ашиглан арилжаанд оролцох

> Компанийн хувьцаа эзэмшигчид, захирлууд, менежерүүд гэх мэт нууцын зэрэглэлтэй мэдээлэл олж авах боломжтой этгээд давуу талаа ашиглан ашиг олох зорилгоор тухайн компанийн хувьцааг авах, зарах арилжааг хэлнэ.

**mongolbank:candidate:20261012T231600970868Z:303** · group 9 · Дотоод мэдээлэл ашиглан арилжаанд оролцох

> Нийтэд ил тод болоогүй мэдээллийг олж авах эрхтэй этгээд уг мэдээллийг ашиглан хувьцаат компанийн хувьцаа эсхүл бусад үнэт цаасны арилжаанд оролцох. Холбогдох хууль- Үнэт цаасны зах зээлийн тухай хууль

## Penalty

domain_scope_variants_candidate — ID2963 describes monetary penalty for law/contract violation, with overdue loan interest example; ID328 gives civil-law nonperformance payment calculated by obligation value. Treat as related legal/contract contexts, not an approved universal equivalent.

**mongolbank:candidate:20261012T231600970868Z:2963** · group 2 · Торгууль

> Хууль болон гэрээний зүйл заалтыг зөрчсөний улмаас ногдуулж буй мөнгөн төлбөрийг хэлнэ. Тухайлбал, гэрээнд заасан хугацаанаас зээлийн төлбөрөө хоцроож төлсөн тохиолдолд гэрээнд заасан торгуулийн нэмэлт хүү төлнө.

**mongolbank:candidate:20261012T231600970868Z:328** · group 9 · Үүрэг зөрчсөний төлбөр

> Үүргээ гүйцэтгээгүй буюу зохих ёсоор гүйцэтгээгүй тал нь төлөхөөр заасан, эсхүл гүйцэтгээгүй буюу зохих ёсоор гүйцэтгээгүй үүргийн үнийн дүнгийн тодорхой хувиар тогтоосон төлбөр. Холбогдох хууль- Иргэний хууль

## Pledge

polysemy_or_grammatical_role_candidate — ID2274 describes the act of delivering collateral, while ID330 describes the legal security mechanism and priority enforcement rights. Target verb phrase versus noun/legal concept should remain separate.

**mongolbank:candidate:20261012T231600970868Z:2274** · group 3 · Бaрьцaaнд тaвиx

> Үүргийн гүйцэтгэлийн аюулгүй байдлыг хангах зорилгоор нэг талаас (өр төлөгчөөс) нөгөө талд (барьцаалагч) актив хөрөнгө хүргүүлэх үйл ажиллагаа. Барьцаалагч талын хувьд хүргүүлсэн актив нь барьцааны зүйл болдог бол өр төлөгчийн хувьд өмч хэвээр байдаг.

**mongolbank:candidate:20261012T231600970868Z:330** · group 9 · Барьцаа

> Үүрэг гүйцэтгэгч барьцаагаар хангагдсан үүргийг хууль буюу гэрээнд заасны дагуу гүйцэтгээгүй буюу зохих ёсоор гүйцэтгээгүй бол барьцаалагч буюу үүрэг гүйцэтгүүлэгч нь бусад үүрэг гүйцэтгүүлэгчдээс тэргүүн ээлжид барьцааны зүйлийн үнээс шаардлагаа хангуулах эрхийг олгодог үүргийн гүйцэтгэлийг хангах арга. Барьцааны эрх үүссэнээр тухайн этгээд үүргийн гүйцэтгэлийг шаардах давуу эрх эдэлнэ. Барьцаа үүсэх үед тодорхойлж болох ирээдүйд бий болох, болзол тавьсан шаардлагыг, эсхүл талуудын харилцан тохиролцсон аливаа үүргийг хангахад барьцааг хэрэглэж болно. Холбогдох хууль- Иргэний хууль, Хөдлөх эд хөрөнгө болон эдийн бус хөрөнгийн барьцааны тухай хууль, Үл хөдлөх хөрөнгийн барьцааны тухай хууль

## Separating

same_sense_variants_candidate — Both definitions describe transferring part of a legal entity rights/obligations to a new entity without ceasing operations. ID342 supplies civil/company law references and a fuller target label.

**mongolbank:candidate:20261012T231600970868Z:342** · group 9 · Хуулийн этгээдийг тусгаарлах

> Хуулийн этгээдийн үйл ажиллагааг зогсоохгүйгээр түүний зарим эрх, үүрэг, хариуцлагыг шинээр байгуулагдсан хуулийн этгээдэд шилжүүлэх. Холбогдох хууль- Иргэний хууль, Компанийн тухай хууль

**mongolbank:candidate:20261012T231600970868Z:955** · group 6 · Тусгаарлах

> Хуулийн этгээдийн үйл ажиллагааг зогсоохгүйгээр түүний зарим эрх, үүрэг, хариуцлагыг шинээр байгуулагдсан хуулийн этгээдэд шилжүүлэх

## Beneficiary

domain_scope_variants_candidate — ID2670 gives financial-product beneficiary with life-insurance example; ID369 distinguishes FATF trust and insurance beneficiaries; ID559 defines a third party receiving entrusted-property benefits. Preserve trust/insurance/general-product context.

**mongolbank:candidate:20261012T231600970868Z:2670** · group 2 · Үр ашиг хүртэгч

> Санхүүгийн бүтээгдэхүүнээс ашиг хүртэх хууль ёсны эрх бүхий хувь хүн, хуулийн этгээд. Тухайлбал, амьдралын даатгалын гэрээнд даатгуулагч нас барсны дараа хуримтлагдсан үлдэгдэл хөрөнгийг хүлээн авах эрхтэй гэж заасан этгээд (нөхөр, энхэр, хүүхэд гэх мэт)-ийг хэлнэ. 

**mongolbank:candidate:20261012T231600970868Z:369** · group 7 · Хүлээн авагч, үр шим хүртэгч

> Санхүүгийн хориг арга хэмжээ авах байгууллага (ФАТФ)-ын зөвлөмжийн хүрээнд хүлээн авагч, үр шим хүртэгч гэдгийг ашиглаж буй нөхцөл байдлаас хамааран өөр өөр утга санаа илэрхийлдэг:
• Трастын хуулиар траст хэлцлээс үр шим хүртэгч хувь хүн, этгээдийг үр шим хүртэгч гэдэг. Үр шим хүртэгч нь хувь хүн, хуулийн этгээд, эрх зүйн бусад зохицуулалтад хамаарах этгээд байж болно. Бүх траст нь (хандивын эсвэл хуулиар зөвшөөрөгдсөн хандивын бус траст) тодорхой үр шим хүртэгчтэй байх шаардлагатай. Траст нь заавал тодорхойлж болох эцсийн үр шим хүртэгчтэй байх шаардлагатай ч зарим траст нь тодорхой этгээдэд үр шим хүртэх эрх үүстэл зөвхөн удирдлагыг хэрэгжүүлдэг эсвэл хөрөнгийг заасан хугацаа (хуримтлалын үе гэдэг) болтол өөр хүн хариуцаж болдог. Энэхүү хугацааг трастын байнгын хүчинтэй нөхцөлөөс хамааран уртасгаж болдог бөгөөд үүнийг ихэвчлэн трастын гэрээслэлд дурдсан байдаг. 
• Амь насны даатгал эсвэл бусад хэлбэрийн хөрөнгө оруулалттай холбоотой даатгалын бүтээгдэхүүний хувьд үр шим хүртгэгч нь даатгалын тохиолдол учирсан үед тухайн даатгалын нөхөн төлбөрийг хүлээн авах хувь хүн, хуулийн этгээд, эрх зүйн бусад зохицуулалтад хамаарах этгээд байна.

**mongolbank:candidate:20261012T231600970868Z:559** · group 6 · Хувь хүртэгч /итгэлцэл/

> Итгэмжилсэн хөрөнгийн ашиг /үр шим/-ийг бүхэлд буюу буюу тодорхой хэсгийг хүртэхээр хөрөнгө итгэмжлэн удирдах гэрээнд заасан гуравдагч иргэн, хуулийн этгээд.

## Letter of credit

same_sense_variants_candidate — Both definitions describe a bank undertaking payment to a supplier subject to agreed documentary/contract conditions. ID2876 adds buyer-request and document-deadline details. Target mixed-script form needs orthographic review.

**mongolbank:candidate:20261012T231600970868Z:2091** · group 3 · Aккрeдитив

> Компaнийн хaрилцaгч бaнкнaaс гaдaaдын нийлүүлэгчид гaргaж өгдөг, гэрээний бүх нөхцөл биелсэн тохиолдолд нэхэмжлэлийн дaгyy төлбөрийг хийхийг зaaсaн бaнкны бaтaлгaa.

**mongolbank:candidate:20261012T231600970868Z:2876** · group 2 · Аккредитив

> Тухайн банк худалдан авагчийн хүсэлтээр буюу өөрийн нэрийн өмнөөс бэлтгэн нийлүүлэгч нь гэрээнд тодорхой заасан баримтуудыг тогтоосон хугацаанд банканд бүрдүүлж өгснийг үндэслэн 2 талын тохиролцсон валютаар мөнгийг төлөхийг хүлээсэн банкны үүрэг юм.

## Leveraged lease

same_sense_variants_candidate — Both definitions specify leveraged lease financing with roughly20 percent supplied by lessor and remainder by lender. ID2094 contains 2O with letter O; numerical text must remain source evidence until corrected separately.

**mongolbank:candidate:20261012T231600970868Z:2094** · group 3 · Хөшүүргийн түрээс

> Үндсэн хөрөнгийн өртгийн 2O орчим хувийг түрээслүүлэгчээс хувь оролцоо болгон гаргаж үлдэх хэсгийг зээлдүүлэгч гаргах түрээс.

**mongolbank:candidate:20261012T231600970868Z:2879** · group 2 · Хөшүүрэгтэй түрээс

> Түрээслүүлэгч нь хөрөнгийн өртгийн дөнгөж 20 орчим хувийг хангадаг, харин зээлдүүлэгч нь үлдэгдлийг нь нийлүүлдэг түрээс.

## Marginal tax rate

same_sense_variants_candidate — Both define taxation of additional/incremental income; ID2126 describes income above a threshold and ID2899 the extra-income rate. Target variation adds the word for rate amount.

**mongolbank:candidate:20261012T231600970868Z:2126** · group 3 · Аxиyц татварын хувь

> Оpлогын тодоpхой түвшнээс илүү гаpсан хэсэгт ногдуулдаг татваpын хэмжээ

**mongolbank:candidate:20261012T231600970868Z:2899** · group 2 · ахиуц татварын хувь хэмжээ

> Нэмэлт орлогод татвар ногдуулах хувь хэмжээ.

## Notional principal

same_sense_variants_candidate — Both describe a reference principal for calculating swap payments; ID2207 explicitly states it need not be transferred. Nominal versus hypothetical target wording requires contextual specialist selection.

**mongolbank:candidate:20261012T231600970868Z:2207** · group 3 · Нэрлэсэн үндсэн төлбөр

> Тухайн санхүүгийн хэрэгслийн хувьд хүү бодоход ашиглах нэрлэсэн буюу онолын хувьд төсөөлөн тооцсон дүн. Ихэвчлэн своп дээр хэрэглэгддэг. Үндсэн төлбөр нь гараас гарт шилжихгүй санхүүгийн хэрэгслүүдийн хувьд үүнийг ашигладаг.

**mongolbank:candidate:20261012T231600970868Z:2208** · group 3 · Хийсвэр үндсэн төлбөр

> Свопын төлбөрийг тооцохын тулд ашигладаг үндсэн өрийн дүн.

## Operating profit margin

same_sense_variants_candidate — Both definitions calculate operating profit divided by sales, excluding interest/tax from deducted costs. Target wording differs between marginal profit and profit ratio; definitions support the ratio concept but no target approval is granted.

**mongolbank:candidate:20261012T231600970868Z:2221** · group 3 · Үйл ажиллагааны ахиуц ашиг

> Xүү, татварыг оруулахгүйгээр бусад бүх өртөг зардлаа төлсний дараа үлдэж байгаа борлуулалтын төгрөг тутмын ашгийн хувь. Борлуулалтаас хүү, татвараас бусад зардлыг хасаж (үйл ажиллагааны ашиг гарна) борлуулалтын дүнд хувааж тооцно.

**mongolbank:candidate:20261012T231600970868Z:2949** · group 2 · Үйл ажиллагааны ашгийн хувь

> Хүү, татварыг оруулахгүйгээр бусад бүх өртөг зардлаа төлсний дараа үлдэж байгаа борлуулалтын ашгийн хувь. Борлуулалтаас хүү, татвараас бусад зардлыг хасаж (үйл ажиллагааны ашиг гарна) борлуулалтын дүнд хувааж тооцно.

## Optimal risky portfolio

needs_language_specialist — Both supplied definitions describe mixing risky and risk-free assets into a complete portfolio, despite the English label Optimal risky portfolio. This raises a source-definition scope suspicion, but available source alone cannot resolve it; no quarantine imposed.

**mongolbank:candidate:20261012T231600970868Z:2225** · group 3 · Эрсдэлтэй активуудын оновчтой багц

> Эрсдэлтэй активуудын хамгийн тохиромжтой багц дээр эрсдэлгүй активыг нэмэх замаар иж бүрэн багцыг бүрдүүлнэ. Энэ нь эрсдэл ба өгөөжийн төгс тэнцвэрийг олох зорилготой.

**mongolbank:candidate:20261012T231600970868Z:2226** · group 3 · Эрсдэлтэй активын оновчтой багц

> Эрсдэлтэй активуудыг эрсдэлгүй активтай хольж бүтэн багц үүсгэсэн хамгийн сайн хувилбар.

## Order costs

same_sense_variants_candidate — Both definitions refer to fixed clerical costs of placing/receiving inventory orders. ID2231 starts target with digit3 instead of Cyrillic letter and includes mixed-script characters; preserve source and request orthographic correction.

**mongolbank:candidate:20261012T231600970868Z:2231** · group 3 · 3ахиалгын зардал

> Бараа материалын захиалгыг өгөх ба хүлээr авахад гардаг бичилт тооцооны тогтмол зардал .

**mongolbank:candidate:20261012T231600970868Z:2954** · group 2 · Захиалгын зардал

> Бараа материалын захиалга байршуулах, хүлээн авахтай холбоотой бичиг хэргийн тогтмол зардал.

## Ordinary income

domain_scope_variants_candidate — Both definitions restrict ordinary income to sales of company goods/services. This is the source corporate context; do not reuse as a complete jurisdiction-specific tax-law definition of ordinary income.

**mongolbank:candidate:20261012T231600970868Z:2232** · group 3 · Ердийн орлого

> Компанийн бүтээгдэхүүн үйлчилгээний боpлуулалтаас бий болсон оpлого.

**mongolbank:candidate:20261012T231600970868Z:2956** · group 2 · Энгийн орлого

> Компанийн бараа, үйлчилгээг борлуулсны үр дүнд олсон орлого.

## Outstanding shares

same_sense_variants_candidate — Both definitions count issued shares held by investors/shareholders in the market. ID2236 lists holder types; neither quoted definition explicitly handles treasury shares, so no accounting/legal scope approval.

**mongolbank:candidate:20261012T231600970868Z:2236** · group 3 · Эргэлтэд байгаа xувьцаа

> Компаниас хувьцаа эзэмшигчдэд эзэмшүүлэхээр гаргаж, зах зээл дээр арилжиж буй бүх хувьцааны тоог хэлнэ. Энэ нь компанийн нийт хувьцаа гаргалтын хэмжээг илэрхийлэх бөгөөд тэдгээр хувьцаа нь олон нийт, байгууллагууд, дотоод ажилтнууд, томоохон хөрөнгө оруулагчид гэх мэт эзэмшигчдийн гарт байдаг.

**mongolbank:candidate:20261012T231600970868Z:2958** · group 2 · Гүйлгээнд гарсан хувьцаа

> Компанийн хөрөнгө оруулагчид, хувьцаа эзэмшигчдэд худалдаалагдсан, мөн зах зээл дээр идэвхтэй арилжаалагдаж байгаа нийт хувьцааны тоог хэлнэ.

## Payback period

same_sense_variants_candidate — Both define time for cash flows to recover a project initial investment. Preserve project-payback context instead of general debt maturity/repayment interpretation.

**mongolbank:candidate:20261012T231600970868Z:2253** · group 3 · Эpгэн төлөх хугaцaa

> Төслийн анхны хөрөнгө оруулалтыг мөнгөн орлогын урсгалаараа нөхөхөд компаниас шаардагдах хугацаа.

**mongolbank:candidate:20261012T231600970868Z:2960** · group 2 · Эргэн төлөлтийн хугацаа

> Төсөлд оруулсан анхны хөрөнгө оруулалтаа нөхөхөд шаардагдах мөнгөн урсгалаас тооцсон хугацаа.

## Payment date

domain_scope_variants_candidate — ID2256 gives transfer date generally with dividend example; ID2961 restricts to directors-set dividend mailing date. Broad payment event versus dividend-specific timing must stay contextualised.

**mongolbank:candidate:20261012T231600970868Z:2256** · group 3 · Төлбөpийн өдөp

> Төлбөр гүйцэтгэгч талаас төлбөр хүлээн авагч талд төлбөр шилжүүлэх өдөр. Жишээлбэл хувьцаа эзэмшигчдэд ногдол ашгийн төлбөрийг бодитойгоор шилжүүлдэг өдөр.

**mongolbank:candidate:20261012T231600970868Z:2961** · group 2 · Төлбөрийн хугацаа

> Пүүсийн захирлууд тогтоодог бөгөөд пүүс ногдол ашгийн төлбөрийг ногдол ашгийг эзэмшигчдэд шуудангаар илгээх бодит огноо юм.

## Performance shares

needs_language_specialist — ID2270 is circular (shares given for performance); ID2966 mentions management awards for reaching planned performance. Likely overlapping labels, but the first definition is too sparse to establish equivalence.

**mongolbank:candidate:20261012T231600970868Z:2270** · group 3 · Гүйцэтгэлийн xyвьцaa

> Гүйцэтгэлээр олгох хувьцаа.

**mongolbank:candidate:20261012T231600970868Z:2966** · group 2 · Гүйцэтгэлийн хувьцаа

> Төлөвлөсөн гүйцэтгэлийн зорилгод хүрэхийн тулд удирдлагад өгсөн хувьцаа.

## Pledge of accounts receivable

same_sense_variants_candidate — Both definitions use company receivables as collateral/security for short-term borrowing. Target action wording versus collateral noun may require grammar-aware selection without concept merging.

**mongolbank:candidate:20261012T231600970868Z:2275** · group 3 · Авлагаа барьцаалах

> Богино хугацаатай зээл авахын тулд авлагын дансаа барьцаа, баталгаа болгон ашиглах.

**mongolbank:candidate:20261012T231600970868Z:2971** · group 2 · Дансны авлагын барьцаа

> Богино хугацаат зээл авахын тулд пүүсийн авлагыг барьцаа болгон ашиглах.

## Poison pill

same_sense_variants_candidate — Both describe anti-hostile-takeover rights/securities strategies; ID2278 gives cheaper-share purchase example while ID2972 describes triggering shareholder rights. Keep mechanism detail as context.

**mongolbank:candidate:20261012T231600970868Z:2278** · group 3 · Хoртoй эм стратеги

> Компаниудыг гадны этгээд хүчээр худалдан авах оролдлогоос хамгаалах арга. Жишээлбэл, худалдан авагчид хяналтаа тогтоохоос өмнө одоогийн хувьцаа эзэмшигчдэд илүү хямд үнээр хувьцаа авах боломж олгох.

**mongolbank:candidate:20261012T231600970868Z:2972** · group 2 · Хорт стратеги

> Пүүс худалдан авахыг оролдсон үед хүчин төгөлдөр болох тодорхой эрхийг эзэмшигчдэдээ олгодог үнэт цаас гаргадаг, худалдан авах хамгаалалт. Эдгээр эрхүүд нь зорилтот пүүсийг дайсагнасан худалдан авагчийн сонирхолгүй болгодог.

## Pro forma statements

domain_scope_variants_candidate — ID2309 explicitly defines forecast income statement/balance sheet; ID2986 describes projected expenses/income based on past experience and future plans. Related projection concept, but statement artefact versus projected quantities differ.

**mongolbank:candidate:20261012T231600970868Z:2309** · group 3 · Cанхүүгийн тайлангийн төсөл

> Таамаглаж төлөвлөсөн санхүүгийн тайлан (орлогын тайлан, тэнцэл).

**mongolbank:candidate:20261012T231600970868Z:2986** · group 2 · Проформа санхүүгийн тайлан

> Компанийн өнгөрсөн туршлага, ирээдүйн төлөвлөгөөнд үндэслэн ирээдүйн зардал, орлогын төсөөлөл.
