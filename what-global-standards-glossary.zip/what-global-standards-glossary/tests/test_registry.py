from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from reference_glossaries import retrieve, verify
from build_glossary import build


class RegistryTests(unittest.TestCase):
    def test_frozen_manifest(self):
        manifest = verify(ROOT / 'datasets/cfpd/v1')
        self.assertEqual(manifest['display_name'], 'cfpd용어집')
        self.assertEqual(manifest['source_entry_count'], 10090)

    def test_rebuild_refuses_frozen_paths(self):
        for directory in [ROOT / 'data', ROOT / 'datasets/cfpd/v1', ROOT / 'datasets/cfpd/v1/nested']:
            with self.assertRaises(ValueError):
                build(directory)

    def test_target_evidence_has_dataset_and_source(self):
        result = retrieve('Credit score', 'ko', dataset_id='cfpd')
        self.assertEqual(result['lookup_status'], 'evidence_found')
        evidence = result['evidence'][0]
        self.assertEqual(evidence['dataset_version'], 'v1')
        self.assertEqual(evidence['translation'], '신용 점수')
        self.assertTrue(evidence['source']['pdf_page_start'])

    def test_mongolian_candidate_cannot_be_evidence(self):
        result = retrieve('Credit score', 'mn')
        self.assertEqual(result['evidence'], [])
        self.assertEqual(result['lookup_status'], 'no_target_language_evidence')
        self.assertEqual(len(result['reference_evidence']), 5)
        self.assertEqual(result['skipped_datasets'][0]['dataset_id'], 'mongolbank')
        self.assertIsNone(result['generated_expression'])

    def test_unknown_dataset(self):
        with self.assertRaises(ValueError):
            retrieve('Credit score', 'mn', dataset_id='nonexistent')


if __name__ == '__main__':
    unittest.main()
