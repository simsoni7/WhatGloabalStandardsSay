import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from collect_mongolbank import parse_response
from reference_glossaries import retrieve


class ExpandedCollectionTests(unittest.TestCase):
    def test_http_success_with_api_error_is_rejected(self):
        with self.assertRaises(ValueError):
            parse_response('{"message":"Internal server error"}')

    def test_api_missing_pair_fields_is_rejected(self):
        with self.assertRaises(ValueError):
            parse_response('{"data":{"success":true,"data":[{"ID":1}]}}')

    def test_collected_mongolian_is_candidate_not_approval(self):
        result=retrieve('Credit Card','mn',dataset_id='mongolbank',include_candidates=True)
        self.assertTrue(result['evidence'])
        self.assertEqual(result['evidence'][0]['translation'],'Зээлийн карт')
        self.assertEqual(result['evidence'][0]['dataset_state'],'candidate')
        self.assertTrue(result['evidence'][0]['definition']['text'])
        self.assertIsNone(result['contextual_verdict'])

    def test_collected_nepali_includes_sources(self):
        result=retrieve('Saving Account','ne',dataset_id='nepalbank',include_candidates=True)
        self.assertEqual(result['evidence'][0]['translation'],'बचत खाता')
        self.assertTrue(result['evidence'][0]['source']['occurrences'])

    def test_candidates_are_excluded_by_default(self):
        result=retrieve('Credit Card','mn',dataset_id='mongolbank')
        self.assertEqual(result['evidence'],[])


if __name__=='__main__':
    unittest.main()
