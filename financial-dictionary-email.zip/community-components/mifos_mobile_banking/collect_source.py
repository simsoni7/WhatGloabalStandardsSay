#!/usr/bin/env python3
"""Pinned MPL mobile banking labels, separated from permissive sources."""
import collections,hashlib,json,re,subprocess,urllib.request,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'datasets/source_collection/banking_batch6'
COMMIT='18a6499ffef39c1cfac69be4a8fdbef84485e536'; REPO='https://github.com/openMF/mifos-mobile'
BASE='cmp-android/src/main/res'; LOCALES={'ar':'ar','bn':'bn','es':'es','fa-rAF':'fa','fr':'fr','hi':'hi','in':'id','km':'km','kn':'kn','ml':'ml','my':'my','pl':'pl','pt':'pt','ru':'ru','sw':'sw','te':'te','ur':'ur'}
KEYS='''funds_transfer recent_transactions charges saving_account_details feature_account_savings_account nominal_interest_rate account_number account_balance total_deposits feature_account_loan feature_account_loan_account loan_repayment_schedule last_transaction transfer_date loan_interest_type interest_calculation_period repayment_strategy feature_account_deposit balance loan_charges savings_charges account_status loan_purpose principal principal_disbursed annual_interest_rate interest_charged interest_paid loan_account_details loan_summary loan_name interest fees total_repayment interest_waived fees_waived outstanding_balance loan_type currency repayment_schedule transactions transfer loan_balance repayment loan_repayment beneficiary beneficiaries beneficiary_detail beneficiary_name account_type transfer_limit third_party_transfer total_loan total_saving income_generating_loan loan_product total_saving_balance total_loan_balance feature_account_interest_posting feature_account_fee_deduction feature_account_withdrawal_transfer feature_account_rejected_transfer feature_account_overdraft_fee savings_account_transaction transaction_period transaction_type'''.split()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(name,upstream):
 p=OUT/'raw'/name;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():
  local=Path('/tmp/batch6-mifos-mobile')/upstream
  if local.exists():
   assert subprocess.check_output(['git','-C','/tmp/batch6-mifos-mobile','rev-parse','HEAD'],text=True).strip()==COMMIT
  p.write_bytes(local.read_bytes() if local.exists() else urllib.request.urlopen(f'https://raw.githubusercontent.com/openMF/mifos-mobile/{COMMIT}/{upstream}',timeout=60).read())
 return p

def main():
 license=get('LICENSE','LICENSE'); assert b'Mozilla Public License' in license.read_bytes()
 enfile=get('values.xml',f'{BASE}/values/strings.xml');en={e.attrib['name']:e.text or '' for e in ET.parse(enfile).getroot() if e.tag=='string'}
 rows=[];excluded=[];seen=set();files={'LICENSE':{'path':'LICENSE','sha256':sha(license)},'values.xml':{'path':f'{BASE}/values/strings.xml','sha256':sha(enfile)}}
 for locale,lang in LOCALES.items():
  path=f'{BASE}/values-{locale}/strings.xml';p=get(f'values-{locale}.xml',path)
  assert b'Mozilla Public License' in p.read_bytes(),path
  files[p.name]={'path':path,'sha256':sha(p)}
  target={e.attrib['name']:e.text or '' for e in ET.parse(p).getroot() if e.tag=='string'}
  for key in KEYS:
   eng=en[key].strip();tar=target.get(key,'').strip();reason=None
   if not tar:reason='missing_actual_target'
   elif tar.casefold()==eng.casefold():reason='english_fallback_or_identical'
   elif re.search(r'%|\{|\}|<|>|\\|\*',eng+tar):reason='placeholder_markup_or_escape'
   elif not any(c.isalpha() for c in tar):reason='nonlexical'
   fp=(lang,eng.casefold(),tar.casefold())
   if fp in seen:reason='exact_pair_duplicate_key'
   if reason:excluded.append({'key':key,'language':lang,'english':eng,'target':tar,'reason':reason});continue
   seen.add(fp)
   rows.append({'evidence_id':f'mifos_mobile_banking:{lang}:{key}','dataset_id':'mifos_mobile_banking','dataset_version':COMMIT,'source_concept_id':f'mifos_mobile_banking:{key}','english':eng,'translation':tar,'target_language':lang,'source_language':'en','kind':'financial_software_label','category':'mobile_banking_software','jurisdiction':'international_software_context','license':'MPL-2.0','commercial_use':True,'distribution_scope':'copyleft_separate_pack','approved_translation':None,'generation_eligible':False,'human_review':False,'context_required':True,'quality_flags':['software_label_not_official_bank_glossary','upstream_translation_not_expert_approved','context_required','language_specialist_review_required'],'source':{'url':f'{REPO}/blob/{COMMIT}/{path}','raw_url':f'https://raw.githubusercontent.com/openMF/mifos-mobile/{COMMIT}/{path}','file':str(p.relative_to(ROOT)),'sha256':sha(p),'english_file':str(enfile.relative_to(ROOT)),'english_sha256':sha(enfile),'source_key':key,'source_locale':locale,'english_locale':'en','raw_english_value':en[key],'raw_target_value':target[key],'normalization':'outer_whitespace_trim_only','alignment_method':'explicit_same_android_resource_key','software_context':'Mifos end-user mobile banking self-service; loans, savings and transfers','commit':COMMIT,'license_url':f'{REPO}/blob/{COMMIT}/LICENSE','license_sha256':sha(license),'file_license_header':'Copyright 2026 Mifos Initiative; Mozilla Public License v2.0','notice':'No root NOTICE file observed; preserve per-file MPL headers and LICENSE'}})
 (OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 (OUT/'excluded.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2)+'\n')
 manifest={'source_repository':REPO,'commit':COMMIT,'license':'MPL-2.0','commercial_use':True,'distribution_scope':'copyleft_separate_pack','license_obligations':['Preserve MPL license and per-file copyright headers','Distribute covered source and modifications under MPL; no Apache/MIT default-pack classification'],'files':files,'selected_keys':KEYS,'locale_mapping':LOCALES,'total_pairs':len(rows),'counts':dict(sorted(collections.Counter(r['target_language'] for r in rows).items())),'no_locale_fallback':True,'expert_approved':0,'generation_block_ids':[r['evidence_id'] for r in rows],'trust_scope':'Official project resource observations, not central-bank glossary nor verified financial translation','investigated_rejected_permissive_candidates':[{'repo':'openMF/web-app','commit':'e175e1cd021b97bc03e0245694bf13d98f6cc707','observed_license':'MPL-2.0'},{'repo':'frappe/books','observed_license':'AGPL-3.0','reason':'not permissive; not collected'}]}
 (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'pairs':len(rows),'counts':manifest['counts']},ensure_ascii=False))
if __name__=='__main__':main()
