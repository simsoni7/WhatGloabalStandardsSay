import hashlib,json,tempfile,unittest
from pathlib import Path
from glossary_app.index import load_language_packs

class LanguagePackIntegrity(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.pack=self.root/'datasets/language_packs/example';self.pack.mkdir(parents=True)
  self.record={'evidence_id':'example:1','dataset_id':'example','source_language':'en','english':'Loan','target_language':'fr','translation':'Prêt','availability':'present','source':{'url':'https://example.org/official'}}
  self.save()
 def tearDown(self):self.temp.cleanup()
 def save(self,decision='accepted_reference',path='datasets/language_packs/example'):
  payload=json.dumps(self.record)+'\n';(self.pack/'evidence.jsonl').write_text(payload)
  (self.pack/'manifest.json').write_text(json.dumps({'dataset_id':'example','entry_count':1,'usage_terms':{'commercial_use':True},'files_sha256':{'evidence.jsonl':hashlib.sha256(payload.encode()).hexdigest()}}))
  (self.pack.parent/'registry.json').write_text(json.dumps({'packs':[{'dataset_id':'example','path':path,'state':'candidate','decision':decision,'commercial_use':True}]}))
 def test_pending_pack_is_not_reference(self):
  self.save(decision='pending');self.assertEqual(load_language_packs(self.root),([],{}))
 def test_tampered_source_rejected(self):
  (self.pack/'evidence.jsonl').write_text('{}\n')
  with self.assertRaisesRegex(ValueError,'checksum'):load_language_packs(self.root)
 def test_path_escape_rejected(self):
  self.save(path='../outside')
  with self.assertRaisesRegex(ValueError,'escapes'):load_language_packs(self.root)
 def test_benchmark_not_indexed_as_reference(self):
  self.record['kind']='benchmark_case';self.save()
  with self.assertRaisesRegex(ValueError,'Invalid reference'):load_language_packs(self.root)
 def test_accepted_preserves_candidate_state(self):
  rows,inputs=load_language_packs(self.root);self.assertEqual(rows[0][0]['dataset_state'],'candidate');self.assertTrue(rows[0][2]);self.assertIn('example',inputs)
 def test_unlicensed_reference_rejected(self):
  file=self.pack/'manifest.json';manifest=json.loads(file.read_text());manifest['usage_terms']['commercial_use']=False;file.write_text(json.dumps(manifest))
  with self.assertRaisesRegex(ValueError,'commercial-use'):load_language_packs(self.root)
 def test_source_flag_names_are_normalized_for_engine(self):
  self.record['quality_flags']=['context_limited'];self.save()
  rows,_=load_language_packs(self.root);self.assertEqual(rows[0][0]['quality_flags'],[{'issue_type':'context_limited','priority':'informational'}])
if __name__=='__main__':unittest.main()
