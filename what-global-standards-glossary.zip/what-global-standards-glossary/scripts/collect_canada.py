"""Extract explicitly paired financial labels from official MIT-licensed GC code.
Usage: python scripts/collect_canada.py /path/to/ckanext-canada
No generated translations, ordinal alignment, or monetary descriptions inferred.
"""
import hashlib,json,pathlib,re,shutil,subprocess,sys
root=pathlib.Path(sys.argv[1]); out=pathlib.Path('datasets/source_collection/canada');raw=out/'raw';raw.mkdir(parents=True,exist_ok=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
base=f'https://github.com/open-data/ckanext-canada/blob/{commit}/'
selected={'Total Contract Value','Original Contract Value','Contract Amendment Value','Economic Object Code','Contract Date','Contracting Entity','Agreement Type','Trade Agreement','Number of Bids','Award Criteria','Recipient Type','Recipient Business Number','Agreement Value in CAD','Foreign Currency Type','Foreign Currency Value','Agreement Number','Airfare','Other transportation','Lodging','Meals and incidentals','Other expenses','Total Amount','Total cost'}
files=['LICENSE','README.md','ckanext/canada/tables/choices/currency.json']+[f'ckanext/canada/tables/{n}.yaml' for n in ['contracts','grants','travelq','hospitalityq']]
manifest=[];rows=[]
for file in files:
 b=(root/file).read_bytes();dest=raw/file;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);sha=hashlib.sha256(b).hexdigest();manifest.append(dict(path=str(dest),original_path=file,url=base+file,sha256=sha,bytes=len(b)))
 if file.endswith('.yaml'):
  text=b.decode()
  for m in re.finditer(r'(?m)^(?P<indent> +)label:\n +en: (?P<en>.+)\n +fr: (?P<fr>.+)',text):
   en=m['en'].strip();fr=m['fr'].strip()
   if en not in selected:continue
   line=text[:m.start()].count('\n')+1
   rows.append(dict(english=en,translation=fr,entry_type='financial_reporting_label',source_location=f'{file}:L{line}',source_url=base+file+f'#L{line}',source_sha256=sha,context=pathlib.Path(file).stem,alignment_basis='same YAML label mapping en/fr'))
 if file.endswith('currency.json'):
  for code,pair in json.loads(b).items():
   rows.append(dict(english=pair['en'],translation=pair['fr'],entry_type='currency_name',source_location=f'{file}:/{code}',source_url=base+file,source_sha256=sha,context=f'currency code {code}; original snapshot, current ISO validity not verified',alignment_basis='same currency object key en/fr',currency_code=code))
for i,row in enumerate(rows):
 row.update(evidence_id=f'canada_ckan_{commit[:12]}_{i+1:04d}',dataset_id='canada_government_financial_labels',dataset_version=commit,target_language='fr',source_language='en',jurisdiction='Canada',license='MIT',license_file=str(raw/'LICENSE'),license_url=base+'LICENSE',review_status='explicit_source_pair_not_expert_reviewed',usable=False)
(out/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
counts={k:sum(r['entry_type']==k for r in rows) for k in sorted({r['entry_type'] for r in rows})}
(out/'manifest.json').write_text(json.dumps(dict(source_repository='https://github.com/open-data/ckanext-canada',commit=commit,license='MIT',commercial_allowed=True,records=len(rows),counts=counts,files=manifest,scope='government financial reporting labels and currency names; NOT FCAC consumer glossary or TERMIUM',status='pending_data_management_review'),ensure_ascii=False,indent=2))
print(json.dumps(dict(records=len(rows),counts=counts),indent=2))
