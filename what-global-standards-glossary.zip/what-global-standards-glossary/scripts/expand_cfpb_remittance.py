"""Add ten explicitly aligned remittance headings in five official language versions.
No generated translations. Original texts and frozen CFPD remain unchanged.
"""
import collections,hashlib,json,pathlib,re,shutil
import fitz
ROOT=pathlib.Path(__file__).resolve().parents[1]
PACK=ROOT/'datasets/language_packs/cfpb_remittance'
EXP=ROOT/'datasets/source_collection/cfpb_remittance_expansion'
# provider, before payment, FX, company fees/taxes, other fees, during payment,
# availability, cancellation right, error action, complaint filing.
EN=[(1,[4]),(2,[5]),(2,[7]),(2,[8]),(2,[9]),(2,[13,14]),(2,[17]),(2,[18]),(2,[19]),(2,[20])]
TARGET={
 'es':[(1,[4]),(2,[5]),(2,[7]),(2,[8]),(2,[9]),(2,[12]),(2,[15]),(2,[16]),(2,[17]),(2,[18])],
 'ko':[(1,[4]),(1,[19]),(1,[21]),(1,[22]),(1,[23]),(2,[3]),(2,[7]),(2,[8]),(2,[9]),(2,[10])],
 'ru':[(1,[7]),(2,[10]),(2,[13]),(2,[14,15]),(2,[16]),(2,[21]),(2,[26,27]),(2,[28,29]),(2,[30,31]),(2,[32])],
 'vi':[(1,[5]),(2,[5]),(2,[7]),(2,[8]),(2,[9]),(2,[12]),(2,[16]),(2,[17]),(2,[18]),(2,[19])],
 'zh-Hant':[(1,[6]),(1,[28]),(1,[32]),(1,[33]),(2,[2]),(2,[6]),(2,[10]),(2,[11]),(2,[12]),(2,[13])]
}
def extract(doc,page,indices):
 blocks=[b for b in doc[page-1].get_text('dict')['blocks'] if 'lines' in b];selected=[blocks[i] for i in indices]
 text=' '.join(''.join(s['text'] for s in line['spans']) for b in selected for line in b['lines'])
 return re.sub(r'\s+',' ',text).strip(' §\t'),[b['bbox'] for b in selected]
def run():
 acquisition=json.loads((EXP/'acquisition.json').read_text());docs={r['language']:r for r in acquisition['documents']};original=[json.loads(l) for l in (PACK/'evidence.jsonl').read_text().splitlines()];existing={r['evidence_id'] for r in original}
 en_doc=fitz.open(PACK/'raw/source_0.pdf');en_hash=hashlib.sha256((PACK/'raw/source_0.pdf').read_bytes()).hexdigest();new=[]
 for lang,mapping in TARGET.items():
  meta=docs[lang];src=ROOT/meta['path'];assert hashlib.sha256(src.read_bytes()).hexdigest()==meta['sha256'];dest=PACK/'raw'/('expansion_'+lang+'.pdf');shutil.copyfile(src,dest);doc=fitz.open(dest)
  for (ep,ei),(tp,ti) in zip(EN,mapping,strict=True):
   english,eb=extract(en_doc,ep,ei);target,tb=extract(doc,tp,ti);assert english and target
   rid=hashlib.sha256((lang+'|'+english+'|'+target).encode()).hexdigest()[:16];eid='cfpb_remittance:'+lang+':'+rid
   source={'type':'official_parallel_pdf','url':meta['url'],'sha256':meta['sha256'],'file':'raw/'+dest.name,'pdf_page_start':tp,'pdf_page_end':tp,'target_blocks':ti,'target_bboxes':tb,'raw_extracted_target':target,'english_url':'https://files.consumerfinance.gov/f/documents/cfpb_helping-consumers-understand-remittance-transfers.pdf','english_sha256':en_hash,'english_pdf_page':ep,'english_blocks':ei,'english_bboxes':eb,'alignment_method':'same_official_fact_sheet_explicit_heading_map','official_listing_url':acquisition['source_listing'],'license_url':'https://www.consumerfinance.gov/privacy/website-privacy-policy/','license_sha256':json.loads((PACK/'manifest.json').read_text())['usage_terms']['policy_sha256']}
   row={'evidence_id':eid,'dataset_id':'cfpb_remittance','dataset_name':'CFPB official remittance consumer-rights parallel expressions','dataset_version':'20261014-r2','dataset_state':'candidate','source_concept_id':'cfpb_remittance:'+hashlib.sha256(english.encode()).hexdigest()[:16],'source_language':'en','english':english,'target_language':lang,'translation':target,'availability':'present','kind':'financial_heading_or_label','category':'remittance','publisher':'Consumer Financial Protection Bureau','jurisdiction':'US','review_status':'ai_source_heading_alignment','human_review':False,'context_required':True,'commercial_use':True,'license':'CFPB-created public-domain information; third-party exceptions apply','source':source,'quality_flags':['contextual_official_parallel_text_not_expert_translation_benchmark'],'usage_terms':json.loads((PACK/'manifest.json').read_text())['usage_terms'],'definition':None}
   if eid not in existing:new.append(row);existing.add(eid)
 rows=original+new;assert len(new) in (0,50)
 (PACK/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 manifest=json.loads((PACK/'manifest.json').read_text());manifest.update(dataset_version='20261014-r2',entry_count=len(rows),language_counts=dict(collections.Counter(r['target_language'] for r in rows)))
 manifest['adoption_review']['expansion_check']='Official listing, PDF hashes, explicit heading maps, and embedded CFPB publication identity checked by AI; no human translation approval.'
 manifest['files_sha256']['evidence.jsonl']=hashlib.sha256((PACK/'evidence.jsonl').read_bytes()).hexdigest()
 for lang in TARGET:
  path=PACK/'raw'/('expansion_'+lang+'.pdf');manifest['files_sha256']['raw/'+path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
 (PACK/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
 exclusions=[{'language':'zh-Hant','page':1,'blocks':[1],'source_title':'協助消費者瞭解貸款歧視','reason':'Title says loan discrimination, not remittance; excluded rather than silently corrected.'},{'language':'vi','page':1,'blocks':[12],'source_heading':'Các hình thức chuyển tiền được luật bảo vệ','reason':'Uncovered-transfer section repeats covered heading; excluded rather than silently corrected.'}]
 report={'new_pairs':len(new),'total_pack_pairs':len(rows),'languages':dict(collections.Counter(r['target_language'] for r in new)),'alignment_maps':{'english':EN,'target':TARGET},'excluded_heading_candidates':exclusions,'human_translation_approval':False,'frozen_cfpd_modified':False,'commercial_policy_basis':manifest['usage_terms']}
 (EXP/'adoption-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':run()
