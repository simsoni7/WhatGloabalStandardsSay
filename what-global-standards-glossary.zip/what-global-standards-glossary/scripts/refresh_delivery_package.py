"""Refresh generated delivery without modifying frozen source datasets."""
from pathlib import Path
import zipfile,json,hashlib,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[1]
def refresh():
 p=ROOT/'dist/what-global-standards-glossary.zip';tmp=p.with_suffix('.refresh.zip')
 updates=['glossary_app/index.py','datasets/derived/reference_index.sqlite','datasets/derived/reference_index_manifest.json','evaluation/results.json','evaluation/cases.json','evaluation/parallel_source_smoke.json','tests/test_application.py','scripts/build_nepal_documents.py','scripts/export_delivery_data.py','scripts/refresh_delivery_package.py','scripts/probe_nepal_official.py','docs/nepal-expansion.md','datasets/nepal_official/candidate/probe.json']
 folder=ROOT/'datasets/nepalbank/candidate/document-expansion'
 updates += [str(f.relative_to(ROOT)) for f in folder.iterdir() if f.suffix in ['.pdf','.txt','.json','.tsv']]
 for name in ['docs/language-market-research.md','docs/language-pack-adoption.md','docs/commercial-source-adoption.md','scripts/export_commercial_data.py','scripts/collect_cfpb_new.py','scripts/collect_canada.py','scripts/collect_philippines.py','scripts/collect_arabic.py','scripts/collect_eu.py','tests/test_language_packs.py']:
  if (ROOT/name).exists():updates.append(name)
 packs=ROOT/'datasets/language_packs'
 if (packs/'registry.json').exists():
  updates += [str(f.relative_to(ROOT)) for f in packs.rglob('*') if f.is_file() and (f.suffix in ['.pdf','.txt','.json','.jsonl','.tsv','.csv','.md','.html','.gz','.yaml','.gc','.xml'] or f.name in ['LICENSE','NOTICE','COPYING'])]
 research=ROOT/'datasets/research_candidates'
 if research.exists():
  updates += [str(f.relative_to(ROOT)) for f in research.rglob('*') if f.is_file() and (f.suffix in ['.json','.md','.html','.po'] or f.name in ['LICENSE','TERMS'])]
 collection=ROOT/'datasets/source_collection'
 if collection.exists():
  updates += [str(f.relative_to(ROOT)) for f in collection.rglob('*') if f.is_file() and (f.suffix in ['.pdf','.txt','.json','.jsonl','.md','.html','.gz','.yaml','.gc','.xml','.csv'] or f.name in ['LICENSE','TERMS'])]
 prefix='what-global-standards-glossary/'
 with zipfile.ZipFile(p) as a,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as b:
  for i in a.infolist():
   if i.filename[len(prefix):] not in updates and i.filename!=prefix+'NEPAL-UPDATE.md':b.writestr(i,a.read(i.filename))
  for name in updates:b.write(ROOT/name,prefix+name)
  b.writestr(prefix+'NEPAL-UPDATE.md',(ROOT/'docs/nepal-expansion.md').read_text())
 with tempfile.TemporaryDirectory() as t:
  with zipfile.ZipFile(tmp) as z:assert z.testzip() is None;z.extractall(t);count=len(z.namelist())
  r=subprocess.run(['python3','-m','evaluation.run'],cwd=Path(t)/prefix,capture_output=True,text=True);assert r.returncode==0,r.stderr;print(r.stdout)
 tmp.replace(p);catalog=json.loads((ROOT/'dist/data/catalog.json').read_text());m=json.loads((ROOT/'dist/delivery.json').read_text());m.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,file_count=count,nepal_entries=catalog['counts_by_language']['ne'],data_entries=catalog['entry_count'],target_languages=catalog['languages'],reference_language_packs=catalog.get('reference_language_packs',[]),benchmarks=catalog.get('benchmarks',[]),release_date='2026-10-14');(ROOT/'dist/delivery.json').write_text(json.dumps(m,indent=2)+'\n')
 files=['glossaries-data.zip','what-global-standards-glossary.zip','delivery.json','data/catalog.json']
 if (ROOT/'dist/commercial-language-packs.zip').exists():files.append('commercial-language-packs.zip')
 (ROOT/'dist/SHA256SUMS').write_text(''.join(hashlib.sha256((ROOT/'dist'/f).read_bytes()).hexdigest()+'  '+('catalog.json' if f=='data/catalog.json' else f)+'\n' for f in files));print(json.dumps(m))
if __name__=='__main__':refresh()
