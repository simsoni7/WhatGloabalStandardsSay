# CFPB 신규 언어 송금 참고팩 수집

2026-10-14: 정상 HTTPS로 공식 PDF 영어·아랍어·아이티 크리올어·타갈로그 4개를 실제 확보했다. 이전 환경의 CDN403은 이번 수집에서 발생하지 않았다. 비공식 미러, 인증 우회, 생성 번역은 사용하지 않았다.

- evidence.jsonl: 86개 대응 후보, ar 16 / ht 35 / tl 35.
- acquisition.json: 원문 URL, HTTP200, SHA256, 원문 파일 경로.
- raw/source_0.pdf: 영어, source_1.pdf: 아랍어, source_2.pdf: 아이티 크리올어, source_3.pdf: 타갈로그.
- raw/source_4.html: 공식 저작권·상표 정책. raw/source_5.html: 4개 공식 PDF 링크를 함께 제공한 CFPB 발표.
- raw/*.txt: PDF 순서 보존 추출 텍스트. raw/*_page_*.png: 원문 렌더링.
- scripts/collect_cfpb_new.py: 명시적으로 점검한 섹션 매핑을 재실행.

## 상업 이용 근거
공식 정책 https://www.consumerfinance.gov/privacy/website-privacy-policy/ 의 Website content 항목:
“Information created by the CFPB is in the public domain and you may reproduce, publish, or otherwise use it without the Bureau’s permission.”
CFPB 자체 제작 자료의 재사용·상업 이용이 가능하다. 제3자 저작물 예외와 기관 상표는 별개이며, 용어팩은 CFPB 승인/보증을 주장하지 않는다. 원문 PDF를 참고 원본으로 보존하고 기관명은 출처 표시로 사용한다.

## 대응 근거 및 적용 한계
공식 발표가 영어·해당 언어 PDF를 같은 remittance fact sheet의 번역으로 제시한다. PDF의 동일 제목·소제목·목록·송금 조항을 명시적으로 매핑했다. 단순 배열 순서 전체를 자동 연결하지 않았다. record에 양쪽 PDF URL·SHA·페이지·블록·bbox를 보존했다. source_concept_id는 cfpb_remittance namespace다.

이 자료는 미국 송금권리 설명의 공식 병행 문장과 표제이며 폭넓은 용어사전도 전문가 번역정답 benchmark도 아니다. 영어판 11/2021, 번역판 12/2021이며 2026년 법적 최신성을 보장하지 않는다. target 원문에 문체 차이, 설명 축약, 원문 오타가 있으므로 실제 문장검수 정답으로 쓰기 전 별도 전문가 검토가 필요하다.

아랍어 PDF는 RTL·폰트 인코딩으로 lam/alef와 숫자 순서가 잘못 추출된다. 아랍어 전체 문장은 채택 제안에서 제외하고 이미지 2페이지를 직접 확인해 짧은 제목·목록 16개만 원문 전사했다. raw_extracted_target 및 원본 이미지와 bbox를 함께 보존한다. “51/005/03/081/09”를 자동 숫자 교정한 아랍어 문장은 만들지 않았다. 첫 소개문에는 다른 주제의 삽입문이 실제로 포함되어 있어 해당 문장도 제외했다.

아이티·타갈로그 문장 35개씩은 section-level 병행 참고 후보다. 특히 타갈로그는 영어보다 일부 문장을 축약/의역하며: 비용 표제는 'saktong halaga ng padala', 오류 안내는 'humingi ng tulong'으로 표현한다. 숫자30/180/90/500/$15는 보존되지만 예약 취소 설명은 영어의 business days가 타갈로그에서 단순 araw로 표현되어 **정밀 법률 번역 benchmark로 채택해서는 안 된다**. 이 section은 추가 품질 flag로 표시한다. 모든 레코드 human_review false, candidate 상태다. 짧은 용어·표제와 병행문장을 구분하여 도입 검토해야 한다.
