# Attribution and usage

CFPB-created reference material: public domain under the captured official CFPB policy. No endorsement is implied; trademarks and third-party works are not licensed by that policy.

Canadian government financial reporting labels and currency names: open-data/ckanext-canada, MIT. Retain the original copyright and license supplied under sources/.

EU CPV financial and insurance service labels: Publications Office of the European Union, OP-TED/eForms-SDK, CC BY 4.0. Division 66 selected; English-fallback Irish labels excluded. Original labels retained. Attribute this source and identify further changes. The original license and source are supplied under sources/.

These records are candidate references. Commercial-use permission does not establish linguistic accuracy or suitability in a different financial jurisdiction. Mongolia and Nepal legacy data are excluded because commercial redistribution conditions have not been verified.
