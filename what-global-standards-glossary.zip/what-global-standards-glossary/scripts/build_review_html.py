"""Compatibility entry point for the read-only financial dictionary."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def fingerprint(r):
    return hashlib.sha256(json.dumps({k:r.get(k) for k in ('evidence_id','dataset_id','dataset_version','source_concept_id','source_english','source_target','target_language','definition','source')},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def build():
    # Keep historical download/build names, delivering the current read-only UI.
    from build_dictionary_html import build as build_dictionary
    import shutil
    build_dictionary()
    shutil.copyfile(ROOT/'dist/financial-dictionary.html',ROOT/'dist/financial-review.html')
    shutil.copyfile(ROOT/'dist/financial-dictionary.zip',ROOT/'dist/financial-review-workbench.zip')
if __name__=='__main__':build()
