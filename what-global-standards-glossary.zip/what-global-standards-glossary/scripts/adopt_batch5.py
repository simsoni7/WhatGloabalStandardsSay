"""Import hash-bound reviewed sources; keep copyleft derivatives in separate source files."""
import collections,hashlib,json,pathlib,shutil,sys
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from glossary_app.expansion_review import reviewed_inputs
from glossary_app.preprocess import preprocess

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write_json(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2))
def adapt(raw):
 r=dict(raw);r['english']=r.get('english',r.get('source_english'));r['translation']=r.get('translation',r.get('source_target'));r['source_language']='en';r['availability']='present';r['kind']=r.get('kind',r.get('record_type','financial_software_ui_label'));r['entry_type']=r.get('entry_type',r['kind']);r['dataset_state']='candidate';r['human_review']=False;r['approved_translation']=None
 if r['dataset_id']=='cfpb_remittance_receipt_labels':
  r['usage_terms']={'commercial_use':True,'license':'CFPB-created public-domain information','attribution_required':False,'license_file':'raw/reuse-policy.html'}
 elif r['dataset_id']=='apache_ofbiz_accounting':
  r['usage_terms']={'commercial_use':True,'license':'Apache-2.0','attribution_required':True,'license_file':'raw/LICENSE','notice_file':'raw/NOTICE'}
 return r

def pack_manifest(base,dataset,rows,terms):
 return {'dataset_id':dataset,'dataset_version':'batch5-reviewed-20261014','decision':'accepted_reference','entry_count':len(rows),'language_counts':dict(collections.Counter(r['target_language'] for r in rows)),'usage_terms':terms,'adoption_review':{'type':'independent_ai_source_review','human_review':False,'semantic_approval':False},'files_sha256':{str(f.relative_to(base)):digest(f) for f in base.rglob('*') if f.is_file() and f.name!='manifest.json'}}
def run():
 grouped=collections.defaultdict(list);decisions={}
 for item,rows in reviewed_inputs(ROOT):grouped[item['dataset_id']]+=rows;decisions.setdefault(item['dataset_id'],[]).append(item)
 registry=ROOT/'datasets/language_packs/registry.json';reg=json.loads(registry.read_text());policy_path=registry.parent/'commercial_policy.json';policy=json.loads(policy_path.read_text())
 for dataset in ['cfpb_remittance_receipt_labels','apache_ofbiz_accounting']:
  base=registry.parent/dataset;base.mkdir(exist_ok=True);rows=[adapt(r) for r in grouped[dataset]];assert len({r['evidence_id'] for r in rows})==len(rows)
  if dataset=='apache_ofbiz_accounting':
   src=ROOT/'datasets/source_collection/permissive_finance_batch5';shutil.copytree(src/'raw',base/'raw',dirs_exist_ok=True);terms=rows[0]['usage_terms'];license_path=base/'raw/LICENSE';license_url=rows[0]['source']['license_url']
  else:
   src=ROOT/'datasets/source_collection/banking_expansion_batch5';(base/'raw').mkdir(exist_ok=True)
   for file in src.rglob('*'):
    if file.is_file() and (file.suffix in ['.pdf','.png'] or file.name.startswith('cfpb_') and file.suffix=='.txt'):
     target=base/'observed'/file.relative_to(src);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
   license_path=base/'raw/reuse-policy.html';shutil.copyfile(ROOT/'datasets/language_packs/cfpb_remittance/raw/source_4.html',license_path);license_url='https://www.consumerfinance.gov/privacy/website-privacy-policy/';terms=rows[0]['usage_terms']
  (base/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows));write_json(base/'independent-review.json',{'accepted_inputs':decisions[dataset],'human_review':False,'semantic_approval':False});(base/'README.md').write_text('Source observations only. Source pairing is not expert semantic equivalence. Original source identifiers, financial software/receipt context and license notices retained.\n')
  write_json(base/'manifest.json',pack_manifest(base,dataset,rows,terms))
  if not any(p['dataset_id']==dataset for p in reg['packs']):reg['packs'].append({'dataset_id':dataset,'path':str(base.relative_to(ROOT)),'state':'candidate','decision':'accepted_reference','commercial_use':True})
  if dataset not in policy['approved_dataset_ids']:policy['approved_dataset_ids'].append(dataset);policy['evidence'].append({'dataset_id':dataset,'policy_url':license_url,'policy_snapshot':str(license_path.relative_to(ROOT)),'policy_sha256':digest(license_path),'attribution_review':str((base/'independent-review.json').relative_to(ROOT))})
 write_json(registry,reg);write_json(policy_path,policy)
 community_root=ROOT/'datasets/community_language_packs';community_root.mkdir(exist_ok=True);creg={'format_version':1,'scope':'Separate copyleft source observations; not included in core commercial JSONL/API by default','packs':[]}
 output=ROOT/'dist/community';output.mkdir(exist_ok=True)
 for dataset,folder in [('gnucash_financial_ui','finance_oss_batch5'),('mifos_financial_ui','finance_oss_batch5/mifos')]:
  base=community_root/dataset;base.mkdir(exist_ok=True);src=ROOT/'datasets/source_collection'/folder
  shutil.copytree(src/'raw',base/'raw',dirs_exist_ok=True)
  if dataset=='mifos_financial_ui':shutil.copytree(ROOT/'datasets/source_collection/finance_oss_batch5/mifos_next_batch/raw',base/'raw',dirs_exist_ok=True)
  for file in ['MODIFICATIONS.md','README.md','SOURCE-NOTICE.md']:
   if (src/file).exists():shutil.copyfile(src/file,base/file)
  raw_rows=[adapt(r) for r in grouped[dataset]];rows=preprocess([(r,r['source_concept_id'],True) for r in raw_rows])[0];blocked=set();reasons={}
  for item in decisions[dataset]:
   blocked.update(item.get('generation_block_ids',[]))
   for caution in item.get('semantic_cautions',[]):
    for eid in caution['evidence_ids']:reasons[eid]=caution['reason']
  canonical=[]
  for r,_,_ in rows:
   r.update(reference_layer='conditional_copyleft',generation_eligible=False,generation_safety_assessed=False,generation_policy_reason='community_copyleft_context_requires_explicit_validation',approved_translation=None,semantic_review={'status':'unreviewed','human_review':False},source_notes=['Community financial-software observation; not a bank standard or expert translation. Automatic generation is disabled by default.'])
   if r['evidence_id'] in blocked:r['equivalence_status']='needs_review';r['source_notes'].append(reasons.get(r['evidence_id'],'Source wording scope mismatch suspected; do not use as confirmed translation.'));r['quality_flags'].append({'issue_type':'source_meaning_scope_quarantine','priority':'high','human_review':False})
   canonical.append(r)
  (base/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in raw_rows));(base/'reference-v2.json').write_text(json.dumps(canonical,ensure_ascii=False,separators=(',',':')))
  write_json(base/'independent-review.json',{'accepted_inputs':decisions[dataset],'human_review':False,'semantic_approval':False});shutil.copyfile(ROOT/'scripts/collect_finance_oss_batch5.py',base/'collect_finance_oss_batch5.py');(base/'SCOPE.md').write_text('This component retains its upstream GPL or MPL license, full source-localization files and change notices. No blanket licensing of unrelated datasets. Observations are not expert-approved financial translations; all model generation is disabled by default.\n')
  terms=raw_rows[0]['usage_terms'];manifest=pack_manifest(base,dataset,raw_rows,terms);write_json(base/'manifest.json',manifest);shutil.copyfile(base/'reference-v2.json',output/(dataset+'.json'))
  creg['packs'].append({'dataset_id':dataset,'path':str(base.relative_to(ROOT)),'entry_count':len(canonical),'language_counts':manifest['language_counts'],'usage_terms':terms,'reference_file':dataset+'.json','reference_sha256':digest(base/'reference-v2.json'),'source_archive':'community-reference-packs.zip','named_semantic_cautions':len(blocked)})
 write_json(community_root/'registry.json',creg);write_json(output/'catalog.json',creg)
 print(json.dumps({'core_added':sum(len(grouped[k]) for k in ['cfpb_remittance_receipt_labels','apache_ofbiz_accounting']),'community_added':sum(p['entry_count'] for p in creg['packs']),'community_packs':creg['packs']},ensure_ascii=False))
if __name__=='__main__':run()
