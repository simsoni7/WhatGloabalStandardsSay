# Extraction notice

2026-10-14: Selected short financial UI labels from MifosX Community App English and Khmer/Vietnamese JSON locales by same explicit key. Original strings unchanged. Selection/JSON evidence formatting is a modification. Complete original files with contributor metadata, MPL-2.0 LICENSE, README and package metadata retained. This source pack remains separate from unrelated reference sources. No expert translation approval.
