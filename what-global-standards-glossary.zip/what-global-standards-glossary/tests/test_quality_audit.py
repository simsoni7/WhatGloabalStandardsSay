import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from audit_candidates import numbers
from reference_glossaries import retrieve


class QualityAuditTests(unittest.TestCase):
    def test_devanagari_numerals_are_compared_as_values(self):
        self.assertEqual(numbers('NPR 500; 4 digits'),numbers('रु. ५००; ४ अंक'))
        self.assertNotEqual(numbers('NPR 500'),numbers('रु. १०००'))

    def test_flags_are_attached_to_source_evidence(self):
        pointer=json.loads((ROOT/'datasets/quality_audits/latest.json').read_text())
        issues=json.loads((ROOT/pointer['path']/'issues.json').read_text())
        item=next(i for i in issues if i['issue_type']=='mixed_script_english')
        result=retrieve(item['details']['english'],'mn',dataset_id='mongolbank',include_candidates=True)
        evidence=next(r for r in result['evidence'] if r['evidence_id'] in item['evidence_ids'])
        self.assertTrue(any(f['issue_type']=='mixed_script_english' for f in evidence['quality_flags']))
        self.assertEqual(evidence['review_status'],'unreviewed')
        self.assertEqual(evidence['quality_audit_status'],'triaged_not_reviewed')
        self.assertIsNone(result['contextual_verdict'])

    def test_lexical_links_do_not_claim_concept_equivalence(self):
        import csv
        pointer=json.loads((ROOT/'datasets/quality_audits/latest.json').read_text())
        with (ROOT/pointer['path']/'english_match_candidates.csv').open(encoding='utf-8-sig') as f:
            rows=list(csv.DictReader(f))
        self.assertTrue(rows)
        self.assertTrue(all(r['concept_status']=='unverified' for r in rows))
        self.assertTrue(all(r['match_method']=='english_spelling_only' for r in rows))


if __name__=='__main__':unittest.main()
