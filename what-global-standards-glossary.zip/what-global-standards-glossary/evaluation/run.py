import argparse,json
from datetime import datetime,timezone
from pathlib import Path
from glossary_app.engine import Engine

ROOT=Path(__file__).resolve().parents[1]


def run():
    engine=Engine();rows=[]
    for case in json.loads((ROOT/'evaluation/cases.json').read_text()):
        result=engine.process(case['request']);failures=[]
        for expected,actual in [('expected_status','status'),('expected_translation','translated_text'),('expected_source_quote','source_quoted_text'),
                                ('expected_comparison','source_comparison'),('expected_generated_expression','generated_expression')]:
            if expected in case and result.get(actual)!=case[expected]:failures.append(actual)
        rows.append({'id':case['id'],'passed':not failures,'failed_fields':failures,
                     'actual_status':result['status'],'citations':[e['evidence_id'] for e in result['evidence']],
                     'result':result})
    return {'executed_at':datetime.now(timezone.utc).isoformat(),'scope':'functional_reference_workflow_not_translation_accuracy',
            'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),
            'total':len(rows),'live_model_validation':'not_performed_model_unavailable','cases':rows}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=ROOT/'evaluation/results.json')
    args=p.parse_args();result=run();args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['scope','passed','failed','total','live_model_validation']}))
    raise SystemExit(1 if result['failed'] else 0)
