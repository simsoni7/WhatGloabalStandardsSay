import http.server,threading,functools,pathlib,json
from playwright.sync_api import sync_playwright,expect
root=pathlib.Path(__file__).resolve().parents[1]
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(root/'dist')));threading.Thread(target=server.serve_forever,daemon=True).start()
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=browser.new_page(viewport={'width':1440,'height':1000});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(f'http://127.0.0.1:{server.server_port}/financial-dictionary.html',wait_until='load')
 assert page.locator('#rows tr').count()==50
 expect(page.locator('#resultCount')).to_contain_text('16,857')
 assert page.locator('#language option').count()==33
 assert page.locator('textarea').count()==0
 for forbidden in ['reviewer','save','export','import','decision','note','context']:
  assert page.locator('#'+forbidden).count()==0
 page.locator('#language').select_option('km');expect(page.locator('#resultCount')).to_contain_text('166');page.locator('#q').fill('រៀលកម្ពុជា');expect(page.locator('#rows')).to_contain_text('Cambodian Riel');page.locator('#clear').click()
 page.locator('#language').select_option('ko');expect(page.locator('#resultCount')).to_contain_text('2,027');expect(page.locator('#activeLanguage')).to_contain_text('한국어 금융용어사전')
 page.locator('#q').fill('Interest');expect(page.locator('#resultCount')).not_to_contain_text('2,027')
 page.locator('#rows button').first.click();expect(page.locator('#detail')).to_contain_text('수집·대응 방법')
 page.locator('#clear').click();page.locator('#rights').select_option('allowed');expect(page.locator('#resultCount')).to_contain_text('13,042')
 page.locator('[data-view="statistics"]').click();expect(page.locator('#filteredStats')).to_contain_text('13,042')
 page.locator('#languageSearch').fill('네팔');assert page.locator('#languageList button').count()==1
 page.locator('#languageList button').click();expect(page.locator('#resultCount')).to_contain_text('171');assert page.locator('#rights').input_value()==''
 page.locator('#pageSize').select_option('25');assert page.locator('#rows tr').count()==25
 first=page.locator('#rows button').first.inner_text();page.locator('#next').click();assert page.locator('#rows button').first.inner_text()!=first
 page.locator('[data-view="sources"]').click();assert page.locator('#sourceCards article').count()==7;expect(page.locator('#sourceCards')).to_contain_text('상업적 재사용')
 page.locator('[data-view="expansion"]').click();assert page.locator('#candidateRows tr').count()==16;expect(page.locator('#researchSummary')).to_contain_text('채택은0개')
 page.locator('[data-view="dictionary"]').click();page.locator('#clear').click();page.locator('#language').select_option('mn');page.locator('#q').fill('Interest Rate');expect(page.locator('#resultCount')).not_to_contain_text('3,644');page.locator('#rows button').first.click();page.screenshot(path='/tmp/dictionary-desktop.png',full_page=True)
 page.set_viewport_size({'width':390,'height':844});page.locator('#rows button').first.click();expect(page.locator('#detail')).to_contain_text('몽골은행');page.screenshot(path='/tmp/dictionary-mobile.png',full_page=True)
 page.locator('#q').fill('not-found-fixture-string');expect(page.locator('#resultCount')).to_contain_text('0쌍');expect(page.locator('#rows')).to_contain_text('검색 결과가 없습니다')
 assert not errors,errors
 assert page.evaluate('localStorage.length')==0
 browser.close()
print('PASS: 32 Korean language filters, search, pagination, details, source descriptions, statistics, commercial subset, language directory, expansion, no review controls/storage, mobile, no browser errors')
