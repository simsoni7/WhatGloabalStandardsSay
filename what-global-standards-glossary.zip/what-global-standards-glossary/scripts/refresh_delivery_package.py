"""Refresh generated delivery without modifying frozen source datasets."""
from pathlib import Path
import zipfile,json,hashlib,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[1]
def refresh():
 p=ROOT/'dist/what-global-standards-glossary.zip';tmp=p.with_suffix('.refresh.zip')
 updates=['RUN.md','glossary_app/index.py','glossary_app/preprocess.py','glossary_app/engine.py','glossary_app/model.py','datasets/derived/reference_index.sqlite','datasets/derived/reference_index_manifest.json','evaluation/results.json','evaluation/run.py','evaluation/cases.json','evaluation/parallel_source_smoke.json','tests/test_application.py','tests/test_preprocessing.py','docs/integration-v2.md','scripts/build_nepal_documents.py','scripts/export_delivery_data.py','scripts/refresh_delivery_package.py','scripts/probe_nepal_official.py','docs/nepal-expansion.md','datasets/nepal_official/candidate/probe.json']
 updates += [str(f.relative_to(ROOT)) for f in (ROOT/'datasets/derived/integration').iterdir() if f.is_file()]
 updates += ['glossary_app/semantic_review.py','docs/semantic-review.md']
 updates += ['glossary_app/enrichment.py','glossary_app/server.py','tests/test_enrichment.py','evaluation/context_run.py','evaluation/context_results.json','scripts/diagnose_dataset.py','docs/dataset-development-plan.md','docs/dataset-quality-diagnosis.md','docs/financial-information-model.md','docs/context-evaluation-scope.md','docs/enrichment-review.md']
 updates += ['scripts/build_dictionary_html.py','scripts/expand_cfpb_remittance.py','scripts/collect_unicode_currencies.py','scripts/smoke_dictionary_ui.py','dictionary/template.html','dictionary/sources.json','docs/financial-dictionary.md','docs/financial-dictionary-expansion.md','docs/kh-vi-ru-collection.md','dist/financial-dictionary.html','dist/financial-dictionary.zip' ]
 updates += ['evaluation/enrichment_http_results.json','scripts/build_review_html.py','scripts/import_financial_reviews.py','docs/financial-review-workbench.md','dist/financial-review.html']
 updates += [str(f.relative_to(ROOT)) for f in (ROOT/'datasets/expansion_research').glob('*.json') if f.is_file() and f.name != 'document-inspection.json']
 updates += [str(f.relative_to(ROOT)) for f in (ROOT/'datasets/enrichment').rglob('*') if f.is_file()]
 updates += [str(f.relative_to(ROOT)) for f in (ROOT/'datasets/derived/semantic_review').iterdir() if f.is_file()]
 folder=ROOT/'datasets/nepalbank/candidate/document-expansion'
 updates += [str(f.relative_to(ROOT)) for f in folder.iterdir() if f.suffix in ['.pdf','.txt','.json','.tsv']]
 for name in ['docs/language-market-research.md','docs/language-pack-adoption.md','docs/commercial-source-adoption.md','scripts/export_commercial_data.py','scripts/collect_cfpb_new.py','scripts/collect_canada.py','scripts/collect_philippines.py','scripts/collect_arabic.py','scripts/collect_eu.py','tests/test_language_packs.py']:
  if (ROOT/name).exists():updates.append(name)
 packs=ROOT/'datasets/language_packs'
 if (packs/'registry.json').exists():
  updates += [str(f.relative_to(ROOT)) for f in packs.rglob('*') if f.is_file() and (f.suffix in ['.pdf','.txt','.json','.jsonl','.tsv','.csv','.md','.html','.gz','.yaml','.gc','.xml'] or f.name in ['LICENSE','NOTICE','COPYING'])]
 research=ROOT/'datasets/research_candidates'
 if research.exists():
  updates += [str(f.relative_to(ROOT)) for f in research.rglob('*') if f.is_file() and (f.suffix in ['.json','.md','.html','.po'] or f.name in ['LICENSE','TERMS'])]
 collection=ROOT/'datasets/source_collection'
 if collection.exists():
  updates += [str(f.relative_to(ROOT)) for f in collection.rglob('*') if f.is_file() and (f.suffix in ['.pdf','.txt','.json','.jsonl','.md','.html','.gz','.yaml','.gc','.xml','.csv'] or f.name in ['LICENSE','TERMS'])]
 updates += ['glossary_app/expansion_review.py','scripts/adopt_batch5.py','scripts/export_community_sources.py','docs/community-reference-policy.md']
 updates += [str(f.relative_to(ROOT)) for f in (ROOT/'datasets/community_language_packs').rglob('*') if f.is_file()]
 updates += [str(f.relative_to(ROOT)) for f in collection.rglob('*') if f.is_file() and (f.suffix in ['.po','.png'] or f.name in ['NOTICE','COPYING'])]
 for name in ['scripts/collect_banking_expansion_batch5.py','scripts/collect_finance_oss_batch5.py','scripts/collect_permissive_finance_batch5.py','scripts/collect_banking_batch6.py','docs/banking-expansion-batch5.md','docs/finance-oss-batch5.md','docs/permissive-finance-batch5.md','docs/banking-batch6.md']:
  if (ROOT/name).exists():updates.append(name)
 updates += ['scripts/test_dictionary_delivery.py']
 updates += ['glossary_app/korean_labels.py','scripts/build_korean_labels.py','scripts/adopt_batch7.py','scripts/build_email_dictionary.py','scripts/collect_batch7_asia.py','scripts/collect_batch7_permissive.py','docs/batch7-asian-official.md','docs/korean-search-aids.md']
 updates += ['scripts/adopt_batch8.py','scripts/collect_batch8_malaysia.py','docs/batch8-malaysia.md','scripts/monitor_glossary_sources.py','tests/test_korean_context.py']
 updates=[name for name in dict.fromkeys(updates) if not name.startswith('datasets/source_collection/batch7_asia/raw/') and not name.startswith('datasets/source_collection/batch7_official/') and not name.startswith('datasets/source_collection/batch8_remaining/')]

 prefix='what-global-standards-glossary/'
 with zipfile.ZipFile(p) as a,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as b:
  for i in a.infolist():
   if i.filename[len(prefix):] not in updates and i.filename not in [prefix+'NEPAL-UPDATE.md',prefix+'reviewer/template.html']:b.writestr(i,a.read(i.filename))
  for name in updates:b.write(ROOT/name,prefix+name)
  b.writestr(prefix+'NEPAL-UPDATE.md',(ROOT/'docs/nepal-expansion.md').read_text())
 with tempfile.TemporaryDirectory() as t:
  with zipfile.ZipFile(tmp) as z:assert z.testzip() is None;z.extractall(t);count=len(z.namelist())
  r=subprocess.run(['python3','-m','evaluation.run'],cwd=Path(t)/prefix,capture_output=True,text=True);assert r.returncode==0,r.stderr;print(r.stdout)
 tmp.replace(p);catalog=json.loads((ROOT/'dist/data/catalog.json').read_text());m=json.loads((ROOT/'dist/delivery.json').read_text());m.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,file_count=count,nepal_entries=catalog['counts_by_language']['ne'],data_entries=catalog['entry_count'],target_languages=catalog['languages'],reference_language_packs=catalog.get('reference_language_packs',[]),benchmarks=catalog.get('benchmarks',[]),release_date='2026-10-14',dictionary_ui={'mode':'read_only','target_language_labels':'Korean','entry_count':catalog['entry_count'],'target_languages':len(catalog['languages']),'source_datasets':len(catalog['counts_by_dataset']),'review_controls':False,'expansion_candidate_groups':16,'newly_adopted_pairs':743});(ROOT/'dist/delivery.json').write_text(json.dumps(m,indent=2)+'\n')
 files=['financial-dictionary.zip','financial-dictionary.html','financial-review-workbench.zip','financial-review.html','glossaries-data.zip','what-global-standards-glossary.zip','delivery.json','data/catalog.json']
 if (ROOT/'dist/commercial-language-packs.zip').exists():files.append('commercial-language-packs.zip')
 if (ROOT/'dist/conditional-community-language-packs.zip').exists():files.append('conditional-community-language-packs.zip')
 (ROOT/'dist/SHA256SUMS').write_text(''.join(hashlib.sha256((ROOT/'dist'/f).read_bytes()).hexdigest()+'  '+('catalog.json' if f=='data/catalog.json' else f)+'\n' for f in files));print(json.dumps(m))
if __name__=='__main__':refresh()
