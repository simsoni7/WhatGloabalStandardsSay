"""Generate a self-contained, read-only financial dictionary from immutable source pairs."""
import collections,hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
LANGUAGES={'ar':'아랍어','bg':'불가리아어','cs':'체코어','da':'덴마크어','de':'독일어','el':'그리스어','en':'영어','es':'스페인어','et':'에스토니아어','fi':'핀란드어','fr':'프랑스어','hr':'크로아티아어','ht':'아이티 크리올어','hu':'헝가리어','it':'이탈리아어','ko':'한국어','lt':'리투아니아어','lv':'라트비아어','mn':'몽골어','mt':'몰타어','ne':'네팔어','nl':'네덜란드어','pl':'폴란드어','pt':'포르투갈어','ro':'루마니아어','ru':'러시아어','sk':'슬로바키아어','sl':'슬로베니아어','sv':'스웨덴어','tl':'타갈로그어','vi':'베트남어','zh-Hant':'중국어 (번체)'}
def build():
 source=ROOT/'dist/data/glossary_entries.jsonl';rows=[]
 for r in map(json.loads,source.open()):
  row={k:r.get(k) for k in ('evidence_id','dataset_id','dataset_version','source_concept_id','source_english','source_target','target_language','jurisdiction','record_type','definition','source','alignment_basis','alignment_status')}
  row['source_notes']=[]
  if r.get('generation_eligible') is False:
   row['source_notes'].append('원문 표제어와 정의의 불일치가 의심되는 항목입니다. 원문 표기는 보존하며 일반 번역의 확정 근거로 사용하지 않습니다.')
  semantic=r.get('semantic_review') or {}
  if semantic.get('source_definition_scope_suspicion'):
   row['source_notes'].append('원문 정의의 범위에 관한 AI 분석상 의문이 있습니다. '+str(semantic.get('usage_constraint','')))
  rows.append(row)
 sources=json.loads((ROOT/'dictionary/sources.json').read_text())
 for entry in sources:
  if entry['dataset_id']=='canada_government_financial_labels':
   entry['license_notice']=(ROOT/'datasets/source_collection/canada/raw/LICENSE').read_text()
   entry['attribution']='Contains unchanged bilingual labels from Government of Canada Open Data / ckanext-canada, commit 779f849146a029e62f409ccff1f3bbc7b7cbc319. Crown Copyright, Government of Canada. MIT License; trademarks excluded.'
  if entry['dataset_id']=='eu_cpv_financial_services':
   entry['license_notice']=(ROOT/'datasets/source_collection/eu/raw/LICENSE').read_text()
   entry['attribution']='Contains CPV labels from the Publications Office of the European Union, OP-TED/eForms-SDK, commit 41adbdae8030f3f557845d477ace04310e1cc01a, CC BY 4.0. Division 66 selected and English-fallback Irish labels omitted; no labels translated or edited.'
 assert set(r['dataset_id'] for r in rows)==set(s['dataset_id'] for s in sources)
 assert set(r['target_language'] for r in rows)<=LANGUAGES.keys()
 candidates_file=ROOT/'datasets/expansion_research/candidates.json'
 payload={'snapshot':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows,'sources':sources,'languages':LANGUAGES,'candidates':json.loads(candidates_file.read_text()) if candidates_file.exists() else {'candidates':[]},'built_date':'2026-10-14'}
 encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 out=ROOT/'dist/financial-dictionary.html';out.write_text((ROOT/'dictionary/template.html').read_text().replace('__DATA__',encoded))
 with zipfile.ZipFile(ROOT/'dist/financial-dictionary.zip','w',zipfile.ZIP_DEFLATED) as z:
  z.write(out,'financial-dictionary.html');z.write(ROOT/'docs/financial-dictionary.md','README.md')
  z.write(ROOT/'datasets/source_collection/canada/raw/LICENSE','licenses/canada-MIT.txt')
  z.write(ROOT/'datasets/source_collection/eu/raw/LICENSE','licenses/eu-CC-BY-4.0.txt')
  z.writestr('licenses/ATTRIBUTION.txt','\n\n'.join(s.get('attribution','')+'\n'+s['name']+'\n'+'\n'.join(s['urls']) for s in sources))
 print(json.dumps({'rows':len(rows),'target_languages':len(set(r['target_language'] for r in rows)),'html_bytes':out.stat().st_size,'source_snapshot':payload['snapshot']}))
if __name__=='__main__':build()
