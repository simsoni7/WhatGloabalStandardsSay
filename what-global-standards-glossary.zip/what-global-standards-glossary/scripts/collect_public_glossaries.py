"""Free public-page collection via curl with normal TLS verification.

Use certificate-valid apex addresses, preserve source documents, and extract
only unambiguous bilingual labels sharing the same service/product URL.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
import csv
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import sqlite3
import subprocess
import tempfile
from urllib.parse import urlsplit, urljoin
from urllib.robotparser import RobotFileParser

ROOT = Path(__file__).resolve().parents[1]
NEPAL = 'https://nepalbank.com.np'
MOBILE = NEPAL + '/personal/services/mobile-banking'


class Labels(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = defaultdict(set)
        self.href = None
        self.parts = []
        self.locale = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'option' and 'selected' in attrs:
            self.locale = attrs.get('value')
        if tag == 'a':
            self.href = attrs.get('href')
            self.parts = []

    def handle_data(self, text):
        if self.href is not None:
            self.parts.append(text)

    def handle_endtag(self, tag):
        if tag != 'a' or self.href is None:
            return
        url = urlsplit(urljoin(NEPAL, self.href))
        text = ' '.join(''.join(self.parts).split())
        if url.hostname in ('nepalbank.com.np', 'www.nepalbank.com.np') and text:
            self.links[url.path].add(text)
        self.href = None


def fetch(url, target, cookie=None):
    command = ['curl', '--silent', '--show-error', '--location', '--max-time', '30',
               '--proto', '=https', '--proto-redir', '=https', '--output', str(target),
               '--write-out', '%{http_code}\n%{url_effective}']
    if cookie is not None:
        command += ['--cookie', str(cookie), '--cookie-jar', str(cookie)]
    result = subprocess.run(command + [url], capture_output=True, text=True)
    lines = result.stdout.splitlines()
    if result.returncode or len(lines) != 2 or lines[0] != '200':
        raise RuntimeError(f'Public HTTPS request failed for {url}; curl code {result.returncode}, HTTP {lines[0] if lines else "unknown"}')
    return {'requested_url': url, 'final_url': lines[1], 'http_status': 200,
            'file': target.name, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}


def align(english_html, nepali_html):
    en, ne = Labels(), Labels()
    en.feed(english_html)
    ne.feed(nepali_html)
    if en.locale != 'en' or ne.locale != 'np':
        raise ValueError('Language switch was not verified; refusing to align pages.')
    allowed = ('/personal/products/', '/personal/services/',
               '/personal/service-charge/', '/personal/interest-rate/')
    pairs, ambiguous = [], []
    for path in sorted(en.links.keys() & ne.links.keys()):
        if not path.startswith(allowed):
            continue
        if len(en.links[path]) != 1 or len(ne.links[path]) != 1:
            ambiguous.append(path)
            continue
        english, nepali = next(iter(en.links[path])), next(iter(ne.links[path]))
        if not any('\u0900' <= c <= '\u097f' for c in nepali):
            continue
        pairs.append({'english': english, 'nepali': nepali, 'linked_path': path,
                      'alignment_method': 'same_link_target_unique_labels', 'review_status': 'unreviewed'})
    return pairs, ambiguous


def nepal():
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    candidate = ROOT / 'datasets/nepalbank/candidate'
    directory = candidate / 'captures' / stamp
    directory.mkdir(parents=True, exist_ok=False)
    robots = directory / 'robots.txt'
    fetch(NEPAL + '/robots.txt', robots)
    policy = RobotFileParser()
    policy.parse(robots.read_text().splitlines())
    for url in [MOBILE, NEPAL + '/locale/en', NEPAL + '/locale/np']:
        if not policy.can_fetch('GlossaryResearchCollector', url):
            raise RuntimeError('robots.txt disallows the required public path.')
    sources = {}
    for locale, language in [('en', 'en'), ('np', 'ne')]:
        # Separate sessions prevent a previous language cookie contaminating a capture.
        with tempfile.TemporaryDirectory() as tmp:
            cookie = Path(tmp) / 'session.cookies'
            fetch(NEPAL + '/locale/' + locale, Path(tmp) / 'switch.html', cookie)
            file = directory / (language + '.html')
            sources[language] = fetch(MOBILE, file, cookie)
            sources[language].update(language=language, site_locale=locale,
                                     locale_endpoint=NEPAL + '/locale/' + locale)
        print(f'Captured verified HTTPS page: {language}', flush=True)
    pairs, ambiguous = align((directory / 'en.html').read_text(), (directory / 'ne.html').read_text())
    if not pairs:
        raise RuntimeError('No bilingual terminology candidates found.')
    with (directory / 'term_candidates.csv').open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(pairs[0]))
        writer.writeheader()
        writer.writerows(pairs)
    with sqlite3.connect(directory / 'candidate.sqlite') as db:
        db.executescript('''CREATE TABLE term_candidates (
            id INTEGER PRIMARY KEY, english TEXT, nepali TEXT, linked_path TEXT,
            alignment_method TEXT, review_status TEXT);
            CREATE TABLE source_pages (language TEXT PRIMARY KEY, metadata_json TEXT NOT NULL);''')
        db.executemany('INSERT INTO term_candidates VALUES (?,?,?,?,?,?)',
                       [(i, *p.values()) for i, p in enumerate(pairs, 1)])
        db.executemany('INSERT INTO source_pages VALUES (?,?)',
                       [(lang, json.dumps(source, ensure_ascii=False)) for lang, source in sources.items()])
        if db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise RuntimeError('Candidate DB integrity failure.')
    with (directory / 'evidence.jsonl').open('w', encoding='utf-8') as handle:
        for i, pair in enumerate(pairs, 1):
            evidence = {'evidence_id': f'nepalbank:candidate:{stamp}:{i}', 'dataset_id': 'nepalbank',
                        'dataset_name': 'Nepal Bank 영어–네팔어 금융 용례 후보', 'dataset_version': 'candidate-' + stamp,
                        'source_language': 'en', 'english': pair['english'], 'target_language': 'ne',
                        'translation': pair['nepali'], 'availability': 'present', 'review_status': 'unreviewed',
                        'publisher': 'Nepal Bank Limited', 'jurisdiction': 'NP',
                        'source': {'type': 'parallel_bank_service_pages', 'pages': sources,
                                   'linked_path': pair['linked_path'], 'retrieved_at': stamp,
                                   'alignment_method': pair['alignment_method']}}
            handle.write(json.dumps(evidence, ensure_ascii=False) + '\n')
    report = {'status': 'captured', 'scope': 'One service page in two languages; not a whole-site crawl.',
              'pair_count': len(pairs), 'ambiguous_paths_skipped': ambiguous, 'review_status': 'unreviewed',
              'sources': sources, 'tls_verification': 'enabled',
              'files_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in directory.iterdir() if p.is_file()}}
    (directory / 'capture.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    manifest_path = candidate / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    manifest.update(inspection_status='captured_partial', pair_count=len(pairs),
                    pair_structure_verified=True, bilingual_availability='verified_language_sessions',
                    last_capture=str(directory.relative_to(ROOT)), access_url=MOBILE,
                    review_status='unreviewed', collector='curl verified HTTPS',
                    note='Nine or more unique bank labels aligned by shared link targets; candidate, not reviewed glossary.')
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'dataset': 'nepalbank', 'pair_count': len(pairs), 'directory': str(directory)}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', choices=['nepalbank'])
    parser.parse_args()
    nepal()
