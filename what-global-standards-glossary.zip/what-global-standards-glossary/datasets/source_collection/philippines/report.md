# 필리핀 공식 금융 언어팩 수집 결과

조사일: 2026-10-14 (Asia/Seoul).

## 실수집 결과

신규 영어–필리핀어/타갈로그어 쌍 **0건**. 원자료 없는 AI 번역, 제3자 번역 데이터, 검색결과를 도입하지 않았다. `evidence.jsonl`은 의도적으로 비어 있다. 공식 사이트 실제 금융본문과 상업 재배포 조건이 모두 확보되지 않았으므로 `blocked_pending_official_content_and_commercial_permission` 상태다.

## 공식 출처 및 접근

| 출처 | 접근 결과 | 수집 판단 |
|---|---|---|
| BSP https://www.bsp.gov.ph/ 및 https://bsp.gov.ph/ | 환경 HTTPS proxy CONNECT403 | 홈페이지부터 원자료 미확보 |
| BSP 금융교육 후보 경로 https://www.bsp.gov.ph/Pages/InclusiveFinance/FinancialEducation.aspx | 동일 CONNECT403 | 이 경로의 존재/본문도 미확인. 검증된 원본 URL이라고 주장하지 않음 |
| BSP 약관 후보 경로 https://www.bsp.gov.ph/Pages/TermsandConditions.aspx | 동일 CONNECT403 | 상업 재배포 조건 미확보 |
| PDIC https://www.pdic.gov.ph/ | 동일 CONNECT403 | 예금보호 관련 영어·필리핀어 자료 확보 못함 |
| SEC https://www.sec.gov.ph/ | 동일 CONNECT403 | 투자자교육 자료 확보 못함 |
| 공식 관보 https://www.officialgazette.gov.ph/ | 동일 CONNECT403 | 정부저작물 재사용 규정 미확보 |
| 저작권법 참고 https://lawphil.net/statutes/repacts/ra1997/ra_8293_1997.html | 동일 CONNECT403 | 법률원문 확인 못함 |

정상 TLS와 구성된 네트워크만 사용했다. CONNECT403은 기관 서버의 자료부재나 기관 HTTP403을 의미하지 않는다. 네트워크 제한을 우회하지 않았다.

## 대안 실제 조사

GitHub 공개 저장소 검색 https://github.com/search?q=%22Bangko+Sentral%22&type=repositories 는 HTTP200으로 확보했다. 실제 검색 결과 10개는 제3자 교환율 SDK, 연설 추출 코드, 학생 프로젝트, RAG 프로젝트 등이다. 공식 BSP 계정 또는 공식 재게시 금융교육 PDF임을 검증할 수 있는 자료가 없으므로 수집 대체재로 사용하지 않았다. 검색 HTML과 SHA256을 `raw/github_bsp_search.html` 및 `acquisition.json`에 보존했다. 검색페이지가 확보되었어도 금융 레코드는 0건이다.

`https://github.com/bspgovph`와 `https://github.com/BangkoSentral`은 각각 HTTP404였다. 계정명을 추측한 결과이므로 BSP의 GitHub 계정이 없다는 결론으로 확대하지 않는다.

## 도입 조건과 재조사 방향

필리핀 정부기관 자료라고 해서 미국 CFPB와 동일한 상업 재사용 조건이라고 추정하지 않는다. 필리핀 저작권법 정부저작물 규정과 발행기관의 상업적 사용 승인 조건을 원문으로 확인해야 한다. PDF 내부 외부저작물·그림·로고의 조건도 별도로 확인한다. 현재 `commercial_license_verified:false`다.

1. BSP 공식 홈페이지에 접근이 가능해지면 실제 링크를 따라 영어/필리핀어 병기 자료와 동일 시리즈 양언어 문서를 찾는다. guessed URL을 원본확보로 계산하지 않는다.
2. 상업 재배포가 명시적으로 허용되는 자료만 병기 제목/표/문장부터 추출한다. 언어 코드와 기관이 사용하는 Filipino/Tagalog 표기를 함께 보존한다.
3. 동일 파일 병기와 같은 조항번호를 우선한다. 서로 다른 일반 영문/필리핀어 금융교육 문서의 유사문장을 번역 정답쌍으로 단정하지 않는다.
4. 기관 공식 재게시본은 발행기관·실제 수집 URL·PDF SHA256·페이지를 보존하며 저작권 조건을 원 발행기관에 연결한다.
5. 자료관리 에이전트가 상업조건과 명시적 대응을 확인하기 전까지 후보 레코드는 배포 DB에 합치지 않는다.

재현 명령: `python scripts/collect_philippines.py`. 독립적인 결과는 `acquisition.json`에 있다. 기존 동결 용어집·레지스트리·DB·ZIP을 변경하지 않았다.
