#!/usr/bin/env python3
"""Normal HTTPS acquisition diagnostics; no translated data or access-control bypass."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1] / 'datasets/source_collection/arabic'
URLS = [
 'https://www.sama.gov.sa/en-US/Pages/default.aspx',
 'https://www.sama.gov.sa/ar-sa/Pages/default.aspx',
 'https://rulebook.sama.gov.sa/en', 'https://rulebook.sama.gov.sa/ar',
 'https://www.centralbank.ae/en/', 'https://www.qcb.gov.qa/en/',
 'https://www.cbb.gov.bh/', 'https://www.cma.org.sa/en/Pages/default.aspx',
 'https://www.sama.gov.sa/en-US/Pages/TermsOfUse.aspx',
]
def fetch(url):
    row = {'url': url, 'commercial_reuse_status': 'unverified', 'accepted_pairs': 0}
    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            body = response.read()
            digest = hashlib.sha256(body).hexdigest()
            (ROOT / 'raw' / (digest + '.html')).write_bytes(body)
            row.update(status=response.status, final_url=response.url, sha256=digest)
    except Exception as exc:
        row.update(error=str(exc), acquisition_status='blocked_or_unavailable')
    return row
if __name__ == '__main__':
    (ROOT / 'raw').mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        rows = list(pool.map(fetch, URLS))
    (ROOT / 'diagnostics.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    print(json.dumps({'checked': len(rows), 'accepted_pairs': 0}))
