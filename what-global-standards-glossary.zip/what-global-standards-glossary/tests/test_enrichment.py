import unittest,json,hashlib,tempfile
from pathlib import Path
from glossary_app.index import Index
from glossary_app.engine import Engine
from glossary_app.enrichment import accepted_records,commercial_cards

class EnrichmentTests(unittest.TestCase):
 def test_concept_search_ai_origin_not_translation_approval(self):
  out=Engine().process({'operation':'concepts','query':'이자율'})
  self.assertEqual(out['concepts'][0]['concept_id'],'finance:interest_rate');self.assertFalse(out['expert_approved'])
  self.assertEqual(out['concepts'][0]['definition_origin'],'ai_written_explanation')
 def test_wrong_financial_sense_withholds_quote(self):
  out=Engine().process({'operation':'translate','english_term':'Interest','target_language':'ko','dataset_id':'cfpd','financial_concept_id':'finance:interest_rate'})
  self.assertEqual(out['status'],'context_scope_needs_review');self.assertIsNone(out['source_quoted_text'])
 def test_correct_candidate_selection_still_not_approval(self):
  out=Engine().process({'operation':'translate','english_term':'Interest rate','target_language':'ko','dataset_id':'cfpd','financial_concept_id':'finance:interest_rate'})
  self.assertEqual(out['source_quoted_text'],'이자율');self.assertIsNone(out['approved_translation'])
 def test_procurement_context_cannot_auto_fill_consumer_ui(self):
  def model(*args):raise AssertionError('Model must not bypass explicit source-context mismatch')
  out=Engine(model=model).process({'operation':'translate','english_term':'Financial and insurance services','target_language':'fr','dataset_id':'eu_cpv_financial_services','use_case':'consumer_ui','mode':'model'})
  self.assertEqual(out['status'],'context_scope_needs_review');self.assertEqual(out['model_status'],'blocked_context_review');self.assertIsNone(out['source_quoted_text'])
 def test_commercial_cards_filter_unlicensed_definitions(self):
  cards=Index().concept_search('Interest');clean=commercial_cards(cards,{'cfpd','cfpb_remittance','eu_cpv_financial_services','canada_government_financial_labels'})
  self.assertTrue(clean)
  self.assertTrue(all(s['dataset_id']!='mongolbank' for c in clean for s in c['source_evidence']))
  self.assertFalse(any('mongolbank' in x for c in clean for x in c['proposed_source_concept_ids']))
 def test_changed_artifact_requires_independent_re_review(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);base=root/'datasets/enrichment';(base/'review').mkdir(parents=True);file=base/'cards.jsonl';file.write_text('{}\n')
   (base/'review/decisions.json').write_text(json.dumps({'accepted_inputs':[{'kind':'financial_concepts','path':'datasets/enrichment/cards.jsonl','sha256':'not-the-current-hash','accepted_ids':[]}]}))
   with self.assertRaisesRegex(ValueError,'independent re-review'):accepted_records(root,'financial_concepts')
if __name__=='__main__':unittest.main()
