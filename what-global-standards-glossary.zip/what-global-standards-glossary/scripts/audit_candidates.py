"""Build source-linked review queues without modifying original glossary data."""
from collections import defaultdict, Counter
from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import unicodedata

ROOT=Path(__file__).resolve().parents[1]


def key(value):
    return ' '.join(unicodedata.normalize('NFC',value or '').split()).casefold()


def numbers(value):
    normalized=''.join(str(unicodedata.decimal(c)) if c.isdecimal() else c for c in value)
    return re.findall(r'\d+(?:[.,]\d+)*',normalized)


def audit():
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    out=ROOT/'datasets/quality_audits'/stamp;out.mkdir(parents=True)
    runs={};records={};issues=[]
    for dataset in ['mongolbank','nepalbank']:
        manifest=json.loads((ROOT/'datasets'/dataset/'candidate/manifest.json').read_text())
        run=ROOT/manifest['last_crawl'];report=json.loads((run/'report.json').read_text())
        expected=report['files_sha256']['evidence.jsonl']
        if hashlib.sha256((run/'evidence.jsonl').read_bytes()).hexdigest()!=expected:raise ValueError('Source evidence changed')
        runs[dataset]=manifest['last_crawl']
        records[dataset]=[json.loads(line) for line in (run/'evidence.jsonl').read_text().splitlines()]

    def issue(dataset,issue_type,priority,evidence_ids,details):
        issues.append({'dataset_id':dataset,'issue_type':issue_type,'priority':priority,
                       'evidence_ids':evidence_ids,'details':details,'status':'pending',
                       'note':'A review flag is not a finding of mistranslation.'})

    mn=records['mongolbank'];by_english=defaultdict(list);by_pair=defaultdict(list)
    for row in mn:
        by_english[key(row['english'])].append(row)
        by_pair[(key(row['english']),key(row['translation']))].append(row)
        if any('\u0400'<=c<='\u04ff' for c in row['english']):
            issue('mongolbank','mixed_script_english','high',[row['evidence_id']],
                  {'english':row['english'],'mongolian':row['translation'],'action':'Verify source spelling; do not silently correct it.'})
    for english,rows in by_english.items():
        translations={key(r['translation']) for r in rows}
        if len(translations)>1:
            issue('mongolbank','same_english_multiple_translations','high',[r['evidence_id'] for r in rows],
                  {'english_key':english,'variants':[{'translation':r['translation'],'group_id':r['source']['group_id']} for r in rows],
                   'action':'Separate senses by definition/group; do not merge by English spelling.'})
    for (english,mongolian),rows in by_pair.items():
        if len(rows)>1:
            issue('mongolbank','duplicate_pair_multiple_entries','medium',[r['evidence_id'] for r in rows],
                  {'english_key':english,'translation_key':mongolian,
                   'distinct_definitions':len({key(r['definition']['text']) for r in rows}),
                   'group_ids':sorted({r['source']['group_id'] for r in rows}),
                   'action':'Preserve source IDs; determine whether definitions describe the same sense.'})
    for row in records['nepalbank']:
        left,right=numbers(row['english']),numbers(row['translation'])
        if left!=right:
            issue('nepalbank','numeric_tokens_differ','high',[row['evidence_id']],
                  {'english':row['english'],'nepali':row['translation'],'english_numbers':left,'nepali_numbers':right,
                   'action':'Check numeral formatting, omitted values and actual product differences.'})
        if row.get('kind') in ('parallel_passage_candidate','short_expression_candidate'):
            issue('nepalbank','tentative_ordinal_alignment','medium',[row['evidence_id']],
                  {'kind':row['kind'],'english':row['english'],'nepali':row['translation'],
                   'action':'Review semantic correspondence in the original page; equal counts are insufficient.'})
    ne_report=json.loads((ROOT/runs['nepalbank']/'report.json').read_text())
    for path in sorted({r['page_path'] for r in ne_report['unaligned_sections']}):
        issue('nepalbank','unaligned_source_sections','medium',[],{'page_path':path,
              'sections':[s for s in ne_report['unaligned_sections'] if s['page_path']==path],
              'action':'Check language/version differences and fallback alignments; do not force missing passages.'})

    # Lexical links are proposed for later sense alignment, never established concepts.
    cfp=ROOT/'datasets/cfpd/v1/glossary.sqlite'
    with sqlite3.connect(cfp.as_uri()+'?mode=ro',uri=True) as db:
        english_terms={key(en):(identity,en) for identity,en in db.execute('SELECT id,english FROM terms')}
    links=[]
    for row in mn:
        matched=english_terms.get(key(row['english']))
        if matched:
            links.append({'english':row['english'],'cfpd_version':'v1','cfpd_term_id':matched[0],
                          'mongolbank_evidence_id':row['evidence_id'],'mongolian':row['translation'],
                          'mongolbank_group_id':row['source']['group_id'],'match_method':'english_spelling_only',
                          'concept_status':'unverified','jurisdiction_pair':'US/MN'})
    (out/'issues.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2)+'\n')
    flags=defaultdict(list)
    for i,row in enumerate(issues,1):
        for evidence_id in row['evidence_ids']:
            flags[evidence_id].append({'issue_id':i,'issue_type':row['issue_type'],'priority':row['priority'],
                                       'status':'pending','suggested_action':row['details']['action']})
    (out/'flags_by_evidence.json').write_text(json.dumps(flags,ensure_ascii=False,indent=2)+'\n')
    with sqlite3.connect(out/'review_queue.sqlite') as db:
        db.execute('CREATE TABLE issues(id INTEGER PRIMARY KEY,dataset_id TEXT,issue_type TEXT,priority TEXT,status TEXT,evidence_ids_json TEXT,details_json TEXT)')
        db.executemany('INSERT INTO issues VALUES (?,?,?,?,?,?,?)',[(i,r['dataset_id'],r['issue_type'],r['priority'],r['status'],json.dumps(r['evidence_ids']),json.dumps(r['details'],ensure_ascii=False)) for i,r in enumerate(issues,1)])
    with (out/'review_queue.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['dataset_id','issue_type','priority','status','evidence_ids','details']);w.writeheader()
        w.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items() if k!='note'} for r in issues)
    with (out/'english_match_candidates.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['english','cfpd_version','cfpd_term_id','mongolbank_evidence_id','mongolian','mongolbank_group_id','match_method','concept_status','jurisdiction_pair']);w.writeheader();w.writerows(links)
    report={'input_runs':runs,'review_issue_count':len(issues),'counts_by_type':dict(Counter(r['issue_type'] for r in issues)),
            'lexical_link_count':len(links),'cfpd_terms_with_lexical_links':len({r['cfpd_term_id'] for r in links}),
            'note':'No entry marked reviewed and no concept equivalence established.',
            'files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}}
    (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'datasets/quality_audits/latest.json').write_text(json.dumps({'path':str(out.relative_to(ROOT))},indent=2)+'\n')
    print(json.dumps({'path':str(out),'issues':len(issues),'counts':report['counts_by_type'],'lexical_links':len(links)},ensure_ascii=False))


if __name__=='__main__':audit()
