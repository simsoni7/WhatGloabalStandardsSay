# 은행용어 추가 수집: CFPB 송금 영수증 항목

공식 CFPB `Send money abroad` 안내문의 영어·베트남어·러시아어·한국어·중국어 번체판에서 송금 영수증 예시의 실제 필드 8개씩, 총 32개 원문 쌍을 확보했다. 계좌·대출 용어집 확장은 아니며, 송금 금액·수수료·세금·환율·수취 총액이라는 실용적인 거래 문맥을 추가한다.

## 근거와 한계

- 출처: `https://files.consumerfinance.gov/f/documents/cfpb_send-money-abroad.pdf` 및 `_vi.pdf`, `_ru.pdf`, `_ko.pdf`, `_zh.pdf`.
- 자료: `datasets/source_collection/banking_expansion_batch5/evidence.jsonl`, `manifest.json`, `raw/cfpb_*.pdf`, `raw/cfpb_*.txt`.
- 방법: 공식 PDF의 1페이지 동일 영수증 행 및 예시금액을 비교. 원문 라벨의 구두점·오류도 보존. 반복된 영어 `Transfer Amount:`는 USD 송금액과 MXN 수취액으로 행 및 통화 문맥을 분리한다.
- 기관이 공개했다는 사실에 더해 별도 CFPB 정책 원문이 CFPB 제작 정보의 public-domain 재사용을 허용한다. PDF가 CFPB를 저자로 표시하며 제3자 저작물 고지는 추출된 본문에서 발견되지 않았다. 로고·상표를 용어 데이터로 포함하지 않는다.
- 일반적인 영어–외국어 금융 개념의 동등성을 전문가가 승인한 결과가 아니다. 승인 번역 0개 유지.
- 러시아어 row6 `Transfer Amount:`/`Cyмма к оплате отправителем:`와 row7 `Other Fees:`/`Наложенные услуги:`는 대응 위치가 같아도 의미 동등성에 의문이 있어 생성에서 격리한다. 원문을 임의 정정하지 않는다. 32 관측 자료 중 30개 비격리, 2개 격리.
- 한국어판 도입 설명이 영어판과 달라 전체 문단의 번역쌍을 추정하지 않았다. 동일 샘플 영수증 라벨만 사용했다.

## 추가 경로 조사

공식 GnuCash 저장소의 베트남어·러시아어 gettext 번역을 확보하여 별도 OSS 조사 에이전트에 인계했다. `oss_handoff/`는 그 조사 초안으로 이 CFPB 배치에 도입하거나 중복 계산하면 안 된다. GPL 고지·해당 파일별 적용 근거와 소스 재배포 조건은 별도 검수가 필요하다.

크메르어 CFPB `_km.pdf` 추정 경로는 404였다. 이는 해당 경로에서 자료를 찾지 못했다는 결과이며 크메르 금융 자료 자체가 없다는 뜻이 아니다. Wikidata의 CC0 공식 EntityData와 저작권 페이지를 직접 조사했으나 클라우드 CONNECT 403으로 읽지 못했다. 접근제한을 우회하거나 미확인 원문을 번역쌍으로 생성하지 않았다.

실행: `python3 scripts/collect_banking_expansion_batch5.py`. 원본 다운로드는 acquisition manifest URL과 SHA256으로 추적 가능하다.

## 후속 확보분

`next_batch_candidates/`에 같은 안내문의 스페인어·아이티크리올어·타갈로그어·아랍어 원본과 실제 접속결과를 저장했다. 스페인어 8행·아이티크리올어 8행은 `next_batch_candidates/evidence.jsonl`의 별도 16개 후보로 제출했다. 기본 32개 검수 스냅샷과 분리하며 검수 수용 전 통합하지 않는다. 타갈로그어는 여러 필드를 영어 그대로 사용하므로 신규 외국어 용어로 무조건 계산하면 안 된다. 아랍어는 PDF의 방향 제어문자와 읽기 순서를 검증한 후 추출해야 한다. 프랑스어·크메르어·네팔어·힌디어의 동일 명명 경로는 404이며 이는 해당 파일 경로의 부재만을 뜻한다.

## 후속 아랍어·타갈로그어

아랍어는 원문 PDF 1페이지를 `pdftoppm -f 1 -singlefile -scale-to 1600 -png`로 렌더링하고 실제 이미지를 확인했다. `arabic_receipt_batch/`에 8개 전사 자료, PDF·PNG와 해시·PDF 좌표를 보관했다. PyMuPDF가 추출한 `:مبلغ التحويل`처럼 콜론이 앞에 있는 문구는 `source.raw_extracted_text`에 그대로 남기고 논리적인 UTF-8 읽기 순서의 `مبلغ التحويل:`를 `source_target`에 기록한다. Arabic 어휘 글자는 수정하지 않았다. 원본 시각 전사는 AI 작업이며 금융·언어 전문가 번역 승인과 구별한다.

타갈로그어는 실제 번역 부분이 있는 4행 `Halaga:`, `Halaga:`, `Ibang mga fee:`, `TOTAL NA MATATANGGAP:`만 `tagalog_receipt_batch/`에 별도 제출했다. `Transfer fee:`, `Transfer tax:`, `TOTAL:`, `Exchange rate:`는 영어 그대로인 원문 필드이므로 추가 번역쌍에서 제외했다.

추가 금융교육 원자료를 찾기 위해 CFPB Your Money Your Goals 공식 toolkit 페이지를 조사하여 44개 PDF 링크를 확보했다. 영어 toolkit 및 checking/savings-account tool 원본은 확보했지만 병렬 언어판 없이 문단·제목을 임의 짝지어 생성하지 않는다. 조사 원본 및 접속 결과는 `education_probe/`에 보관한다.
