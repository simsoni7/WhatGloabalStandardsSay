#!/usr/bin/env python3
"""Collect finance-scoped GnuCash PO labels. Requires polib (pip install polib)."""
import hashlib,json,re,urllib.request
from pathlib import Path
import polib
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'datasets/source_collection/finance_oss_batch5'
COMMIT='9e39744aac80f2737d291fcbea3fff2d357b28a5'
BASE=f'https://raw.githubusercontent.com/Gnucash/gnucash/{COMMIT}/'
PAT=re.compile(r'\b(account|accounts|asset|assets|liability|liabilities|equity|income|expense|expenses|debit|credit|balance|balances|loan|loans|interest|deposit|deposits|withdrawal|payment|payments|invoice|invoices|fee|fees|tax|taxes|insurance|mortgage|bond|bonds|stock|stocks|share|shares|investment|investments|dividend|dividends|currency|currencies|exchange|transaction|transactions|budget|budgets|reconcile|reconciliation|receivable|payable|profit|loss|cash|bank|banking|capital|principal|amortization|ledger|payroll|refund|transfer|remittance)\b',re.I)
SHA=lambda b:hashlib.sha256(b).hexdigest()
TERMS={'commercial_use':True,'license':'GPL-2.0-or-GPL-3.0','copyleft':True,'attribution_required':True,'license_file':'raw/LICENSE','source_distribution_required':True,'source_files':['raw/po_vi.po','raw/po_ru.po'],'distribution_policy':'Separate GnuCash-derived copyleft reference pack; retain original PO copyright notices and GPL license. No claim that unrelated packs adopt GPL. Modified extraction notice in MODIFICATIONS.md.'}
def main():
 (OUT/'raw').mkdir(parents=True,exist_ok=True)
 acquisition=[]
 for f in ['po/vi.po','po/ru.po','LICENSE','README']:
  path=OUT/'raw'/f.replace('/','_')
  if not path.exists():path.write_bytes(urllib.request.urlopen(BASE+f,timeout=30).read())
  acquisition.append({'url':BASE+f,'local_file':str(path.relative_to(OUT)),'sha256':SHA(path.read_bytes()),'commit':COMMIT})
 records=[];excluded={};counts={}
 for lang in ['vi','ru']:
  po=polib.pofile(str(OUT/'raw'/f'po_{lang}.po')); reasons={};counts[lang]=0
  for e in po:
   reason=None
   if e.obsolete:reason='obsolete'
   elif e.fuzzy:reason='fuzzy'
   elif not e.msgstr or not e.msgid or e.msgid_plural:reason='empty_or_plural'
   elif not PAT.search(e.msgid):reason='outside_financial_scope'
   elif len(e.msgid)>65 or len(e.msgid.split())>8 or '\n' in e.msgid or re.search(r'[.!?]',e.msgid):reason='long_or_instruction_not_term_label'
   elif re.search(r'%|~|<|>|\{|\}',e.msgid+e.msgstr):reason='placeholder_or_markup'
   elif re.findall(r'\d+',e.msgid)!=re.findall(r'\d+',e.msgstr):reason='numeric_mismatch'
   elif e.msgid.casefold()==e.msgstr.casefold():reason='unchanged_translation'
   if reason:reasons[reason]=reasons.get(reason,0)+1;continue
   context=e.msgctxt or '';key=SHA((context+'\x04'+e.msgid).encode())[:20]
   record={'evidence_id':f'gnucash_financial_ui:{lang}:{key}','dataset_id':'gnucash_financial_ui','dataset_version':COMMIT,'dataset_state':'candidate','source_concept_id':f'gnucash_financial_ui:msg:{key}','source_language':'en','english':e.msgid,'target_language':lang,'translation':e.msgstr,'availability':'present','kind':'financial_software_ui_label','entry_type':'financial_software_ui_label','category':'accounting_and_financial_software','publisher':'GnuCash project / translation contributors','jurisdiction':'international','definition':None,'review_status':'explicit_source_key_alignment','human_review':False,'approved_translation':None,'context_required':True,'commercial_use':True,'license':TERMS['license'],'usage_terms':TERMS,'quality_flags':[{'issue_type':'community_software_translation_not_financial_authority','priority':'informational'}],'source':{'type':'official_project_gettext_localization','repository':'https://github.com/Gnucash/gnucash','commit':COMMIT,'url':BASE+f'po/{lang}.po','sha256':SHA((OUT/'raw'/f'po_{lang}.po').read_bytes()),'location':f'PO line {e.linenum}','msgid':e.msgid,'msgctxt':context,'msgstr':e.msgstr,'flags':e.flags,'occurrences':e.occurrences,'alignment_basis':'English msgid and localized msgstr in the same non-fuzzy gettext entry, context preserved','context':'Accounting/financial software UI label; not official bank terminology or expert-approved translation','license_url':BASE+'LICENSE','license_sha256':SHA((OUT/'raw/LICENSE').read_bytes()),'financial_scope_match':PAT.search(e.msgid).group(0)}}
   records.append(record);counts[lang]+=1
  excluded[lang]=reasons
 (OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
 (OUT/'excluded.json').write_text(json.dumps(excluded,indent=2))
 (OUT/'acquisition.json').write_text(json.dumps({'files':acquisition,'missing_language':{'km':'po/km.po HTTP 404; no Khmer data collected'},'officialness_evidence':'Pinned upstream README identifies this GitHub repository as GnuCash mirror; original maintained localization PO files retained.'},indent=2))
 (OUT/'MODIFICATIONS.md').write_text('# Extraction notice\n\n2026-10-14: Extracted non-fuzzy, translated finance-related short UI labels from original GnuCash PO files. English msgid, msgctxt and localized msgstr are unchanged. No translation authored or approved. Selection and JSON formatting are modifications; complete corresponding PO source and original copyright notices are distributed in raw/. This source pack is separate from unrelated dataset packs.\n')
 files={str(p.relative_to(OUT)):SHA(p.read_bytes()) for p in OUT.rglob('*') if p.is_file() and p.name!='manifest.json' and 'mifos' not in p.relative_to(OUT).parts}
 (OUT/'manifest.json').write_text(json.dumps({'dataset_id':'gnucash_financial_ui','entry_count':len(records),'language_counts':counts,'decision':'pending_independent_review','commercial_use':True,'usage_terms':TERMS,'scope':'Non-fuzzy short accounting/financial UI labels; official OSS source, community translations; not official financial institution glossary','files_sha256':files,'approved_translation_count':0},indent=2))
 print(json.dumps({'count':len(records),'languages':counts}))

def collect_mifos(directory="mifos", languages=("km","vi")):
 bankpat=re.compile(PAT.pattern+r'|\b(collateral|collaterals|savings|saving|disbursement|repayment|repayments)\b',re.I)
 out=OUT/directory;(out/'raw').mkdir(parents=True,exist_ok=True)
 commit='45ec7b82e9b14424a53ce9e8a847811f37f431bd';base=f'https://raw.githubusercontent.com/openMF/community-app/{commit}/'
 sources=['app/global-translations/locale-en.json']+[f'app/global-translations/locale-{lang}.json' for lang in languages]+['LICENSE.txt','README.md','package.json']
 acquisition=[]
 for f in sources:
  dest=out/'raw'/f.replace('/','_');tmp=Path('/tmp/mifos_'+f.replace('/','_'))
  if not dest.exists():dest.write_bytes(tmp.read_bytes() if tmp.exists() else urllib.request.urlopen(base+f,timeout=30).read())
  acquisition.append({'url':base+f,'local_file':str(dest.relative_to(out)),'sha256':SHA(dest.read_bytes()),'commit':commit})
 terms={'commercial_use':True,'license':'MPL-2.0','copyleft':True,'copyleft_scope':'file_level','attribution_required':True,'license_file':'raw/LICENSE.txt','source_distribution_required':True,'source_files':['raw/app_global-translations_locale-en.json']+[f'raw/app_global-translations_locale-{lang}.json' for lang in languages],'distribution_policy':'Separate MPL-covered localization source pack with complete corresponding JSON source, contributor metadata, license and extraction notice. No blanket relicensing of unrelated datasets.'}
 en=json.loads((out/'raw/app_global-translations_locale-en.json').read_text());rows=[];ex={};counts={}
 for lang in languages:
  target=json.loads((out/'raw'/f'app_global-translations_locale-{lang}.json').read_text());reasons={};counts[lang]=0
  for key,english in en.items():
   tr=target.get(key);reason=None
   if not isinstance(english,str) or not isinstance(tr,str) or not tr.strip():reason='missing_or_non_string'
   elif not key.startswith('label.') or not bankpat.search(english):reason='outside_financial_label_scope'
   elif len(english)>65 or len(english.split())>8 or re.search(r'[.!?\n]',english):reason='long_or_instruction_not_label'
   elif re.search(r'%|~|<|>|\{|\}',english+tr):reason='placeholder_or_markup'
   elif re.findall(r'\d+',english)!=re.findall(r'\d+',tr):reason='numeric_mismatch'
   elif english.casefold()==tr.casefold():reason='unchanged_translation'
   elif lang in {'km','ko','hi','ne'} and not re.search({'km':'[\u1780-\u17ff]','ko':'[\uac00-\ud7af\u1100-\u11ff]','hi':'[\u0900-\u097f]','ne':'[\u0900-\u097f]'}[lang],tr):reason='missing_expected_native_script'
   if reason:reasons[reason]=reasons.get(reason,0)+1;continue
   rows.append({'evidence_id':f'mifos_financial_ui:{lang}:{key}','dataset_id':'mifos_financial_ui','dataset_version':commit,'dataset_state':'candidate','source_concept_id':f'mifos_financial_ui:label:{key}','source_language':'en','english':english,'target_language':lang,'translation':tr,'availability':'present','kind':'financial_software_ui_label','entry_type':'financial_software_ui_label','category':'microfinance_banking_software','publisher':'Mifos initiative / openMF community translation contributors','jurisdiction':'international','definition':None,'review_status':'explicit_source_key_alignment','human_review':False,'approved_translation':None,'context_required':True,'commercial_use':True,'license':'MPL-2.0','usage_terms':terms,'quality_flags':[{'issue_type':'community_software_translation_not_financial_authority','priority':'informational'}],'source':{'type':'official_project_localization_json','repository':'https://github.com/openMF/community-app','commit':commit,'url':base+f'app/global-translations/locale-{lang}.json','sha256':SHA((out/'raw'/f'app_global-translations_locale-{lang}.json').read_bytes()),'location':key,'english_url':base+'app/global-translations/locale-en.json','english_sha256':SHA((out/'raw/app_global-translations_locale-en.json').read_bytes()),'english_location':key,'alignment_basis':'Same explicit localization JSON key in English and target-language files','context':'MifosX financial services software label, not national bank authority glossary or expert-approved translation','financial_scope_match':bankpat.search(english).group(0),'license_url':base+'LICENSE.txt','license_sha256':SHA((out/'raw/LICENSE.txt').read_bytes())}});counts[lang]+=1
  ex[lang]=reasons
 (out/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 (out/'excluded.json').write_text(json.dumps(ex,indent=2))
 (out/'acquisition.json').write_text(json.dumps({'files':acquisition,'officialness_evidence':'Pinned upstream README identifies default MifosX application; package.json author openMF links mifos.org. Contributor metadata retained in complete locale files.'},indent=2))
 (out/'MODIFICATIONS.md').write_text('# Extraction notice\n\n2026-10-14: Selected short financial UI labels from MifosX Community App English and target-language JSON locales by same explicit key. Original strings unchanged. Selection/JSON evidence formatting is a modification. Complete original files with contributor metadata, MPL-2.0 LICENSE, README and package metadata retained. This source pack remains separate from unrelated reference sources. No expert translation approval.\n')
 (out/'manifest.json').write_text(json.dumps({'dataset_id':'mifos_financial_ui','entry_count':len(rows),'language_counts':counts,'decision':'pending_independent_review','commercial_use':True,'usage_terms':terms,'scope':'Short microfinance/banking/accounting software UI labels, community translations not official bank glossary','files_sha256':{str(p.relative_to(out)):SHA(p.read_bytes()) for p in out.rglob('*') if p.is_file() and p.name!='manifest.json'},'approved_translation_count':0},indent=2))
 print(json.dumps({'dataset':'mifos_financial_ui','count':len(rows),'languages':counts}))

if __name__=="__main__":
 import argparse
 parser=argparse.ArgumentParser()
 parser.add_argument("--source", choices=["gnucash","mifos","mifos_next_batch","all"], default="all")
 args=parser.parse_args()
 if args.source in ("gnucash","all"):main()
 if args.source in ("mifos","all"):collect_mifos()

 if args.source == "mifos_next_batch":collect_mifos(directory="mifos_next_batch",languages=["ko","es","hi","ne","id"])
