# 실행과 현재 완성 범위

## 바로 실행

기존 DB로 용어 조회·원문 용어 번역·출처 비교를 실행하는 데에는 Python 3.12 표준 라이브러리만 필요합니다. 유료 API나 API 키를 사용하지 않습니다.

```bash
python3 -m glossary_app.server --port 8766
```

다른 터미널에서 실행하는 예:

```bash
curl --noproxy '*' -sS http://127.0.0.1:8766/v1/translate \
  -H 'Content-Type: application/json' \
  -d '{"english_term":"Credit Card","target_language":"mn","jurisdiction":"MN","context":"Bank app field label"}'

curl --noproxy '*' -sS http://127.0.0.1:8766/v1/check \
  -H 'Content-Type: application/json' \
  -d '{"english_term":"Saving Account","target_language":"ne","expression":"बचत खाता","jurisdiction":"NP","context":"Deposit product label"}'
```

`--noproxy '*'`는 위 **로컬 주소**에만 프록시 없이 연결하기 위한 옵션입니다. 외부 사이트의 네트워크 정책 우회에 사용하지 않습니다. 서버는 기본적으로 loopback에만 바인딩하며 공개 배포/인증은 포함하지 않았습니다.

서버 없이 CLI도 사용할 수 있습니다.

```bash
python3 -m glossary_app --request '{"operation":"translate","english_term":"Credit Card","target_language":"mn","jurisdiction":"MN"}'
```

## 동작하는 범위

- `/health`: 참조 인덱스와 모델 설정 상태
- `/v1/lookup`: 원문 표기·출처·정의·출처별 의미 ID·품질 표시 조회
- `/v1/translate`, `mode=reference`: **원문에 있는 용어를 인용해 번역 후보 제공**
- `/v1/check`, `mode=reference`: 입력 표현의 출처 일치/부분 일치/불일치 확인
- 여러 뜻이 있으면 `sense_selection_required`로 반환하며 임의 선택하지 않음. 반환한 `source_concept_id`를 요청에 넣어 의미를 선택할 수 있음
- 다른 나라 자료, 표기 제안, 숫자/내용 충돌, 원본 결측을 구분
- 잘못 연결된 네팔어 혜택과 UI 컨트롤은 기본 검색에서 제외. 여성 저축상품의 혜택 6쌍은 원문과 연결 순서를 확인한 별도 AI 보조 검토 기록으로 제공

`translated_text`는 자유롭게 생성한 문장이 아니라 **원본 용어 인용**입니다. 품사나 문맥 주석이 포함된 원문은 그대로 반환합니다. `source_comparison=exact_source_match`도 문맥 적합성·법적 정확성의 보증은 아닙니다. `contextual_verdict`는 모델 없이 `not_assessed`입니다.

국가별 차이를 지우지 않으며, 출처별 의미 ID는 각 자료의 항목 단위입니다. 영어 표기가 같은 256개 연결 후보를 의미가 같은 전역 개념으로 자동 병합하지 않았습니다.

## 아직 실행할 수 없는 범위: 자유 문장 AI 생성·문맥 검수

모델 호출 어댑터는 구현하고 JSON 출력·인용 ID·숫자 보존·TLS 검사 계약을 검증했습니다. 그러나 **실제 모델 호출은 수행하지 못했습니다.** 현재 환경에 모델 서비스 주소/모델명/인증이나 로컬 가중치가 없고, Hugging Face 및 공식 대체 모델 다운로드 주소는 네트워크 정책상 403으로 차단됩니다. 모델이 없을 때 `mode=model` 요청은 HTTP 503 `model_unavailable`을 반환합니다. 이를 번역 성공으로 처리하지 않습니다.

연결 가능한 OpenAI 호환 모델 서버가 생기면 다음 환경 변수로 사용합니다.

```bash
export MODEL_BASE_URL='http://127.0.0.1:11434/v1'
export MODEL_NAME='YOUR_INSTALLED_MODEL_NAME'
# 인증이 필요한 서비스만 MODEL_API_KEY를 보안 환경 설정으로 주입
python3 -m glossary_app.server --port 8766
```

예시 주소는 **이미 로컬 모델을 설치·실행한 경우**에만 사용합니다. 이 패키지가 모델 서버나 가중치를 포함한다는 뜻은 아닙니다. 외부 서버는 HTTPS를 사용해야 하며, 새 서버 연결의 비용·인증·접속 가능 여부는 여기서 검증하지 않았습니다.

생성 요청은 `mode=model`, 원문 문장은 `source_text`, 금융 용어는 `english_term`, 상황은 `context`에 전달합니다. 응답의 `generated_expression`과 `model_assessment`는 모델 제안이며 원본 용어·사람의 검수와 구분합니다. 모델은 없는 출처를 인용하거나 숫자 충돌/자료 충돌을 승인으로 덮어쓸 수 없습니다.

## 검증과 재구축

```bash
python3 -m evaluation.run
python3 -m glossary_app.index
```

16개 기능 평가를 실행했습니다. 이것은 참조 API의 행동 검증이며 번역 품질 정확도 점수가 아닙니다. 단위/HTTP/모델 계약 테스트 48개를 실행했습니다. 모델 계약 테스트는 명시적인 모의 응답이며 실제 AI 생성 테스트가 아닙니다. 결과는 `evaluation/results.json`, `evaluation/live_http_results.json`에 보존했습니다.

수집/품질 재구축/전체 테스트는 추가 패키지가 필요합니다.

```bash
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m unittest discover -s tests -q
.venv/bin/python scripts/resolve_quality.py
.venv/bin/python -m glossary_app.index
```

고정 `cfpd용어집 v1`은 변경하지 않습니다. 3,644개 몽골 항목은 원본 ID별로 보존했고 공식 총수와의 완전성 대조는 미확인입니다. 네팔어 수수료 페이지 세 종류는 여전히 서버 500이므로 대응 번역을 만들지 않았습니다. 원본 수집은 후보 상태를 유지하고, 품질 필터/표기 제안/정렬 검토는 `datasets/derived/`의 별도 계층으로 관리합니다.
