# Extraction notice

2026-10-14: Extracted non-fuzzy, translated finance-related short UI labels from original GnuCash PO files. English msgid, msgctxt and localized msgstr are unchanged. No translation authored or approved. Selection and JSON formatting are modifications; complete corresponding PO source and original copyright notices are distributed in raw/. This source pack is separate from unrelated dataset packs.
