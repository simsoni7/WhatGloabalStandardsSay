"""Export commercially approved reference data, preserving licenses and attribution."""
import collections,csv,hashlib,json,sqlite3,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def export():
 policy_path=ROOT/'datasets/language_packs/commercial_policy.json'
 policy=json.loads(policy_path.read_text());approved=set(policy['approved_dataset_ids'])
 registry=json.loads((policy_path.parent/'registry.json').read_text());manifests={};sources=[]
 for pack in registry['packs']:
  if pack['dataset_id'] not in approved:continue
  if pack['decision']!='accepted_reference' or pack.get('commercial_use') is not True:
   raise ValueError('Commercial reference pack not approved')
  base=(ROOT/pack['path']).resolve()
  if not base.is_relative_to(policy_path.parent.resolve()):raise ValueError('Commercial source path escapes')
  manifest=json.loads((base/'manifest.json').read_text())
  if manifest['usage_terms'].get('commercial_use') is not True:raise ValueError('Commercial permission missing')
  for name,digest in manifest['files_sha256'].items():
   file=(base/name).resolve()
   if not file.is_relative_to(base) or hashlib.sha256(file.read_bytes()).hexdigest()!=digest:
    raise ValueError('Commercial source checksum mismatch')
  manifests[pack['dataset_id']]=manifest
  sources += [(file,'sources/'+pack['dataset_id']+'/'+str(file.relative_to(base))) for file in base.rglob('*') if file.is_file() and file.name not in ['evidence.jsonl','excluded.jsonl','excluded.json']]
 if approved-{'cfpd'} != set(manifests):raise ValueError('Approved dataset lacks verified manifest')
 for evidence in policy['evidence']:
  file=(ROOT/evidence['policy_snapshot']).resolve()
  if not file.is_relative_to(ROOT) or hashlib.sha256(file.read_bytes()).hexdigest()!=evidence['policy_sha256']:
   raise ValueError('Legacy commercial policy evidence mismatch')
  sources.append((file,'licensing/'+evidence['dataset_id']+'/policy.html'))
  sources.append((ROOT/evidence['attribution_review'],'licensing/'+evidence['dataset_id']+'/attribution-review.json'))
 with sqlite3.connect(ROOT/'datasets/derived/reference_index.sqlite') as db:
  rows=[json.loads(x[0]) for x in db.execute("SELECT payload FROM entries WHERE usable=1 AND source_target IS NOT NULL AND source_target!='' ORDER BY dataset_id,evidence_id")]
 rows=[r for r in rows if r['dataset_id'] in approved]
 p=ROOT/'dist/commercial';p.mkdir(parents=True,exist_ok=True)
 (p/'glossary_entries.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 fields=['evidence_id','dataset_id','source_concept_id','source_english','target_language','source_target','alignment_status','equivalence_status','generation_eligible','approved_translation','integration_issue_ids','jurisdiction','review_status','record_type','source_json']
 with (p/'glossary_entries.csv').open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
  for r in rows:
   out={k:r.get(k,'') for k in fields};out['integration_issue_ids']=json.dumps(r.get('integration_issue_ids',[]));out['source_json']=json.dumps(r['source'],ensure_ascii=False);writer.writerow(out)
 c={'format_version':2,'entry_count':len(rows),'counts_by_dataset':dict(collections.Counter(r['dataset_id'] for r in rows)),'counts_by_language':dict(collections.Counter(r['target_language'] for r in rows)),'target_languages':sorted({r['target_language'] for r in rows}),'scope':'Commercially permitted reference terms and financial guidance; preserve source license and attribution conditions. Not expert-reviewed translation gold.','policy':policy,'manifests':manifests,'files_sha256':{}}
 for name in ['glossary_entries.jsonl','glossary_entries.csv']:c['files_sha256'][name]=hashlib.sha256((p/name).read_bytes()).hexdigest()
 c['schema_version']=2;c['approved_translation_count']=0
 c['field_rules']='Source observations are not approved translations. Commercial permission is separate from semantic correctness.'
 (p/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
 (p/'ATTRIBUTION.md').write_text('''# Attribution and usage\n\nCFPB-created reference material: public domain under the captured official CFPB policy. No endorsement is implied; trademarks and third-party works are not licensed by that policy.\n\nCanadian government financial reporting labels and currency names: open-data/ckanext-canada, MIT. Retain the original copyright and license supplied under sources/.\n\nEU CPV financial and insurance service labels: Publications Office of the European Union, OP-TED/eForms-SDK, CC BY 4.0. Division 66 selected; English-fallback Irish labels excluded. Original labels retained. Attribute this source and identify further changes. The original license and source are supplied under sources/.\n\nThese records are candidate references. Commercial-use permission does not establish linguistic accuracy or suitability in a different financial jurisdiction. Mongolia and Nepal legacy data are excluded because commercial redistribution conditions have not been verified.\n''')
 with zipfile.ZipFile(ROOT/'dist/commercial-language-packs.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for file in sorted(p.iterdir()):z.write(file,'commercial-language-packs/'+file.name)
  for file,name in sources:z.write(file,'commercial-language-packs/'+name)
 with zipfile.ZipFile(ROOT/'dist/commercial-language-packs.zip') as z:assert z.testzip() is None
 assert not {'mongolbank','nepalbank','finqa'} & set(c['counts_by_dataset'])
 with (p/'glossary_entries.csv').open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==len(rows)
 print(json.dumps({'entry_count':len(rows),'target_languages':len(c['target_languages']),'counts_by_dataset':c['counts_by_dataset']},ensure_ascii=False))
if __name__=='__main__':export()
