"""Build an offline financial-review workbench without mutating source records."""
import hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
def fingerprint(r):
    return hashlib.sha256(json.dumps({k:r.get(k) for k in ('evidence_id','dataset_id','dataset_version','source_concept_id','source_english','source_target','target_language','definition','source')},ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def build():
    source=ROOT/'dist/data/glossary_entries.jsonl'
    rows=[]
    for line in source.open():
        r=json.loads(line)
        row={k:r.get(k) for k in ('evidence_id','dataset_id','dataset_version','source_concept_id','source_english','source_target','target_language','jurisdiction','record_type','definition','source','semantic_review','quality_flags','generation_eligible')}
        row['source_fingerprint']=fingerprint(r)
        rows.append(row)
    payload={'snapshot':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows,'cards':[json.loads(l) for l in (ROOT/'datasets/enrichment/financial_concepts/cards.jsonl').open()]}
    encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    out=ROOT/'dist/financial-review.html'
    out.write_text((ROOT/'reviewer/template.html').read_text().replace('__DATA__',encoded))
    print(json.dumps({'rows':len(rows),'bytes':out.stat().st_size,'snapshot':payload['snapshot']}))
if __name__=='__main__':build()
