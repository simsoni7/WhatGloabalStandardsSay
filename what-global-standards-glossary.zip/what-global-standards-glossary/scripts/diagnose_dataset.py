#!/usr/bin/env python3
"""Read-only structural coverage audit; heuristic domains are not semantic approvals."""
import collections, csv, hashlib, json, pathlib, re, sqlite3
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'datasets/enrichment/diagnostics'; OUT.mkdir(parents=True,exist_ok=True)
DB=ROOT/'datasets/derived/reference_index.sqlite'
policy=json.loads((ROOT/'datasets/language_packs/commercial_policy.json').read_text())
allowed=set(policy['approved_dataset_ids'])
conn=sqlite3.connect(f'file:{DB}?mode=ro',uri=True);conn.row_factory=sqlite3.Row
rows=[dict(r) for r in conn.execute('select * from entries')]
for r in rows:r['p']=json.loads(r['payload'])
active=[r for r in rows if r['usable'] and r['source_target'] and r['source_target'].strip()]
RULES={
 'credit_lending':r'loan|mortgage|credit|borrow|repay|collateral|foreclos|lending',
 'payments_remittance':r'remittance|transfer|payment|card|cheque|check|wire|acquir',
 'deposits_interest':r'deposit|saving|interest|rate|account|banking',
 'investment_securities':r'stock|share|bond|securit|investment|equity|fund|derivative|option|warrant',
 'insurance_pension':r'insuran|premium|pension|annuity|coverage',
 'compliance_consumer_rights':r'complaint|dispute|fraud|identity|disclosure|regulat|compliance|consumer|kyc|verification',
 'currency_fx':r'currency|exchange|foreign|dollar|euro|yen',
 'accounting_contracts':r'accounting|balance|asset|liabilit|audit|contract|agreement|procurement|revenue|expense|tax'}
def present(x):
 if isinstance(x,dict):return any(present(v) for v in x.values())
 if isinstance(x,list):return any(present(v) for v in x)
 return bool(x and str(x).strip())
def _group(rs,key,value):
 groups=collections.defaultdict(set)
 for r in rs:groups[(r['dataset_id'],r['language'],r[key])].add(r[value])
 return groups
def metric(rs):
 n=len(rs); ps=[r['p'] for r in rs]
 def cnt(f):return sum(bool(f(p)) for p in ps)
 return {'records':n,'languages':len({r['language'] for r in rs}), 'source_specific_concepts':len({r['concept_id'] for r in rs}),
 'definition_present':cnt(lambda p:present(p.get('definition'))),
 'explicit_context_present':cnt(lambda p:present(p.get('context')) or present(p.get('semantic_review',{}).get('context')) or present(p.get('source',{}).get('context'))),
 'explicit_usage_scenario_present':cnt(lambda p:any(present(p.get(k)) for k in ('usage_scenario','usage_context','example_sentence','examples'))),
 'approved_translation_present':cnt(lambda p:present(p.get('approved_translation'))),
 'source_provenance_object_present':cnt(lambda p:present(p.get('source'))),
 'integration_issue_records':cnt(lambda p:present(p.get('integration_issue_ids'))),
 'quality_flag_records':cnt(lambda p:present(p.get('quality_flags'))),
 'ai_semantically_reviewed_records':cnt(lambda p:p.get('semantic_review',{}).get('status')!='not_reviewed' and bool(p.get('semantic_review',{}).get('status'))),
 'generation_ineligible_records':cnt(lambda p:p.get('generation_eligible') is False),
 'exact_pair_duplicate_excess':sum(n-1 for n in collections.Counter((r['dataset_id'],r['language'],r['english_norm'],r['translation_norm']) for r in rs).values() if n>1),
 'same_english_multiple_target_groups':sum(len(v)>1 for v in _group(rs,'english_norm','translation_norm').values()),
 'same_target_multiple_english_groups':sum(len(v)>1 for v in _group(rs,'translation_norm','english_norm').values())}
coverage=[]
for d,l,t in sorted({(r['dataset_id'],r['language'],r['p'].get('record_type','unknown')) for r in active}):
 rs=[r for r in active if (r['dataset_id'],r['language'],r['p'].get('record_type','unknown'))==(d,l,t)]
 coverage.append({'dataset_id':d,'language':l,'record_type':t,'commercial_policy_allowed':d in allowed,**metric(rs)})
with (OUT/'coverage.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(coverage[0]));w.writeheader();w.writerows(coverage)
domaincounts=collections.Counter(); annotations=[]
for r in active:
 labels=[k for k,v in RULES.items() if re.search(v,r['source_english'],re.I)] or ['unclassified']
 if r['p'].get('record_type')=='currency_name':labels=['currency_fx']
 for domain in labels:domaincounts[(r['dataset_id'],r['language'],domain)]+=1
 annotations.append({'evidence_id':r['evidence_id'],'domain_candidates':labels,'classification_basis':'English regex heuristic; not expert reviewed','commercial_policy_allowed':r['dataset_id'] in allowed})
with (OUT/'domain_candidates.jsonl').open('w') as f:
 for a in annotations:f.write(json.dumps(a,ensure_ascii=False)+'\n')
langs=[]
for l in sorted({r['language'] for r in active}):
 rs=[r for r in active if r['language']==l];cs=[r for r in rs if r['dataset_id'] in allowed]
 langs.append({'language':l,'all_records':len(rs),'commercial_records':len(cs),'all_concepts':len({r['concept_id'] for r in rs}),'commercial_concepts':len({r['concept_id'] for r in cs}),'datasets':dict(collections.Counter(r['dataset_id'] for r in rs))})
bydataset={d:metric([r for r in active if r['dataset_id']==d]) for d in sorted({r['dataset_id'] for r in active})}
result={'method':'Structural presence audit of usable nonempty source pairs. Context fields only; source URLs/categories do not count as usage context. Commercial scope uses policy allowlist, not legal judgment. Regex domains are overlapping heuristic candidates, not verified classifications.', 'input_db_sha256':hashlib.sha256(DB.read_bytes()).hexdigest(),'raw_index_rows':len(rows),'all':metric(active),'commercial':metric([r for r in active if r['dataset_id'] in allowed]),'by_dataset':bydataset,'by_language':langs,'domain_heuristic_counts':[{'dataset_id':d,'language':l,'domain':dom,'records':n} for (d,l,dom),n in sorted(domaincounts.items())],'equivalence_status':dict(collections.Counter(r['equivalence_status'] for r in active))}
(OUT/'diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['all','commercial','by_dataset']},ensure_ascii=False,indent=2))
