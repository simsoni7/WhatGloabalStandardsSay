#!/usr/bin/env python3
"""Pinned Apache source observations; no generated translations or locale fallback."""
import collections,hashlib,json,pathlib,re,urllib.request,xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'datasets/source_collection/batch7_permissive'
COMMIT='b8b72d556e829d4a0818f8a4fed57e0750efcacb'
BASE=f'https://raw.githubusercontent.com/apache/ofbiz-framework/{COMMIT}/'
FILES={'CommonUiLabels.xml':'framework/common/config/CommonUiLabels.xml','CommonEntityLabels.xml':'framework/common/config/CommonEntityLabels.xml','PartyUiLabels.xml':'applications/party/config/PartyUiLabels.xml','AccountingEntityLabels.xml':'applications/accounting/config/AccountingEntityLabels.xml','LICENSE':'LICENSE','NOTICE':'NOTICE'}
LANG='{http://www.w3.org/XML/1998/namespace}lang'
LOCALES={'ar':'ar','cs':'cs','de':'de','es':'es','fr':'fr','hi-IN':'hi','it':'it','ja':'ja','nl':'nl','pt':'pt','pt-BR':'pt-BR','ro':'ro','ru':'ru','th':'th','vi':'vi','zh':'zh-Hans','zh-TW':'zh-Hant'}
ALLOW=set('''Credit Line|Credit Memo|Depreciation|Disbursement|Incoming Payment|Outgoing Payment|Tax Due|Bank Account|Deposit Account|Investment Account|Accumulated Depreciation|Asset|Cash and Equivalent|Cash Expense|Cash Income|Cost of Goods Sold Expense|Current Asset|Current Liability|Expense|Interest Expense|Inventory Asset|Liability|Long Term Asset|Long Term Liability|Non-Cash Expense|Non-Cash Income|Revenue|Selling, General, and Administrative Expense|Accounts Payable|Accounts Receivable|Accounts Payables Write Off|Accounts Receivables Write Off|Bank Settlement|Commission Expense|Credit Card|Customer Credits|Interest Income|Interest Income Receivables|Interest Income Write Off|Merchant Account Settlement|Operating Expense|Other Asset|Other Expense|Prepaid Expenses|Cash|Company Account|Cash On Delivery|Personal Check|Certified Check|Money Order|Electronic Fund Transfer|Commission Payment|Customer Deposit|Customer Payment|Customer Refund|Income Tax Payment|Interest Receipt|Payroll Tax Payment|Sales Tax Payment|Tax Payment|Vendor Payment|Vendor Prepayment|Export Tax|Import Tax|Income Tax|Excise Tax|Annual revenue|Tax ID|Tax Identification and Exemption|Total Payments In|Total Payments Out|Payment Method Type|Payment Authorization Service|Payment Capture Service|Payment Refund Service|Invoice Status|Payment Status'''.split('|'))
# Conservative rejection of directly identifiable false friends/scope losses. Retained
# observations remain unapproved source quotations and generation-ineligible.
BAD={('vi','Credit Memo'),('vi','Interest Receipt'),('vi','Personal Check'),('vi','Vendor Prepayment'),('vi','Depreciation'),('vi','Tax Due'),('vi','Customer Payment'),('vi','Payroll Tax Payment'),('vi','Sales Tax Payment'),('vi','Tax Payment'),('it','Depreciation'),('it','Vendor Payment'),('it','Credit Line'),('ro','Credit Line'),('ro','Tax Due'),('ro','Income Tax'),('ro','Payroll Tax Payment'),('ro','Use Tax'),('ru','Customer Refund'),('th','Credit Line'),('fr','Income Tax Payment')}
BAD.update({('vi',x) for x in ['Payment Authorization Service','Payment Capture Service','Invoice Status','Tax ID','Credit Line','Deposit Account','Accumulated Depreciation','Cash and Equivalent','Cost of Goods Sold Expense','Current Liability','Interest Expense','Liability','Long Term Liability','Revenue','Selling, General, and Administrative Expense','Accounts Payable','Accounts Receivable','Accounts Payables Write Off','Accounts Receivables Write Off','Interest Income','Interest Income Receivables','Interest Income Write Off','Merchant Account Settlement','Certified Check','Money Order']})
BAD.update({('it',x) for x in ['Annual revenue','Cash and Equivalent','Current Asset','Current Liability','Long Term Liability','Bank Settlement','Merchant Account Settlement','Money Order','Disbursement','Tax Payment','Payroll Tax Payment','Sales Tax Payment']})
BAD.update({('ro',x) for x in ['Depreciation','Disbursement','Accumulated Depreciation','Current Asset','Current Liability','Revenue','Bank Settlement','Merchant Account Settlement','Certified Check','Tax Payment','Sales Tax Payment','Cash On Delivery','Cost of Goods Sold Expense']})
BAD.update({('ru',x) for x in ['Tax Due','Bank Settlement','Merchant Account Settlement','Disbursement']})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 raw=OUT/'raw';raw.mkdir(parents=True,exist_ok=True)
 for name,path in FILES.items():
  if not (raw/name).exists():(raw/name).write_bytes(urllib.request.urlopen(BASE+path,timeout=45).read())
 assert b'Apache License' in (raw/'LICENSE').read_bytes()
 existing=set()
 for line in (ROOT/'datasets/source_collection/permissive_finance_batch5/evidence.jsonl').read_text().splitlines():
  r=json.loads(line);existing.add((r['target_language'],r['english'].strip().casefold(),r['translation'].strip().casefold()))
 rows=[];excluded=[];keys=[]
 for name,path in FILES.items():
  if not name.endswith('.xml'):continue
  for prop in ET.parse(raw/name).getroot():
   key=prop.get('key');values={x.get(LANG):x.text or '' for x in prop};en=values.get('en','').strip()
   if en not in ALLOW:continue
   keys.append({'file':name,'key':key,'english':en})
   for locale,lang in LOCALES.items():
    val=values.get(locale,'').strip();reason=None
    if not val:reason='missing_actual_locale'
    elif val.casefold()==en.casefold():reason='english_fallback_or_identical_unverified'
    elif re.search(r'\$|[{}<>]|%[sd]',val):reason='placeholder_or_markup'
    elif (lang,en) in BAD:reason='semantic_scope_or_false_friend_rejected'
    fp=(lang,en.casefold(),val.casefold())
    if fp in existing:reason='duplicate_existing_or_current_exact_pair'
    if reason:
     excluded.append({'file':name,'key':key,'english':en,'locale':locale,'target':val,'reason':reason});continue
    existing.add(fp)
    rows.append({'evidence_id':f'apache_ofbiz_financial_entities:{lang}:{name}:{key}','dataset_id':'apache_ofbiz_financial_entities','dataset_name':'Apache OFBiz financial entity and payment labels','dataset_version':COMMIT,'dataset_state':'candidate','source_concept_id':f'apache_ofbiz_financial_entities:{name}:{key}','source_language':'en','english':en,'target_language':lang,'translation':val,'availability':'present','kind':'financial_software_label','category':'financial_software_entity_labels','publisher':'Apache Software Foundation','jurisdiction':'international_software_context','license':'Apache-2.0','commercial_use':True,'human_review':False,'approved_translation':None,'generation_eligible':False,'generation_safety_assessed':False,'context_required':True,'review_status':'explicit_upstream_resource_key_alignment','quality_flags':['software_label_not_financial_institution_glossary','upstream_translation_not_expert_approved','context_required'],'source':{'type':'official_open_source_localization','url':f'https://github.com/apache/ofbiz-framework/blob/{COMMIT}/{path}','raw_url':BASE+path,'file':str((raw/name).relative_to(ROOT)),'sha256':sha(raw/name),'commit':COMMIT,'source_key':key,'source_locale':locale,'english_locale':'en','raw_english_value':values['en'],'raw_target_value':values[locale],'normalization':'outer_whitespace_trim_only','alignment_method':'explicit_same_property_key_two_actual_locale_values','software_context':'Apache OFBiz ERP accounting entities / payment methods; not a bank glossary','license_url':f'https://github.com/apache/ofbiz-framework/blob/{COMMIT}/LICENSE','notice_url':f'https://github.com/apache/ofbiz-framework/blob/{COMMIT}/NOTICE','license_sha256':sha(raw/'LICENSE'),'notice_sha256':sha(raw/'NOTICE')}})
 (OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 (OUT/'excluded.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2)+'\n')
 manifest={'commit':COMMIT,'dataset_id':'apache_ofbiz_financial_entities','license':'Apache-2.0','commercial_use':True,'license_obligations':['Preserve LICENSE and NOTICE','State extraction and selection changes; no Apache endorsement'],'total_pairs':len(rows),'counts':dict(collections.Counter(r['target_language'] for r in rows)),'files':{n:{'path':p,'sha256':sha(raw/n)} for n,p in FILES.items()},'evidence_sha256':sha(OUT/'evidence.jsonl'),'selected_keys':keys,'deduplication':'exact target language / English / translation against batch5 and this batch','excluded_semantic_pairs':sorted([list(x) for x in BAD]),'expert_approved':False,'generation_eligible':False}
 (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rows':len(rows),'counts':manifest['counts']}))
if __name__=='__main__':main()
