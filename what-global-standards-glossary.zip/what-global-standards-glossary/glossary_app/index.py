from collections import defaultdict
from datetime import datetime,timezone
import hashlib,json,re,sqlite3,unicodedata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'datasets/derived/reference_index.sqlite'


def normalize(value):
    return ' '.join(unicodedata.normalize('NFC',value or '').split()).casefold()


def load_language_packs(root):
    base=(root/'datasets/language_packs').resolve()
    registry=base/'registry.json'
    if not registry.exists():return [],{}
    rows=[];inputs={};seen=set()
    for pack in json.loads(registry.read_text())['packs']:
        if pack['decision']!='accepted_reference':continue
        directory=(root/pack['path']).resolve()
        if not directory.is_relative_to(base):raise ValueError('Language pack escapes approved directory')
        manifest=json.loads((directory/'manifest.json').read_text())
        path=directory/'evidence.jsonl';digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if manifest['dataset_id']!=pack['dataset_id'] or digest!=manifest['files_sha256']['evidence.jsonl']:
            raise ValueError('Language pack identity or checksum mismatch')
        records=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        if len(records)!=manifest['entry_count']:raise ValueError('Language pack entry count mismatch')
        for record in records:
            if (record['dataset_id']!=pack['dataset_id'] or record['source_language']!='en'
                or record.get('availability')!='present' or not record.get('english')
                or not record.get('translation') or not record.get('target_language')
                or record.get('kind')=='benchmark_case'):
                raise ValueError('Invalid reference language pack record')
            if record['evidence_id'] in seen:raise ValueError('Duplicate language pack evidence')
            seen.add(record['evidence_id'])
            record={**record,'dataset_state':pack['state']}
            record.setdefault('quality_flags',[])
            concept=record.get('source_concept_id') or pack['dataset_id']+':entry:'+record['evidence_id']
            rows.append((record,concept,True))
        inputs[pack['dataset_id']]={'path':pack['path'],'sha256':digest}
    return rows,inputs


def build():
    quality_dir=ROOT/json.loads((ROOT/'datasets/derived/quality/latest.json').read_text())['path']
    release=json.loads((quality_dir/'release.json').read_text())
    summary=json.loads((quality_dir/'summary.json').read_text())
    if hashlib.sha256((quality_dir/'release.json').read_bytes()).hexdigest()!=summary['release_sha256']:raise ValueError('Quality release checksum mismatch')
    audit=ROOT/release['audit_path'];flags=json.loads((audit/'flags_by_evidence.json').read_text())
    numeric_resolved={eid for r in release['resolutions'] if r['status']=='numeric_values_equivalent_only' for eid in r['evidence_ids']}
    blocked=set(release['blocked_evidence_ids'])
    rows=[];inputs={}
    for dataset,directory in [('cfpd',ROOT/'datasets/cfpd/v1'),*[(k,ROOT/v) for k,v in release['input_runs'].items()]]:
        report=json.loads((directory/('manifest.json' if dataset=='cfpd' else 'report.json')).read_text())
        path=directory/'evidence.jsonl'
        if hashlib.sha256(path.read_bytes()).hexdigest()!=report['files_sha256']['evidence.jsonl']:raise ValueError('Source evidence checksum mismatch')
        inputs[dataset]={'path':str(directory.relative_to(ROOT)),'sha256':report['files_sha256']['evidence.jsonl']}
        for line in path.read_text().splitlines():
            record=json.loads(line);record['dataset_state']='frozen' if dataset=='cfpd' else 'candidate'
            row_flags=flags.get(record['evidence_id'],[])
            if record['evidence_id'] in numeric_resolved:
                row_flags=[f for f in row_flags if f['issue_type']!='numeric_tokens_differ']
            record['quality_flags']=row_flags
            if dataset=='cfpd':concept='cfpd:term:'+record['evidence_id'].split(':')[2]
            elif dataset=='mongolbank':concept='mongolbank:entry:'+str(record['source']['source_id'])
            else:concept='nepalbank:entry:'+record['evidence_id'].rsplit(':',1)[-1]
            usable=record['evidence_id'] not in blocked and (dataset!='nepalbank' or record.get('kind')=='term')
            rows.append((record,concept,usable))
    for record in release['patches']:
        record={**record,'dataset_state':'candidate','quality_flags':[]}
        rows.append((record,'nepalbank:alignment:'+record['evidence_id'].rsplit(':',1)[-1],True))
    supplement=ROOT/'datasets/nepalbank/candidate/document-expansion'
    if (supplement/'report.json').exists():
        report=json.loads((supplement/'report.json').read_text())
        path=supplement/'evidence.jsonl'
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if digest!=report['files_sha256']['evidence.jsonl']:
            raise ValueError('Nepal document supplement checksum mismatch')
        inputs['nepalbank_forms']={'path':str(supplement.relative_to(ROOT)),'sha256':digest}
        for line in path.read_text().splitlines():
            record=json.loads(line)
            rows.append((record,'nepalbank:form:'+record['evidence_id'].rsplit(':',1)[-1],True))
    pack_rows,pack_inputs=load_language_packs(ROOT)
    if inputs.keys() & pack_inputs.keys():raise ValueError('Language pack dataset identity collision')
    rows.extend(pack_rows);inputs.update(pack_inputs)
    DB.parent.mkdir(parents=True,exist_ok=True);temp=DB.with_suffix('.building.sqlite')
    if temp.exists():temp.unlink()
    concepts={}
    with sqlite3.connect(temp) as db:
        db.executescript('''PRAGMA foreign_keys=ON;
        CREATE TABLE source_concepts(id TEXT PRIMARY KEY,dataset_id TEXT,english TEXT,definition TEXT,definition_language TEXT,group_id INTEGER);
        CREATE TABLE entries(id INTEGER PRIMARY KEY,evidence_id TEXT UNIQUE,concept_id TEXT REFERENCES source_concepts(id),dataset_id TEXT,
        english TEXT,english_norm TEXT,language TEXT,translation TEXT,translation_norm TEXT,jurisdiction TEXT,usable INTEGER,payload TEXT);
        CREATE INDEX entry_term_language ON entries(english_norm,language,usable);
        CREATE INDEX entry_concept ON entries(concept_id);
        CREATE TABLE aliases(alias_norm TEXT,concept_id TEXT REFERENCES source_concepts(id),kind TEXT,PRIMARY KEY(alias_norm,concept_id));
        CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);
        CREATE VIRTUAL TABLE entry_search USING fts5(english,translation,definition,tokenize='unicode61');''')
        for record,concept,usable in rows:
            definition=record.get('definition') or {}
            if concept not in concepts:
                values=(concept,record['dataset_id'],record['english'],definition.get('text'),definition.get('language'),record['source'].get('group_id'))
                db.execute('INSERT INTO source_concepts VALUES (?,?,?,?,?,?)',values);concepts[concept]=values
            record['source_concept_id']=concept
            values=(record['evidence_id'],concept,record['dataset_id'],record['english'],normalize(record['english']),record['target_language'],
                    record.get('translation'),normalize(record.get('translation')),record['jurisdiction'],int(usable),json.dumps(record,ensure_ascii=False))
            cursor=db.execute('INSERT INTO entries(evidence_id,concept_id,dataset_id,english,english_norm,language,translation,translation_norm,jurisdiction,usable,payload) VALUES (?,?,?,?,?,?,?,?,?,?,?)',values)
            db.execute('INSERT INTO entry_search(rowid,english,translation,definition) VALUES (?,?,?,?)',
                       (cursor.lastrowid,record['english'],record.get('translation') or '',definition.get('text') or ''))
            acronym=re.search(r'\(([A-Z][A-Z0-9-]{1,11})\)\s*$',record['english'])
            if acronym:db.execute('INSERT OR IGNORE INTO aliases VALUES (?,?,?)',(normalize(acronym[1]),concept,'source_acronym'))
            term=normalize(record['english'])
            if term in ('saving account','savings account'):
                alternative='savings account' if term=='saving account' else 'saving account'
                db.execute('INSERT OR IGNORE INTO aliases VALUES (?,?,?)',(alternative,concept,'inflection_candidate'))
        for alias in release['aliases']:
            for eid in alias['evidence_ids']:
                found=db.execute('SELECT concept_id FROM entries WHERE evidence_id=?',(eid,)).fetchone()
                if found:db.execute('INSERT OR REPLACE INTO aliases VALUES (?,?,?)',(normalize(alias['alias']),found[0],alias['status']))
        details={'built_at':datetime.now(timezone.utc).isoformat(),'inputs':inputs,'quality_release':str(quality_dir.relative_to(ROOT)),
                 'entry_count':len(rows),'source_concept_count':len(concepts),'usable_entry_count':db.execute('SELECT count(*) FROM entries WHERE usable=1').fetchone()[0]}
        db.execute('INSERT INTO metadata VALUES (?,?)',('build',json.dumps(details)))
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
    temp.replace(DB)
    (DB.parent/'reference_index_manifest.json').write_text(json.dumps({**details,'sha256':hashlib.sha256(DB.read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
    return details


class Index:
    def __init__(self,path=DB):
        self.path=Path(path)
        if not self.path.exists():raise RuntimeError('Reference index missing; run python -m glossary_app.index')

    def connect(self):
        db=sqlite3.connect(self.path.resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;return db

    def lookup(self,query,language=None,dataset=None,jurisdiction=None,concept_id=None,limit=20):
        q=normalize(query)
        if not q or len(q)>2000:raise ValueError('Query must contain 1..2000 characters')
        if not 1<=limit<=50:raise ValueError('Limit must be 1..50')
        with self.connect() as db:
            where=['e.usable=1'];params=[]
            if language:where.append('e.language=?');params.append(language.casefold() if language.casefold()!='zh-hant' else 'zh-Hant')
            if dataset:where.append('e.dataset_id=?');params.append(dataset)
            if jurisdiction:where.append('e.jurisdiction=?');params.append(jurisdiction.upper())
            if concept_id:where.append('e.concept_id=?');params.append(concept_id)
            base='SELECT e.* FROM entries e WHERE '+' AND '.join(where)
            exact=db.execute(base+' AND (e.english_norm=? OR e.translation_norm=?) LIMIT ?',params+[q,q,limit]).fetchall()
            results=[{**json.loads(r['payload']),'match_type':'exact_source_text'} for r in exact]
            if not results:
                aliases=db.execute(base+' AND e.concept_id IN (SELECT concept_id FROM aliases WHERE alias_norm=?) LIMIT ?',params+[q,limit]).fetchall()
                for row in aliases:
                    kind=db.execute('SELECT kind FROM aliases WHERE alias_norm=? AND concept_id=?',(q,row['concept_id'])).fetchone()[0]
                    results.append({**json.loads(row['payload']),'match_type':kind})
            if not results:
                tokens=re.findall(r'[^\W_]+',q,flags=re.UNICODE)[:12]
                if tokens:
                    match=' OR '.join('"'+t+'"' for t in tokens)
                    found=db.execute(base+' AND e.id IN (SELECT rowid FROM entry_search WHERE entry_search MATCH ? ORDER BY rank LIMIT 200) LIMIT ?',params+[match,limit]).fetchall()
                    results=[{**json.loads(r['payload']),'match_type':'token_search_candidate'} for r in found]
            return results

    def stats(self):
        with self.connect() as db:
            return {**json.loads(db.execute("SELECT value FROM metadata WHERE key='build'").fetchone()[0]),
                    'aliases':db.execute('SELECT count(*) FROM aliases').fetchone()[0]}


if __name__=='__main__':print(json.dumps(build(),ensure_ascii=False,indent=2))
