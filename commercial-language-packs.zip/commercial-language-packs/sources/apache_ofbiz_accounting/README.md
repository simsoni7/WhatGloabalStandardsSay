Source observations only. Source pairing is not expert semantic equivalence. Original source identifiers, financial software/receipt context and license notices retained.
