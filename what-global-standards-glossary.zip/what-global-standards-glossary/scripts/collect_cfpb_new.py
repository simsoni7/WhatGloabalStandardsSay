"""Reproducibly extract explicitly mapped sections of CFPB official remittance translations.
Run with project .venv (PyMuPDF). PDFs remain verbatim, including source mistakes.
"""
import json,re,hashlib,pathlib
import fitz
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'datasets/source_collection/cfpb_new'
ACQ=json.loads((OUT/'acquisition.json').read_text())
DOCS=[fitz.open(OUT/'raw'/f'source_{i}.pdf') for i in range(4)]
def blocks(i,p):return [b for b in DOCS[i][p-1].get_text('dict')['blocks'] if 'lines' in b]
def extract(i,p,ix):
 bs=blocks(i,p); selected=[bs[k] for k in ix];t=' '.join(''.join(s['text'] for s in l['spans']) for b in selected for l in b['lines']);return re.sub(r'\s+',' ',t).strip(' §\t'),[b['bbox'] for b in selected]
# page, English block IDs, Haitian block IDs, Tagalog block IDs. Explicit author-reviewed section map, not position-only automatic alignment.
MAP=[(1,[1],[1],[1]),(1,[2],[2],[2]),(1,[3],[3],[3]),(1,[4],[4],[4]),(1,[5],[5],[5]),(1,[6],[6],[6]),(1,[7,8],[7],[7]),(1,[9],[9],[10]),(1,[10,11],[10,11],[11]),(1,[12],[12],[12]),(1,[13,14],[13,14],[13]),(1,[15],[15],[14]),(2,[1],[1],[1]),(2,[2],[2],[2]),(2,[3,4],[3],[3]),(2,[5],[4],[4]),(2,[6],[5],[5]),(2,[7],[6],[6]),(2,[8],[7],[7]),(2,[9],[8],[8]),(2,[10,11],[9],[9,10]),(2,[12],[10],[11]),(2,[13,14],[11],[12]),(2,[15],[12],[13]),(2,[16],[13],[14]),(2,[17],[14],[15]),(2,[18],[15],[16]),(2,[19],[16],[17]),(2,[20],[17],[18]),(2,[21],[18],[19]),(2,[22],[19],[20]),(3,[1],[1],[1]),(3,[2],[2],[2]),(3,[3,4],[3],[3]),(3,[5,6],[4],[4])]
# Arabic visible-source transcription repairs PDF font/RTL extraction errors. No translation is generated.
AR=[(1,[1],1,[1],'مساعدة المستهلكين على فهم الحوالات المالية'),(1,[4],1,[5],'مقدمو خدمة الحوالات المالية'),(1,[9],1,[9],'التحويلات المغطاة'),(1,[12],1,[10],'التحويلات غير المغطاة'),(1,[9],1,[9],'التحويلات المغطاة'),(2,[1],1,[12],'المستهلكون يرون التكاليف قبل الدفع'),(2,[5],2,[2],'ما الذي يحدث قبل الدفع'),(2,[7],2,[4],'سعر الصرف'),(2,[8],2,[5],'الرسوم والضرائب التي يتم تحصيلها من قبل الشركة'),(2,[9],2,[6],'الرسوم الأخرى المرتبطة بعملية التحويل'),(2,[10,11],2,[7],'مبلغ المال المتوقع تسليمه، والذي لا يشمل ضرائب أجنبية أو رسوم معينة مفروضة على المستلم.'),(2,[13,14],2,[9],'ماذا يحدث في أثناء الدفع'),(2,[17],2,[12],'متى سيكون المال متوفرا للمستلم'),(2,[18],2,[13],'حق المرسل في إلغاء التحويل'),(2,[19],2,[14],'ماذا تفعل في حالة وجود خطأ'),(2,[20],2,[15],'كيف تقدم شكوى'),(3,[1],2,[20],'إذا حصل خطأ في حوالة مالية')]
rows=[]
def add(lang,idx,p,ei,tp,ti,trans=None):
 en,ebox=extract(0,p,ei);raw,tbox=extract(idx,tp,ti);tx=trans or raw
 rid=hashlib.sha256((lang+'|'+en+'|'+tx).encode()).hexdigest()[:16]
 if any(r['evidence_id'].endswith(rid) for r in rows):return
 short=len(en)<90 and len(tx)<100
 rows.append({'evidence_id':'cfpb_remittance:'+lang+':'+rid,'dataset_id':'cfpb_remittance','dataset_name':'CFPB official remittance consumer-rights parallel expressions','dataset_version':'20261014','dataset_state':'candidate','source_concept_id':'cfpb_remittance:'+hashlib.sha256(en.encode()).hexdigest()[:16],'source_language':'en','english':en,'target_language':lang,'translation':tx,'availability':'present','kind':'financial_heading_or_label' if short else 'parallel_financial_passage','category':'remittance','publisher':'Consumer Financial Protection Bureau','jurisdiction':'US','review_status':'ai_visual_source_transcription' if lang=='ar' else 'ai_source_section_alignment','human_review':False,'context_required':True,'license':'CFPB-created public-domain information; third-party exceptions apply','commercial_use':True,'source':{'type':'official_parallel_pdf','url':ACQ[idx]['url'],'sha256':ACQ[idx]['sha256'],'file':ACQ[idx]['file'],'pdf_page_start':tp,'pdf_page_end':tp,'target_blocks':ti,'target_bboxes':tbox,'raw_extracted_target':raw,'english_url':ACQ[0]['url'],'english_sha256':ACQ[0]['sha256'],'english_pdf_page':p,'english_blocks':ei,'english_bboxes':ebox,'alignment_method':'same_official_fact_sheet_explicit_section_map','license_url':ACQ[4]['url'],'license_sha256':ACQ[4]['sha256']},'quality_flags':['contextual_official_parallel_text_not_expert_translation_benchmark']+(['pdf_rtl_font_extraction_repaired_from_visible_source'] if lang=='ar' else [])})
for p,en,ht,tl in MAP:
 add('ht',2,p,en,p,ht);add('tl',3,p,en,p,tl)
for p,en,tp,ti,tx in AR:add('ar',1,p,en,tp,ti,tx)
for r in rows:
 if r['target_language']=='tl' and ('Consumers generally have up to 30' in r['english']):r['quality_flags'].append('source_omits_business_day_qualifier_do_not_use_as_equivalence')
(OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
summary={'source_pdfs':4,'pair_count':len(rows),'language_counts':{l:sum(r['target_language']==l for r in rows) for l in ['ar','ht','tl']},'state':'candidate','commercial_use':True,'human_review':False,'coverage':'US remittance fact sheet sections only; not broad financial glossary','license_policy_quote':'Information created by the CFPB is in the public domain and you may reproduce, publish, or otherwise use it without the Bureau’s permission.'}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
