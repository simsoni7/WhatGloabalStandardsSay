"""Extract the supplied CFPB March 2024 PDFs using their table geometry.

This adapter deliberately fails on unknown layouts or unassigned text. New PDF
editions/languages need their own layout checks before using this extractor.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import unicodedata

import fitz

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    ('cfpb_adult-fin-ed_chinese-style-guide-glossary.pdf', 'zh-Hant',
     'Chinese (Traditional)', 297, 81),
    ('cfpb_adult-fin-ed_spanish-style-guide-glossary.pdf', 'es',
     'Spanish', 306, 86),
    ('cfpb_adult-fin-ed_korean-style-guide-glossary.pdf', 'ko',
     'Korean', 298.92, 81),
    ('cfpb_adult-fin-ed_vietnamese-style-guide-glossary.pdf', 'vi',
     'Vietnamese', 306, 82),
    ('cfpb_adult-fin-ed_russian-style-guide-glossary.pdf', 'ru',
     'Russian', 292.56, 82),
]


def flatten(text, english=False):
    # Rejoin an English hyphenated line wrap, preserving its actual hyphen.
    if english:
        text = re.sub(r'-\s*\n\s*', '-', text)
    return ' '.join(unicodedata.normalize('NFC', text).split())


def cell_text(words):
    lines = {}
    for word in words:
        lines.setdefault((word[5], word[6]), []).append(word)
    ordered = sorted(lines.values(), key=lambda line: min(w[1] for w in line))
    return '\n'.join(' '.join(w[4] for w in sorted(line, key=lambda w: w[0]))
                     for line in ordered).strip()


def extract(path, split, expected_pages):
    rows, continuations, page_counts, missing = [], [], {}, []
    with fitz.open(path) as doc:
        if len(doc) != expected_pages or 'MARCH 2024' not in doc[0].get_text():
            raise ValueError(f'Unsupported edition: {path.name}')
        for page_no in range(3, len(doc) + 1):
            page = doc[page_no - 1]
            ys = []
            for drawing in page.get_drawings():
                rect = drawing['rect']
                if abs(rect.x0 - 72) < .05 and abs(rect.x1 - split) < .05:
                    ys.extend([rect.y0, rect.y1])
            if not ys:
                raise ValueError(f'No table boundaries on page {page_no}')
            clusters = []
            for y in sorted(set(ys)):
                if clusters and y - clusters[-1][-1] < .8:
                    clusters[-1].append(y)
                else:
                    clusters.append([y])
            bounds = [sum(c) / len(c) for c in clusters]
            # Some white first/last cells have no full-width drawing.
            if page_no > 3 and bounds[0] > 73:
                bounds.insert(0, 71)
            if bounds[-1] < 710:
                bounds.append(710)
            words = [w for w in page.get_text('words')
                     if 72 <= w[0] < (544.56 if path.name == SOURCES[4][0] else 540)
                     and (w[1] + w[3]) / 2 < 710]
            used = set()
            page_counts[str(page_no)] = 0
            for lo, hi in zip(bounds, bounds[1:]):
                if hi - lo < 5:
                    continue
                cols = [[], []]
                for wi, word in enumerate(words):
                    if lo <= (word[1] + word[3]) / 2 < hi:
                        cols[0 if word[0] < split else 1].append(word)
                        used.add(wi)
                en_raw, tr_raw = map(cell_text, cols)
                en, tr = flatten(en_raw, True), flatten(tr_raw)
                if not en and not tr:
                    continue
                if en in ('English', 'Numeric') or (len(en) == 1 and en.isupper() and not tr):
                    continue
                if not en:
                    # Explicitly inspected page-spanning cells in these editions.
                    known = {
                        (SOURCES[0][0], 78): ('Undocumented', '(depending on context)'),
                        (SOURCES[4][0], 62): ('Property inspection', 'недвижимости'),
                        (SOURCES[4][0], 79): ('Uniformed and Overseas Citizens Absentee Voting Act (UOCAVA)', 'границей'),
                    }.get((path.name, page_no))
                    if not (known and rows and rows[-1]['english'] == known[0]
                            and tr == known[1] and rows[-1]['pdf_page_end'] == page_no - 1):
                        raise ValueError(f'Unexpected continuation on page {page_no}: {tr}')
                    previous = rows[-1]
                    previous['translation_raw'] += '\n' + tr_raw
                    previous['translation'] = flatten(previous['translation_raw'])
                    previous['pdf_page_end'] = page_no
                    continuations.append({'english': previous['english'], 'pages': [page_no - 1, page_no]})
                    continue
                if not tr:
                    if not (path.name == SOURCES[2][0] and page_no == 36
                            and en == 'Ghost mortgage, silent second mortgage'):
                        raise ValueError(f'Missing translation: {en}, page {page_no}')
                    missing.append({'english': en, 'pdf_page': page_no})
                rows.append(dict(english=en, english_raw=en_raw, translation=tr,
                                 translation_raw=tr_raw, pdf_page_start=page_no,
                                 pdf_page_end=page_no, source_row=len(rows) + 1,
                                 availability='present' if tr else 'missing_in_source'))
                page_counts[str(page_no)] += 1
            leftovers = [w[4] for wi, w in enumerate(words)
                         if wi not in used and w[4] != 'Glossary']
            if leftovers:
                raise ValueError(f'Unassigned text on page {page_no}: {leftovers}')
    if len(rows) != 2018:
        raise ValueError(f'Unexpected entry count in {path.name}: {len(rows)}')
    return rows, {'entries': len(rows), 'page_entry_counts': page_counts,
                  'continuations': continuations, 'unassigned_words': 0,
                  'missing_in_source': missing}


def build(output):
    # Frozen releases and the legacy output are never rebuilt in place.
    for parent in [output, *output.parents]:
        lock = parent / 'DATASET_LOCK.json'
        manifest = parent / 'manifest.json'
        if lock.exists() or (manifest.exists() and json.loads(manifest.read_text()).get('state') == 'frozen'):
            raise ValueError('Frozen dataset: use a separate --output-dir for a new candidate version.')
    output.mkdir(parents=True, exist_ok=True)
    all_rows, reports, metadata = [], {}, []
    for source_id, (filename, lang, name, split, pages) in enumerate(SOURCES, 1):
        path = ROOT / 'data' / 'sources' / filename
        rows, report = extract(path, split, pages)
        reports[lang] = report
        metadata.append((source_id, filename, f'{name}-English glossary of financial terms',
                         'Consumer Financial Protection Bureau', '2024-03',
                         hashlib.sha256(path.read_bytes()).hexdigest(), pages, lang))
        for row in rows:
            row.update(source_id=source_id, language_code=lang)
        all_rows.extend(rows)

    db_path = output / 'glossary.sqlite'
    temp_path = output / 'glossary.building.sqlite'
    if temp_path.exists():
        temp_path.unlink()
    conn = sqlite3.connect(temp_path)
    try:
        conn.executescript((ROOT / 'schema.sql').read_text())
        conn.executemany('INSERT INTO languages VALUES (?,?)',
                         [(s[1], s[2]) for s in SOURCES])
        conn.executemany('INSERT INTO sources VALUES (?,?,?,?,?,?,?,?)', metadata)
        for row in all_rows:
            key = row['english'].casefold()
            conn.execute('INSERT OR IGNORE INTO terms(english,normalized_key) VALUES (?,?)',
                         (row['english'], key))
            term_id = conn.execute('SELECT id FROM terms WHERE normalized_key=?', (key,)).fetchone()[0]
            conn.execute('''INSERT INTO translations
                (term_id, language_code, source_id, source_row, english_raw,
                 translation_raw, translation, pdf_page_start, pdf_page_end,
                 printed_page_start, printed_page_end, availability)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
                (term_id, row['language_code'], row['source_id'], row['source_row'],
                 row['english_raw'], row['translation_raw'], row['translation'] or None,
                 row['pdf_page_start'], row['pdf_page_end'],
                 row['pdf_page_start'] - 1, row['pdf_page_end'] - 1, row['availability']))
        assert conn.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert not conn.execute('PRAGMA foreign_key_check').fetchall()
        term_count = conn.execute('SELECT count(*) FROM terms').fetchone()[0]
        assert term_count == 2018, term_count
        assert conn.execute('SELECT count(*) FROM translations').fetchone()[0] == 2018 * len(SOURCES)
        assert not conn.execute('''SELECT term_id FROM translations GROUP BY term_id
                                  HAVING count(DISTINCT language_code) != ?''', (len(SOURCES),)).fetchall()
        # Regression checks for multiline, page-spanning, and last-page entries.
        expected = [
            ('Access', 'zh-Hant', '接近，進入，存取，獲得，造訪 (v.) (n.) (depending on context)'),
            ('Credit score', 'es', 'Puntaje crediticio, puntuación de crédito'),
            ('Undocumented', 'zh-Hant', '無正式文檔的，未存檔的，不合法的 (adj.) (depending on context)'),
            ('Zoning', 'es', 'Zonificación, uso de suelo'),
            ('Credit score', 'ko', '신용 점수'),
            ('Ability to repay', 'vi', 'Khả năng trả nợ'),
            ('Zoning', 'vi', 'Quy hoạch, chia thành khu vực'),
            ('Credit score', 'ru', 'Кредитная оценка'),
            ('Property inspection', 'ru', 'Осмотр недвижимости, проверка состояния недвижимости'),
        ]
        for en, lang, translation in expected:
            actual = conn.execute('SELECT translation FROM glossary_pairs WHERE english=? AND language_code=?',
                                  (en, lang)).fetchone()
            assert actual and actual[0] == translation, (en, actual)
        assert conn.execute("SELECT count(*) FROM translations WHERE availability='missing_in_source'").fetchone()[0] == 1
        assert conn.execute("SELECT availability, translation FROM glossary_pairs WHERE english=? AND language_code='ko'",
                            ('Ghost mortgage, silent second mortgage',)).fetchone() == ('missing_in_source', None)
        conn.row_factory = sqlite3.Row
        pairs = [dict(r) for r in conn.execute('SELECT * FROM glossary_pairs ORDER BY term_id,language_code')]
        conn.commit()
    finally:
        conn.close()
    temp_path.replace(db_path)
    (output / 'glossary.json').write_text(json.dumps(pairs, ensure_ascii=False, indent=2) + '\n')
    with (output / 'glossary.csv').open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(pairs[0]))
        writer.writeheader()
        writer.writerows(pairs)
    report = dict(term_count=term_count, source_entry_count=len(pairs),
                  translation_count=sum(p['availability'] == 'present' for p in pairs),
                  missing_in_source_count=sum(p['availability'] == 'missing_in_source' for p in pairs), sources=reports,
                  integrity_check='ok', foreign_key_violations=0,
                  review_status='unreviewed',
                  note='Geometry/coverage validated; all entries still require human linguistic review.')
    (output / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'sources'}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'data')
    build(parser.parse_args().output_dir.resolve())
