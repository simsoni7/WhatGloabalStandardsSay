# GnuCash 금융 소프트웨어 표현 수집 — 2026-10-14

## 확보 자료

공식 GnuCash 프로젝트의 GitHub 원본 미러에서 고정 커밋 `9e39744aac80f2737d291fcbea3fff2d357b28a5`의 영어 `msgid`와 베트남어·러시아어 `msgstr`를 동일 gettext 항목으로 연결했다. 베트남어 489쌍, 러시아어 948쌍, 합계 1,437쌍이다. 크메르어 `po/km.po`는 실제 HTTP 404로 존재가 확인되지 않아 생성하지 않았다.

은행 공인 용어집이 아니라 **금융·회계 소프트웨어의 커뮤니티 번역 UI 라벨**이다. 출처의 공식성은 원본 유지관리와 키 대응의 신뢰를 뜻하며 번역의 금융적 정답을 보증하지 않는다. 초안 번역 참고 자료로 쓸 수 있지만 법률·은행 업무·세무 목적의 확정 번역으로 사용하려면 의미와 관할권을 별도 확인해야 한다. 베트남어 `Invoice`가 `Đơn hàng gửi`로 수록되는 등 전문용어 검토가 필요한 기존 소프트웨어 표현을 수정하거나 승인하지 않았다.

## 선별 및 재현

`python -m pip install polib` 이후 `python scripts/collect_finance_oss_batch5.py`로 재현한다. 정확한 영어 msgid·msgctxt·목표 msgstr를 보존한다. finance/accounting 키워드를 포함하는 65자·8단어 이하 UI 라벨만 선정하고 fuzzy, obsolete, 빈 번역, 복수형, 문장/질문, 플레이스홀더, 마크업, 숫자 불일치, 영어와 같은 목표 번역은 제외한다. 일반 데스크톱 UI는 금융 키워드가 없으면 제외한다. `Tax Number`, `Principal`, `Interest`, `Opening Balance`, `Insurance`, `Debit`, `Credit` 등이 포함된다. 금융 용어와 소프트웨어 기능 라벨은 같은 것이 아니므로 범위명은 financial_software_ui_label이다.

자료 디렉터리: `datasets/source_collection/finance_oss_batch5/`.
- raw/: 원본 전체 PO, 전체 LICENSE, upstream README. PO의 저작권·번역 기여자 고지를 보존한다.
- evidence.jsonl: 키 대응, 파일 SHA256, 커밋, PO 위치·소스 코드 위치, 원본 표현.
- excluded.json: 제외 사유별 수량.
- acquisition.json: 실제 다운로드 URL·원본 해시와 공식 미러 근거.
- MODIFICATIONS.md: 선택·JSON 형식화 변경 고지.
- manifest.json: 모든 전달파일 해시·범위·수량·독립검수 상태.

## 라이선스와 상업 배포 조건

upstream LICENSE는 대부분의 소스에 GPL 2 또는 3을 적용하며 개별 파일 예외 확인을 요구한다. 러시아어 PO에는 패키지와 같은 라이선스라는 직접 고지가 있다. 베트남어 PO에는 FSF 저작권 고지가 있고 별도 라이선스 예외가 없으므로 저장소의 기본 GPL을 적용하는 보수적 방침이다. GPL은 비상업 전용 라이선스가 아니며 상업 사용을 허용한다. 다만 이 추출 자료는 **별도 copyleft 원출처팩**으로 관리하고 원본 저작권 고지·GPL 전문·추출 변경 고지·대응 원본 PO를 함께 제공한다. 기존 CFPB·CLDR 등 독립 자료의 라이선스를 GPL로 일괄 변경하지 않는다. 혼합 데이터나 새로운 파생 제품의 배포 조건은 결합 방식에 맞춰 확인해야 한다.

독립 검수 수용 이전에는 candidate이며 전문가 승인 번역 수는 0이다. 동일 원본을 다른 조사 에이전트가 추출한 1,815행은 중복 인계되어 별도 추가 수량으로 계산하지 않는다.

## 다른 우회 후보 조사

공식 ERPNext 고정 커밋 `a72feb79637c509ac2725ee5ca9ee1ee217bda80`에서 README와 GPL 라이선스를 확보했으나 과거 CSV 경로 `erpnext/translations/{km,vi,ru}.csv`는 모두 404였다. 해당 경로에서 자료를 얻지 못했다고 기록하며 언어가 전혀 지원되지 않는다고 단정하지 않는다. 이번 수록은 GnuCash만이며 ERPNext 자료를 용어쌍으로 생성하지 않았다.

## 크메르어 금융서비스 소프트웨어 확보

후속 실제 원출처 탐색으로 MifosX 공식 `openMF/community-app`의 고정 커밋 `45ec7b82e9b14424a53ce9e8a847811f37f431bd`에서 영어–크메르어 **629쌍**, 영어–베트남어 **861쌍**을 확보했다. 경로는 `finance_oss_batch5/mifos/`이며 별도 dataset_id `mifos_financial_ui`이다. `label.heading.collaterals`처럼 동일 명시 JSON 키에서 영어·목표언어를 연결했다. GnuCash와 같은 길이·금융범위 필터를 사용한다. 크메르어 통화명 자료와 달리 대출·계좌·담보·이자 등 금융서비스 업무 UI 자료이다. 기능명이나 항목명을 포함하므로 일반 금융사전 표제어 수와 혼동하지 않는다.

이 원출처의 실제 라이선스는 **MPL-2.0**이다. 파일 수준 copyleft와 상업 사용 허용을 구분하고 원본 전체 locale JSON·저작자 metadata·LICENSE·변경 고지·README·package.json을 전달한다. GPL인 GnuCash 팩 및 비copyleft인 기존 CFPB/CLDR 팩과 별도로 관리한다. 금융기관·감독당국의 공인 번역이 아니며 전문 번역 승인 수는 0이다.

스크립트 기본 실행은 두 원출처를 모두 수집한다. `--source gnucash` 또는 `--source mifos`로 개별 재현할 수 있다. 합계 **2,927 후보쌍**이며 독립 검수 수용 후 도입한다.

## 확장 언어 후속 차수

기존 GnuCash 1,437행·Mifos 1,490행을 수정하지 않고 `mifos_next_batch/`에 추가 확보했다. 동일 고정 commit과 영어 키 대응의 한국어 111, 스페인어 868, 힌디어 21, 네팔어 387, 인도네시아어 765, 합계 **2,152쌍**이다. `--source mifos_next_batch`로 재현한다. 한국어·힌디어·네팔어의 해당 원어 문자 존재 여부까지 검사했다. 아랍어·태국어·러시아어·몽골어·벵골어의 기본 locale 경로는 404이며 대체 로캘명이나 다른 공식 자료를 아직 확인하지 않아 생성하지 않았다. 같은 dataset_id와 commit을 사용하므로 언어가 다른 같은 금융키는 소스 관측 단위로 함께 조회할 수 있다. source_concept_id는 동일 키, evidence_id는 언어와 키의 조합이다. 전처리·허용조건·MPL 대응원문 정책은 첫 Mifos 팩과 같다. 금융 소프트웨어 문구의 실제 locale key 수이지 검증된 서로 다른 금융개념 수는 아니다. 두 소스 전체 확보 후보는 **5,079쌍**이다.
