# 캐나다 공식 영어–프랑스어 금융 표현 수집

조사일: 2026-10-14 (Asia/Seoul).

## 확보 결과

118개 명시적 영어–프랑스어 쌍을 확보했다. 정부 재정공개/계약/지원금/지출 양식 라벨 24개와 통화명 94개다. 소비자금융 일반용어집이 아니므로 118개를 FCAC 사전으로 부르거나 일반 금융용어 118개라 과장하지 않는다. FCAC와 TERMIUM 원자료는 확보되지 않았다.

원출처는 캐나다 Open Government의 공식 소프트웨어 저장소 https://github.com/open-data/ckanext-canada 이다. org 프로필은 Open Government Initiative 이름과 https://open.canada.ca 링크를 제공하며, 저장소 README 및 LICENSE도 Government of Canada CKAN Extension임을 명시한다. 해당 HTML은 alternative_4.html에 보존했다.

고정 commit: `779f849146a029e62f409ccff1f3bbc7b7cbc319`.

## 상업 이용 조건

`raw/LICENSE` 원문은 Crown Copyright, Government of Canada의 program source code를 MIT로 배포한다고 명시하며, associated documentation까지 "use, copy, modify, merge, publish, distribute, sublicense, and/or sell" 허용한다. copyright와 permission notice 보존은 의무다. 로고/Canada wordmark와 제3자 자산은 별도 조건이므로 채택하지 않았다. 이번 자료는 해당 저장소의 직접 en/fr 스키마 문자열과 currency.json 코드 리소스만 추출했다. 서버에서 내려받은 외부 정부 데이터에 MIT를 확대 적용하지 않았다.

Open Government Licence 자체는 공식 사이트 접속이 차단돼 확보하지 못했다. 이 팩의 근거는 확보한 MIT이며 OGL을 임의로 적용하지 않았다.

## 대응과 범위

- 계약금액·계약수정금액·협정금액 CAD·외화유형·외화금액·총액·총비용 등의 같은 YAML label 객체 `en`과 `fr`를 연결했다.
- 통화명은 같은 JSON 통화코드의 `en`과 `fr`를 연결했다.
- 장문 description은 같은 객체라도 상세 내용이 서로 다른 사례가 있어 일괄 추출하지 않았다.
- 원본 철자/어색한 표현은 그대로 보존했다. 전문가 언어검수는 수행하지 않았다.
- 통화명 목록은 94개인 해당 소스 스냅샷이다. 전체 세계 통화 목록이 아니며 현행 ISO 유효성 검증도 하지 않았다. 동일표현 쌍도 보존했다.
- 24 라벨 중 Agreement Type은 계약 자료/보조금 자료에서 서로 다른 프랑스어 표현이므로 출처 문맥별 두 레코드로 보존했다.

관리 검토 전 `usable=false`이며 최종 채택은 자료관리 에이전트에게 위임했다. 공개 원문에 명시적 대응이 있다는 확인이지 전문가 번역평가 정답 세트가 아니다.

## 재현과 증거

`python scripts/collect_canada.py /path/to/ckanext-canada`

`evidence.jsonl`: ID·영어·프랑스어·문맥·원문 URL·원본 SHA256·행/JSON키·license.
`manifest.json`: commit·원본 파일 및 해시·118건 실측·타입별 규모.
`raw/`: LICENSE/README와 스키마·JSON 원문.
`diagnostics.json`, `alternative_diagnostics.json`: 정상 HTTPS 실접속 결과.

FCAC canada.ca, TERMIUM btb.termiumplus.gc.ca, OGL open.canada.ca는 모두 환경 프록시 CONNECT403. FCAC-ACFC와 fcac GitHub 프로필에 수집가능한 저장소가 보이지 않았으며 공식기관 귀속도 확인되지 않아 자료로 채택하지 않았다. 보안 제한을 우회하지 않고 정상 접근가능한 공식 GitHub 원본으로 자료 경로를 변경했다.
