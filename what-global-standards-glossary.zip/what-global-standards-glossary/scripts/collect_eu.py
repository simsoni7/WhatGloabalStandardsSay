#!/usr/bin/env python3
"""Extract official EU CPV division 66 labels; never generate translations."""
import argparse, collections, gzip, hashlib, json, pathlib, urllib.request, xml.etree.ElementTree as ET
COMMIT = '41adbdae8030f3f557845d477ace04310e1cc01a'
REPO = 'https://github.com/OP-TED/eForms-SDK'
BASE = f'https://raw.githubusercontent.com/OP-TED/eForms-SDK/{COMMIT}/'
LANGS = dict(bul='bg',ces='cs',dan='da',deu='de',ell='el',spa='es',est='et',fin='fi',fra='fr',gle='ga',hrv='hr',hun='hu',ita='it',lit='lt',lav='lv',mlt='mt',nld='nl',pol='pl',por='pt',ron='ro',slk='sk',slv='sl',swe='sv')
def main():
 p=argparse.ArgumentParser();p.add_argument('--source-dir',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path,default=pathlib.Path('datasets/source_collection/eu'));args=p.parse_args()
 out=args.output;raw=out/'raw';raw.mkdir(parents=True,exist_ok=True)
 files={}
 for name in ('codelists/cpv.gc','LICENSE','README.md'):
  b=(args.source_dir/name).read_bytes() if args.source_dir else urllib.request.urlopen(BASE+name,timeout=90).read()
  dest=raw/(pathlib.Path(name).name+('.gz' if name.endswith('.gc') else ''))
  dest.write_bytes(gzip.compress(b,mtime=0) if name.endswith('.gc') else b)
  files[name]={'url':BASE+name,'path':str(dest),'source_sha256':hashlib.sha256(b).hexdigest(),'stored_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'bytes':len(b)}
 xml=gzip.decompress((raw/'cpv.gc.gz').read_bytes());root=ET.fromstring(xml);records=[];excluded=[];concepts=set()
 for row in root.findall('.//Row'):
  d={v.get('ColumnRef'):v.findtext('SimpleValue') for v in row.findall('Value')};code=d.get('code','')
  if not code.startswith('66'):continue
  en=d['eng_label'];concepts.add(code)
  for iso3,iso2 in LANGS.items():
   target=d.get(iso3+'_label')
   if not target or target==en:
    excluded.append({'code':code,'language':iso2,'reason':'english_fallback_or_missing','value':target});continue
   records.append({'evidence_id':f'eu-cpv-2008:{code}:{iso2}','dataset_id':'eu_cpv_financial_services','dataset_version':COMMIT,'dataset_state':'candidate','source_concept_id':f'eu-cpv-2008:{code}','english':en,'target_language':iso2,'translation':target,'jurisdiction':'EU','entry_type':'procurement_service_classification_label','review_status':'official_same_code_alignment_unreviewed_semantics','license':'CC-BY-4.0','source':{'publisher':'Publications Office of the European Union','repository':REPO,'url':BASE+'codelists/cpv.gc','canonical_dataset_uri':'http://publications.europa.eu/resource/dataset/cpv','cpv_code':code,'parent_code':d.get('parentCode'),'english_column':'eng_label','target_column':iso3+'_label','source_sha256':files['codelists/cpv.gc']['source_sha256']},'quality_flags':['context_limited_to_public_procurement','not_independent_translation_benchmark']})
 with (out/'evidence.jsonl').open('w') as f:
  for record in records:f.write(json.dumps(record,ensure_ascii=False)+'\n')
 (out/'excluded.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2)+'\n')
 manifest={'publisher':'Publications Office of the European Union','repository':REPO,'commit':COMMIT,'dataset_id':'eu_cpv_financial_services','records':len(records),'concepts':len(concepts),'counts_by_language':dict(sorted(collections.Counter(x['target_language'] for x in records).items())),'selection':'CPV 2008 codes starting 66: Financial and insurance services','alignment':'Same Genericode Row, English eng_label and target label linked by CPV code','license':{'id':'CC-BY-4.0','commercial_use':True,'url':BASE+'LICENSE','attribution':'Contains CPV labels from the Publications Office of the European Union, OP-TED/eForms-SDK, CC BY 4.0. Division 66 selected and English-fallback Irish labels omitted; no labels translated or edited.'},'files':files,'excluded_count':len(excluded),'limitations':['Irish labels are English fallbacks and excluded','Official alignment is not independent linguistic review','CPV service classification context; not broad consumer banking dictionary','IATE and EuroVoc original endpoints unavailable: proxy CONNECT403']}
 (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'records':len(records),'concepts':len(concepts),'languages':len(manifest['counts_by_language']),'excluded':len(excluded)}))
if __name__=='__main__':main()
