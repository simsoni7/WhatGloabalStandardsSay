"""Korean reading/search aids for English labels; never target translation approval."""
import json,unicodedata

def english_key(text):return ' '.join(unicodedata.normalize('NFKC',text or '').split()).casefold()
def load_labels(root):
 path=root/'datasets/enrichment/korean_english_labels.jsonl'
 if not path.exists():return {}
 result={}
 for line in path.read_text().splitlines():
  row=json.loads(line);key=row['key']
  if key in result or key!=english_key(row['english']) or not row['korean'].strip():raise ValueError('Invalid Korean English-label aid')
  if row['status'] not in ['source_korean_reused','ai_translated_unreviewed']:raise ValueError('Unknown Korean expression origin')
  result[key]=row
 return result

def load_overrides(root):
 path=root/'datasets/enrichment/korean_record_overrides.jsonl'
 if not path.exists():return {}
 result={}
 for line in path.read_text().splitlines():
  r=json.loads(line)
  if r['evidence_id'] in result or r['key']!=english_key(r['english']) or not r['korean'].strip() or r['status']!='ai_translated_unreviewed':raise ValueError('Invalid contextual Korean label')
  result[r['evidence_id']]=r
 return result

def attach_label(row,labels,overrides=None):
 entry=(overrides or {}).get(row['evidence_id']) or labels.get(english_key(row['source_english']))
 if entry and entry['key']!=english_key(row['source_english']):raise ValueError('Contextual Korean label differs from source English')
 if entry:
  row['source_english_korean']=entry['korean']
  row['korean_expression']={k:v for k,v in entry.items() if k in ['status','origin','source_evidence_id','note','context']}
  row['korean_expression'].update(scope='english_label_reading_and_search_aid',human_approved=False,target_equivalence_approval=False)
 else:row['source_english_korean']=None;row['korean_expression']={'status':'pending','scope':'english_label_reading_and_search_aid','human_approved':False}
 return row

def enrich_rows(rows,root):
 labels=load_labels(root);overrides=load_overrides(root)
 for r,_,_ in rows:attach_label(r,labels,overrides)
 return rows
