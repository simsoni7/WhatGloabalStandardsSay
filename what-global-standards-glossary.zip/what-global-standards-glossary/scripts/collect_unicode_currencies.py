"""Collect official CLDR currency display names by shared currency code, never generate translations."""
import collections,concurrent.futures,hashlib,json,pathlib,re,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1];OUT=ROOT/'datasets/source_collection/unicode_cldr_currencies';RAW=OUT/'raw';COMMIT='4d06be52b51bb2f75688d0abe55c52a66afed790';DATASET='unicode_cldr_currency_names'
def download(path):
 url='https://raw.githubusercontent.com/unicode-org/cldr-json/'+COMMIT+'/'+path
 with urllib.request.urlopen(url,timeout=25) as response:data=response.read(2000000);assert response.status==200
 name=path if path in ['LICENSE','README.md'] else path.split('/')[-2]+'.json';file=RAW/name;file.write_bytes(data)
 return {'url':url,'original_path':path,'file':'raw/'+name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def collect():
 RAW.mkdir(parents=True,exist_ok=True);paths=['LICENSE','README.md']+[f'cldr-json/cldr-numbers-full/main/{lang}/currencies.json' for lang in ['en','km','vi','ru']]
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:files=list(ex.map(download,paths))
 meta={r['file']:r for r in files};currencies={lang:json.loads((RAW/(lang+'.json')).read_text())['main'][lang]['numbers']['currencies'] for lang in ['en','km','vi','ru']};rows=[];excluded=[]
 for lang in ['km','vi','ru']:
  for code,obj in sorted(currencies[lang].items()):
   english=currencies['en'].get(code,{}).get('displayName');target=obj.get('displayName')
   if code in ['XXX','XTS'] or not english or not target or target==code:
    excluded.append({'language':lang,'currency_code':code,'reason':'unknown/test/fallback/missing_label'});continue
   r={'evidence_id':f'{DATASET}:{lang}:{code}','dataset_id':DATASET,'dataset_version':'CLDR-48.0.0:'+COMMIT,'dataset_state':'candidate','source_concept_id':DATASET+':currency:'+code,'source_language':'en','english':english,'target_language':lang,'translation':target,'availability':'present','kind':'currency_name','entry_type':'currency_name','category':'currency_names','publisher':'Unicode Consortium','jurisdiction':'international','currency_code':code,'definition':None,'review_status':'explicit_source_key_alignment','human_review':False,'context_required':True,'commercial_use':True,'license':'Unicode-3.0','usage_terms':{'commercial_use':True,'license':'Unicode-3.0','attribution_required':True,'license_file':'raw/LICENSE'},'quality_flags':[{'issue_type':'currency_snapshot_not_currently_validated','priority':'informational'}],'source':{'type':'official_localization_currency_data','repository':'https://github.com/unicode-org/cldr-json','commit':COMMIT,'release':'48.0.0','url':meta['raw/'+lang+'.json']['url'],'sha256':meta['raw/'+lang+'.json']['sha256'],'location':f'main/{lang}/numbers/currencies/{code}/displayName','english_url':meta['raw/en.json']['url'],'english_sha256':meta['raw/en.json']['sha256'],'english_location':f'main/en/numbers/currencies/{code}/displayName','currency_code':code,'alignment_basis':'same currency code in explicit English/target locale displayName fields','license_url':meta['raw/LICENSE']['url'],'license_sha256':meta['raw/LICENSE']['sha256'],'context':'CLDR currency-name snapshot; includes historical currencies; not a current valid-currency registry or a banking glossary'}}
   if re.search(r'\d{4}',english):r['quality_flags'].append({'issue_type':'historical_currency_qualifier_in_source','priority':'informational'})
   rows.append(r)
 (OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows));(OUT/'excluded.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2));(OUT/'acquisition.json').write_text(json.dumps({'repository':'https://github.com/unicode-org/cldr-json','commit':COMMIT,'tag':'48.0.0','files':files},ensure_ascii=False,indent=2))
 manifest={'dataset_id':DATASET,'entry_count':len(rows),'language_counts':dict(collections.Counter(r['target_language'] for r in rows)),'decision':'pending_independent_review','commercial_use':True,'usage_terms':{'commercial_use':True,'license':'Unicode-3.0','attribution_required':True,'license_file':'raw/LICENSE'},'scope':'Explicit currency display names only, including historical currencies; no ordinary loan/deposit/interest terminology','files_sha256':{str(f.relative_to(OUT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in OUT.rglob('*') if f.is_file() and f.name!='manifest.json'}}
 (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps({'records':len(rows),'language_counts':manifest['language_counts'],'excluded':len(excluded),'commercial_license':'Unicode-3.0','status':manifest['decision']}))
if __name__=='__main__':collect()
