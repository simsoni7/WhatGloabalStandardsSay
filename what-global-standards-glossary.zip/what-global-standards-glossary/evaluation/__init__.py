"""Functional source-workflow evaluation, not a language accuracy benchmark."""
