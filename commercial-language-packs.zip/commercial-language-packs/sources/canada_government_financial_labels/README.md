# Canada government financial labels

117 source-attested English–French pairs: 94 currency names and 23 government financial-reporting/contract/expenditure labels. Official Government of Canada CKAN source-code labels, not FCAC consumer guidance or TERMIUM. MIT copyright notice retained. Stable source keys establish pairing. Current currency-code validity is unverified. One suspected French typo excluded without correction. Candidate, machine reviewed, no linguistic expert review.
