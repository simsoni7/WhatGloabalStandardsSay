import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from prepare_expression import prepare


class GlossaryTests(unittest.TestCase):
    def test_five_languages_and_source_gap(self):
        with sqlite3.connect(ROOT / 'data' / 'glossary.sqlite') as db:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0], 'ok')
            self.assertEqual(db.execute('PRAGMA foreign_key_check').fetchall(), [])
            counts = dict(db.execute('SELECT language_code,count(*) FROM translations GROUP BY language_code'))
            self.assertEqual(counts, {'es': 2018, 'ko': 2018, 'ru': 2018, 'vi': 2018, 'zh-Hant': 2018})
            self.assertEqual(db.execute("SELECT count(*) FROM translations WHERE translation IS NOT NULL").fetchone()[0], 10089)

    def test_old_sources_unchanged(self):
        # Original source files, entry order and IDs remain stable as languages are added.
        result = prepare('Credit score', 'es')
        self.assertEqual(result['evidence'][0]['term_id'], 472)
        self.assertEqual(result['evidence'][0]['translation'], 'Puntaje crediticio, puntuación de crédito')
        result = prepare('Undocumented', 'zh-Hant')
        self.assertEqual(result['evidence'][0]['pdf_page_start'], 77)
        self.assertEqual(result['evidence'][0]['pdf_page_end'], 78)

    def test_literal_match_is_not_contextual_approval(self):
        result = prepare('Credit score', 'ko', '신용 점수', '대출 화면')
        self.assertEqual(result['lookup_status'], 'literal_glossary_match')
        self.assertIsNone(result['contextual_verdict'])
        self.assertIsNone(result['generated_expression'])
        self.assertEqual(result['evidence'][0]['review_status'], 'unreviewed')

    def test_vietnamese_unicode_normalization(self):
        import unicodedata
        result = prepare('Credit score', 'vi', unicodedata.normalize('NFD', 'Điểm tín dụng'))
        self.assertEqual(result['lookup_status'], 'literal_glossary_match')

    def test_unmatched_expression_is_not_rejected_as_wrong(self):
        result = prepare('Credit score', 'ko', '신용평점')
        self.assertEqual(result['lookup_status'], 'expression_not_found_in_source')
        self.assertIsNone(result['contextual_verdict'])

    def test_missing_source_does_not_generate(self):
        result = prepare('Ghost mortgage, silent second mortgage', 'ko')
        self.assertEqual(result['lookup_status'], 'missing_in_source')
        self.assertIsNone(result['evidence'][0]['translation'])
        self.assertIsNone(result['generated_expression'])

    def test_unknown_and_empty_inputs(self):
        self.assertEqual(prepare("' OR 1=1 --", 'ko')['lookup_status'], 'term_not_found')
        with self.assertRaises(ValueError):
            prepare('Credit score', 'ko', ' ')

    def test_multilingual_cli(self):
        for query, language in [('신용', 'ko'), ('tín dụng', 'vi'), ('Кредит', 'ru')]:
            output = subprocess.check_output([sys.executable, str(ROOT / 'scripts/search_glossary.py'),
                                              query, '--language', language], text=True)
            rows = json.loads(output)
            self.assertTrue(rows)
            self.assertTrue(all(r['language_code'] == language for r in rows))

    def test_unsupported_language_is_not_unknown_term(self):
        result = prepare('Credit score', 'fr', 'score de crédit')
        self.assertEqual(result['lookup_status'], 'language_not_supported')
        self.assertTrue(result['term_found'])
        self.assertFalse(result['target_language_supported'])
        self.assertEqual(result['evidence'], [])
        self.assertEqual(len(result['reference_evidence']), 5)
        self.assertIsNone(result['contextual_verdict'])
        self.assertIsNone(result['generated_expression'])

    def test_locale_does_not_silently_use_base_language(self):
        result = prepare('Credit score', 'es-MX')
        self.assertEqual(result['lookup_status'], 'language_not_supported')
        self.assertEqual(result['evidence'], [])

    def test_unsupported_language_unknown_term(self):
        result = prepare('Unknown made-up term 874', 'fr')
        self.assertEqual(result['lookup_status'], 'term_not_found')
        self.assertEqual(result['reference_evidence'], [])

    def test_language_tag_case(self):
        self.assertEqual(prepare('Credit score', 'RU')['lookup_status'], 'evidence_found')


if __name__ == '__main__':
    unittest.main()
