"""Capture candidate pages with free local Chromium; preserve TLS verification."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
from urllib.parse import urlsplit, unquote

from playwright.sync_api import sync_playwright, Error

ROOT = Path(__file__).resolve().parents[1]
TARGETS = {
    'nepalbank': 'https://www.nepalbank.com.np/personal/services/mobile-banking',
    'mongolbank': 'https://toli.mongolbank.mn/',
}


def launch_options():
    executable = shutil.which('chromium') or shutil.which('google-chrome')
    options = {'headless': True}
    if executable:
        options['executable_path'] = executable
    proxy = os.environ.get('HTTPS_PROXY') or os.environ.get('HTTP_PROXY')
    if proxy:
        parsed = urlsplit(proxy)
        options['proxy'] = {'server': f'{parsed.scheme}://{parsed.hostname}:{parsed.port or 80}'}
        if parsed.username:
            options['proxy']['username'] = unquote(parsed.username)
        if parsed.password:
            options['proxy']['password'] = unquote(parsed.password)
    return options


def capture(page, dataset, url, root=ROOT):
    now = datetime.now(timezone.utc)
    directory = root / 'datasets' / dataset / 'candidate' / 'captures' / now.strftime('%Y%m%dT%H%M%S%fZ')
    directory.mkdir(parents=True, exist_ok=False)
    record = {'dataset_id': dataset, 'requested_url': url, 'retrieved_at': now.isoformat(),
              'collector': 'Playwright Chromium', 'pair_count': 0, 'review_status': 'unreviewed'}
    try:
        response = page.goto(url, wait_until='domcontentloaded', timeout=25000)
        record.update(final_url=page.url, source_http_status=response.status if response else None)
        if response is None or not 200 <= response.status < 300:
            record.update(status='failed', error_code='non_success_http')
        else:
            page.locator('body').wait_for(timeout=10000)
            # Rendered DOM is separate from the server's original response.
            files = {'response.html': response.text(), 'rendered.html': page.content(),
                     'body.txt': page.inner_text('body'),
                     'links.json': json.dumps(page.locator('a[href]').evaluate_all(
                         '(links) => links.map(a => ({text:a.innerText, url:a.href, hreflang:a.hreflang}))'),
                         ensure_ascii=False, indent=2)}
            for name, content in files.items():
                (directory / name).write_text(content, encoding='utf-8')
            page.screenshot(path=str(directory / 'page.png'), full_page=True)
            record.update(status='captured', title=page.title(),
                          note='Unreviewed page capture; inspect language alignment and page validity before extraction.',
                          files_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                        for p in directory.iterdir() if p.is_file()})
    except Error as exc:
        # Persist a stable diagnostic, not headers or raw errors that could expose proxy credentials.
        message = str(exc)
        code = next((c for c in ['ERR_CERT_AUTHORITY_INVALID', 'ERR_CERT_DATE_INVALID',
                                'ERR_TUNNEL_CONNECTION_FAILED', 'ERR_CONNECTION_RESET',
                                'ERR_CONNECTION_TIMED_OUT'] if c in message), 'browser_navigation_error')
        record.update(status='failed', error_code=code)
    (directory / 'capture.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    return directory, record


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dataset', choices=[*TARGETS, 'all'])
    args = parser.parse_args()
    targets = TARGETS.items() if args.dataset == 'all' else [(args.dataset, TARGETS[args.dataset])]
    failed = False
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(**launch_options())
        try:
            for dataset, url in targets:
                context = browser.new_context()  # TLS checks stay enabled.
                try:
                    directory, record = capture(context.new_page(), dataset, url)
                    print(json.dumps({'dataset': dataset, 'status': record['status'],
                                      'error_code': record.get('error_code'), 'directory': str(directory)}))
                    failed |= record['status'] != 'captured'
                finally:
                    context.close()
        finally:
            browser.close()
    raise SystemExit(1 if failed else 0)
