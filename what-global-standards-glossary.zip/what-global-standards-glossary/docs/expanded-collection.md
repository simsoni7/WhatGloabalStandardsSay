# 확장 수집 결과와 재사용

## 몽골은행 경제·금융 용어집 후보

공개 화면 코드에 등장하는 `https://etoli.mn/api/letterswithgroup`가 정상 데이터를 반환한다. `id`는 문자, `locale`은 `en` 또는 `mn`, `group=0`은 전체 분류다. 영어 A–Z와 몽골어 문자 목록을 양쪽 언어로 수집하고, 원문에서 관찰한 숫자·혼합 문자 접두사도 추가했다. 빈 접두사 요청은 실패했으므로 사용하지 않는다. 로그인·유료 서비스·TLS 검증 해제는 사용하지 않았다.

- 원본 ID 기준 **3,643개 항목**, 모두 영어·몽골어 표기와 몽골어 정의가 있다.
- 완전히 같은 표기 쌍은 3,589개다. 분류/정의가 다른 항목은 같은 표기라도 ID별로 보존한다.
- 11개 분류를 수집했다. 현재 성공한 문자 조회 응답은 83개이며, 마지막 수집의 실패한 조회는 0개다.
- 영어 표기에 키릴 문자가 섞인 항목 2개는 원문을 보존하고 CSV에 표시했다. 임의로 영문 철자를 교정하지 않았다.
- 사이트 소개의 “3,650개 이상”은 공식 총수 검증 API가 아니다. 수집 범위가 상당히 넓어졌지만 완전 수집이라고 단정하지 않는다.

현재 결과: `datasets/mongolbank/candidate/crawls/20261012T151757300882Z/`

`candidate.sqlite`에는 표기·정의·분류·원본 ID·사이트 상태·원본 날짜와 응답별 출처가 있다. `term_candidates.csv`, `evidence.jsonl`, 원본 응답 JSON, 해시·누락·충돌 검사 `report.json`도 제공한다.

```bash
python3 scripts/collect_mongolbank.py
# 기존 성공 응답을 재사용하며 누락 조회를 보완할 때
python3 scripts/collect_mongolbank.py --seed-run datasets/mongolbank/candidate/crawls/20261012T151757300882Z
```

## 네팔은행 금융 표현 후보

예금·대출·송금·카드·모바일뱅킹·수수료·금리 페이지로 범위를 확대했다. 공개 링크를 따라가는 제한된 BFS 수집이며, 인증서가 정상인 apex 주소와 두 개의 언어 세션을 사용했다. 성공한 원문은 재수집 없이 해시 검증 후 재사용할 수 있다.

- **127개 페이지쌍, 영어·네팔어 HTML 254개**
- 중복 제거한 용어·제목 60쌍, 제목류 1쌍, 짧은 표현 46쌍: 합계 **107개 후보**
- 별도로 **문장·목록 용례 110쌍**
- 세 종류의 수수료 페이지에 해당하는 9개 주소는 HTTP 500을 반환해 실패로 기록했다. 같은 실패를 무한 재시도하지 않는다.
- 현재 금융 범위에서 발견한 후속 링크는 모두 처리했으며 페이지 상한에 걸린 잔여 링크는 없다. 뉴스·인사·공시 등 금융 상품 설명 밖의 영역을 포함한 전체 사이트 수집은 아니다.

현재 결과: `datasets/nepalbank/candidate/crawls/20261012T152120919160Z/`

HTML 원문, CSV 2개, 후보 DB, 공통 근거 JSONL, 페이지별 출처와 정렬 위치, 실패 목록과 보고서가 있다. 동일 링크 대상의 고유한 이름을 대응시킨 자료와 같은 페이지의 문단 순서로 대응한 자료를 구분한다. `<br>`가 잘못 중첩된 원문에서도 내용을 버리지 않고 논리적 줄로 변환했다. 줄 수가 다르면 연결하지 않으며, 숫자·요금·날짜의 차이나 의미 차이는 별도 검수가 필요하다. 네팔어를 선택해도 영어로 남는 본문은 번역 쌍으로 넣지 않았다.

```bash
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python scripts/crawl_nepalbank.py --max-pages 200
# 실제 수집한 원문을 재사용해 범위/정렬 방법을 개선할 때
.venv/bin/python scripts/crawl_nepalbank.py --max-pages 200 --seed-run datasets/nepalbank/candidate/crawls/20261012T152120919160Z
```

## AI가 참고하는 공통 조회

두 용어집은 아직 **검수 전 후보**다. 기존 고정 버전 `cfpd용어집 v1`은 그대로 두며, 새 후보를 자동으로 고정/검수 완료로 승격하지 않는다. 단순 문자열 일치나 같은 문단 수가 문맥 적합성을 보장하지 않는다.

```bash
python3 scripts/reference_glossaries.py 'Credit Card' --language mn --dataset mongolbank --include-candidates
python3 scripts/reference_glossaries.py 'Saving Account' --language ne --dataset nepalbank --include-candidates
```

기본 조회는 기존처럼 고정 용어집만 참고한다. `--include-candidates`를 명시하면 후보의 해시를 확인하고 `dataset_state=candidate`, 버전, 출처, 정의/용례 위치를 함께 반환한다. 문장·목록 정렬은 더 약한 후보이므로 `--include-passages`가 있어야 조회한다. 서로 다른 분류나 출처의 충돌은 합치지 않는다. 모델 호출, 최종 번역과 문맥 검수는 아직 구현하지 않았으며 판단 결과는 `null`로 유지한다.
