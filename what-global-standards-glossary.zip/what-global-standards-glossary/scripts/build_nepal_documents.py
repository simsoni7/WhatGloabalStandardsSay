"""Build a separate source-backed supplement from visually checked bilingual forms."""
import csv,hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def build():
 p=ROOT/'datasets/nepalbank/candidate/document-expansion'
 sources={r['file']:r for r in json.loads((p/'sources.json').read_text()) if 'error' not in r}
 rows=[];seen=set()
 for x in csv.DictReader((p/'visually-checked-pairs.tsv').open(),delimiter='\t'):
  src=sources[x['document']];f=p/src['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==src['sha256']
  pair=(x['english'],x['nepali']);assert pair not in seen;seen.add(pair)
  eid='nepalbank:forms:'+hashlib.sha256(('\0'.join(pair)).encode()).hexdigest()[:16]
  rows.append({'evidence_id':eid,'dataset_id':'nepalbank','dataset_name':'Nepal Bank bilingual financial forms','dataset_version':'forms-20261013','source_language':'en','english':x['english'],'target_language':'ne','translation':x['nepali'],'availability':'present','kind':'financial_form_label','category':x['category'],'review_status':'ai_visual_source_check','publisher':'Nepal Bank Limited','jurisdiction':'NP','dataset_state':'candidate','human_review':False,'context_required':True,'source':{'type':'bilingual_pdf_form','url':src['url'],'file':src['file'],'sha256':src['sha256'],'pdf_page_start':int(x['page']),'pdf_page_end':int(x['page']),'alignment_method':'explicit_bilingual_label_visually_checked','context':'Use within the originating banking form; source wording retained.'},'quality_flags':[]})
 (p/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 report={'entry_count':len(rows),'state':'candidate','human_review':False,'files_sha256':{'evidence.jsonl':hashlib.sha256((p/'evidence.jsonl').read_bytes()).hexdigest()},'collected_documents':len(sources),'ocr_pages':len(json.loads((p/'ocr-status.json').read_text())),'selected_documents':len({x['source']['file'] for x in rows}),'note':'Bank form labels, not a comprehensive Nepalese terminology dictionary; visual source transcription checked by AI.'}
 (p/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':build()
