import sys
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from collect_public_glossaries import align


class PublicCollectorTests(unittest.TestCase):
    def test_requires_actual_nepali_session(self):
        english = '<option selected value="en">English</option>'
        with self.assertRaises(ValueError):
            align(english, english)

    def test_ambiguous_link_labels_are_not_forced_into_pairs(self):
        english = '''<option selected value="en">English</option>
        <a href="/personal/services/mobile-banking">Mobile Banking</a>
        <a href="/personal/products/saving-account">Savings</a>
        <a href="/personal/products/saving-account">Saving Account</a>'''
        nepali = '''<option selected value="np">नेपाली</option>
        <a href="/personal/services/mobile-banking">मोबाइल बैंकिङ</a>
        <a href="/personal/products/saving-account">बचत खाता</a>'''
        pairs, ambiguous = align(english, nepali)
        self.assertEqual(len(pairs), 1)
        self.assertEqual(pairs[0]['english'], 'Mobile Banking')
        self.assertEqual(ambiguous, ['/personal/products/saving-account'])


if __name__ == '__main__':
    unittest.main()
