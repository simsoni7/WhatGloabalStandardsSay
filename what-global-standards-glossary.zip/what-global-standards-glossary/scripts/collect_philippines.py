#!/usr/bin/env python3
"""Acquire official Philippine source evidence, without inventing translations.
No pairs are emitted unless independent alignment and commercial-license review
have succeeded. HTTP failures and search pages are not language data.
"""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request

TARGETS = [
    ('bsp_home_www', 'https://www.bsp.gov.ph/', 'official_entrypoint'),
    ('bsp_home_apex', 'https://bsp.gov.ph/', 'official_entrypoint'),
    ('bsp_financial_education', 'https://www.bsp.gov.ph/Pages/InclusiveFinance/FinancialEducation.aspx', 'candidate_path_not_verified'),
    ('bsp_terms', 'https://www.bsp.gov.ph/Pages/TermsandConditions.aspx', 'candidate_path_not_verified'),
    ('pdic_home', 'https://www.pdic.gov.ph/', 'official_entrypoint'),
    ('sec_home', 'https://www.sec.gov.ph/', 'official_entrypoint'),
    ('copyright_law', 'https://lawphil.net/statutes/repacts/ra1997/ra_8293_1997.html', 'legal_reference_requires_reading'),
    ('official_gazette_home', 'https://www.officialgazette.gov.ph/', 'official_entrypoint'),
    ('github_bsp_search', 'https://github.com/search?q=%22Bangko+Sentral%22&type=repositories', 'discovery_only'),
]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default='datasets/source_collection/philippines')
    args = parser.parse_args()
    out = Path(args.output)
    raw = out / 'raw'
    raw.mkdir(parents=True, exist_ok=True)
    records = []
    for name, url, kind in TARGETS:
        record = {'id': name, 'url': url, 'kind': kind, 'checked_at': dt.datetime.now(dt.timezone.utc).isoformat()}
        request = urllib.request.Request(url, headers={'User-Agent': 'FinancialGlossarySourceResearch/1.0'})
        try:
            with urllib.request.urlopen(request, timeout=25) as response:
                body = response.read()
                record.update(status=response.status, final_url=response.url,
                              content_type=response.headers.get('Content-Type'), bytes=len(body),
                              sha256=hashlib.sha256(body).hexdigest())
                path = raw / (name + '.html')
                path.write_bytes(body)
                record['file'] = str(path.relative_to(out))
        except (urllib.error.URLError, TimeoutError) as error:
            record['error'] = str(error)
            record['status'] = getattr(error, 'code', None)
            record['failure_layer'] = 'environment_proxy' if 'Tunnel connection failed: 403' in str(error) else 'http_or_network'
        records.append(record)
    manifest = {'checked_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'requests': records,
                'acquired_financial_pairs': 0, 'commercial_license_verified': False,
                'adoption_status': 'blocked_pending_official_content_and_commercial_permission'}
    (out / 'acquisition.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    (out / 'evidence.jsonl').write_text('')
    print(json.dumps({'requests': len(records), 'successful_requests': sum('sha256' in r for r in records),
                      'financial_pairs': 0}, ensure_ascii=False))

if __name__ == '__main__':
    main()
