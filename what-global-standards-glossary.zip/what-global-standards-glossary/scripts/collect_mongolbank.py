"""Collect publicly displayed dictionary records through the working category API."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sqlite3
import string
import time
import shutil
from urllib.parse import urlencode

from collect_public_glossaries import ROOT, fetch

CYRILLIC = 'АБВГДЕЁЖЗИЙКЛМНОӨПРСТУҮФХЦЧШЩЪЬЫЭЮЯ'


def parse_response(raw):
    obj = json.loads(raw)
    data = obj.get('data')
    if not isinstance(data, dict) or data.get('success') is not True or not isinstance(data.get('data'), list):
        raise ValueError('API returned an error or malformed data, not dictionary records.')
    for row in data['data']:
        if not isinstance(row, dict) or 'ID' not in row or 'WORD_EN' not in row or 'WORD_MN' not in row:
            raise ValueError('Dictionary entry is missing required source fields.')
    return data['data']


def collect(workers=2, seed_run=None):
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    candidate = ROOT / 'datasets/mongolbank/candidate'
    run = candidate / 'crawls' / stamp; (run / 'responses').mkdir(parents=True)
    records, occurrences, responses, failures, conflicts = {}, {}, [], [], []
    pending = ({(c, 'en') for c in string.ascii_uppercase} | {(c, 'mn') for c in CYRILLIC}
               | {(c,locale) for c in string.digits for locale in ['en','mn']})
    done = set()
    if seed_run:
        seed_run = seed_run.resolve()
        if not seed_run.is_relative_to(candidate.resolve() / 'crawls'):
            raise ValueError('Seed must be a previous Mongolian dictionary crawl.')
        previous = json.loads((seed_run / 'progress.json').read_text())
        for source in previous['responses']:
            old = seed_run / source['source']['file']
            if hashlib.sha256(old.read_bytes()).hexdigest() != source['source']['sha256']:
                raise ValueError('Cached API source checksum mismatch')
            target = run / source['source']['file']; shutil.copy2(old,target)
            source = {**source,'source':{**source['source'],'reused_from_run':str(seed_run.relative_to(ROOT))}}
            responses.append(source);done.add((source['prefix'],source['locale']))
            for row in parse_response(target.read_text()):
                identity=str(row['ID']);records[identity]=row;occurrences.setdefault(identity,[]).append(source)
        pending.difference_update(done)

    def query(item):
        prefix, locale = item
        url = 'https://etoli.mn/api/letterswithgroup?' + urlencode({'id':prefix,'locale':locale,'group':0})
        name = locale + '-' + hashlib.sha256(prefix.encode()).hexdigest()[:12] + '.json'
        path = run / 'responses' / name
        try:
            meta = fetch(url, path);rows = parse_response(path.read_text())
            time.sleep(.3)
            return {'prefix':prefix,'locale':locale,'count':len(rows),'source':{**meta,'file':'responses/'+name},'rows':rows}
        except (RuntimeError, ValueError, json.JSONDecodeError) as exc:
            return {'prefix':prefix,'locale':locale,'error':str(exc)}

    with ThreadPoolExecutor(max_workers=workers) as pool:
        while pending:
            batch = sorted(pending); pending.clear(); done.update(batch)
            for future in as_completed([pool.submit(query,item) for item in batch]):
                result = future.result()
                if 'error' in result:
                    failures.append(result);print('Failed prefix:',result['locale'],result['prefix'],flush=True);continue
                source = {k:result[k] for k in ['prefix','locale','count','source']}; responses.append(source)
                for row in result['rows']:
                    identity = str(row['ID'])
                    if identity in records and records[identity] != row:
                        conflicts.append({'source_id':identity,'response':source,'note':'Source entry changed or differed across queries.'})
                    else:
                        records[identity] = row
                    occurrences.setdefault(identity,[]).append(source)
                    # Cover mixed-script prefixes observed in the source, without editing spelling.
                    for field, locale in [('WORD_EN','en'),('WORD_MN','mn')]:
                        word = (row.get(field) or '').strip()
                        if word:
                            item = (word[0].upper(),locale)
                            if item not in done:pending.add(item)
                print(f"{result['locale']} {result['prefix']}: {result['count']} rows, {len(records)} unique source IDs",flush=True)
                (run / 'progress.json').write_text(json.dumps({'unique_source_count':len(records),'responses':responses,'failures':failures},ensure_ascii=False,indent=2))

    entries = sorted(records.values(),key=lambda r:int(r['ID']))
    pairs = [r for r in entries if (r.get('WORD_EN') or '').strip() and (r.get('WORD_MN') or '').strip()]
    with sqlite3.connect(run / 'candidate.sqlite') as db:
        db.executescript('''CREATE TABLE entries(source_id INTEGER PRIMARY KEY,english TEXT,mongolian TEXT,
            definition_mn TEXT,group_id INTEGER,source_status TEXT,source_created_at TEXT,source_updated_at TEXT,
            review_status TEXT,source_json TEXT);
            CREATE TABLE source_responses(id INTEGER PRIMARY KEY,metadata_json TEXT);
            CREATE TABLE entry_sources(source_id INTEGER REFERENCES entries(source_id),response_id INTEGER REFERENCES source_responses(id));
            PRAGMA foreign_keys=ON;''')
        for row in entries:
            db.execute('INSERT INTO entries VALUES (?,?,?,?,?,?,?,?,?,?)',
                       (row['ID'],row.get('WORD_EN'),row.get('WORD_MN'),row.get('DESCRIPTION'),row.get('GROUP_ID'),
                        str(row.get('STATUS')),row.get('CREATED_DATE'),row.get('UPDATED_DATE'),'unreviewed',json.dumps(row,ensure_ascii=False)))
        for i,response in enumerate(responses,1):
            db.execute('INSERT INTO source_responses VALUES (?,?)',(i,json.dumps(response,ensure_ascii=False)))
            for identity, refs in occurrences.items():
                if response in refs:db.execute('INSERT INTO entry_sources VALUES (?,?)',(int(identity),i))
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
    with (run / 'term_candidates.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=['source_id','english','mongolian','definition_mn','group_id','review_status','mixed_script_english']);writer.writeheader()
        for row in pairs:
            writer.writerow({'source_id':row['ID'],'english':row['WORD_EN'],'mongolian':row['WORD_MN'],
                             'definition_mn':row.get('DESCRIPTION'),'group_id':row.get('GROUP_ID'),'review_status':'unreviewed',
                             'mixed_script_english':any('\u0400'<=c<='\u04ff' for c in row['WORD_EN'])})
    with (run / 'evidence.jsonl').open('w',encoding='utf-8') as f:
        for row in pairs:
            identity=str(row['ID'])
            record={'evidence_id':f'mongolbank:candidate:{stamp}:{identity}','dataset_id':'mongolbank',
                    'dataset_name':'몽골은행 경제·금융 용어집 후보','dataset_version':'candidate-'+stamp,
                    'english':row['WORD_EN'],'source_language':'en','target_language':'mn','translation':row['WORD_MN'],
                    'definition':{'language':'mn','text':row.get('DESCRIPTION')},'availability':'present','review_status':'unreviewed',
                    'publisher':'Bank of Mongolia dictionary project','jurisdiction':'MN',
                    'source':{'type':'public_dictionary_api','source_id':row['ID'],'group_id':row.get('GROUP_ID'),
                              'source_status':row.get('STATUS'),'retrieved_at':stamp,'responses':occurrences[identity]}}
            f.write(json.dumps(record,ensure_ascii=False)+'\n')
    report={'source_entry_count':len(entries),'pair_count':len(pairs),
            'unique_spelling_pair_count':len({(r['WORD_EN'],r['WORD_MN']) for r in pairs}),
            'definition_count':sum(bool((r.get('DESCRIPTION') or '').strip()) for r in pairs),
            'missing_pair_source_ids':[r['ID'] for r in entries if r not in pairs],
            'groups':{str(g):sum(r.get('GROUP_ID')==g for r in entries) for g in sorted({r.get('GROUP_ID') for r in entries},key=str)},
            'mixed_script_english_count':sum(any('\u0400'<=c<='\u04ff' for c in r['WORD_EN']) for r in pairs),
            'failed_prefix_queries':failures,'conflicting_source_records':conflicts,
            'response_count':len(responses),'tls_verification':'enabled','review_status':'unreviewed',
            'coverage_note':'Union of English A-Z, Mongolian alphabet and digit-prefix listings, plus observed mixed-script prefixes. No official total-count endpoint verified; do not claim exhaustive coverage.',
            'files_sha256':{str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in run.rglob('*') if p.is_file()}}
    (run / 'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    manifest_path=candidate/'manifest.json';manifest=json.loads(manifest_path.read_text())
    manifest.update(pair_count=len(pairs),last_crawl=str(run.relative_to(ROOT)),inspection_status='dictionary_api_collected',
                    pair_structure_verified=True,review_status='unreviewed',collector='curl verified HTTPS public category API',
                    last_observation='Working category/letter API returns original English, Mongolian and definitions.')
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'run':str(run),'pairs':len(pairs),'definitions':report['definition_count'],'failed_queries':len(failures)},ensure_ascii=False),flush=True)


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workers',type=int,choices=[1,2],default=2)
    p.add_argument('--seed-run',type=Path);args=p.parse_args()
    collect(args.workers,args.seed_run)
