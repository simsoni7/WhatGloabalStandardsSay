"""Export default usable reference entries with complete JSONL provenance."""
from pathlib import Path
import csv,hashlib,json,sqlite3,zipfile,collections
ROOT=Path(__file__).resolve().parents[1]
def export():
 p=ROOT/'dist/data';p.mkdir(parents=True,exist_ok=True)
 with sqlite3.connect(ROOT/'datasets/derived/reference_index.sqlite') as db:rows=[json.loads(x[0]) for x in db.execute("SELECT payload FROM entries WHERE usable=1 AND translation IS NOT NULL AND translation!='' ORDER BY dataset_id,evidence_id")]
 (p/'glossary_entries.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 fields=['evidence_id','dataset_id','dataset_version','dataset_state','source_concept_id','english','target_language','translation','jurisdiction','review_status','kind','category','context_required','source_json','quality_flags_json']
 with (p/'glossary_entries.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for r in rows:
   s={k:v for k,v in r['source'].items() if isinstance(v,(str,int,float,bool,type(None))) and (not isinstance(v,str) or len(v)<2000)}
   s['full_provenance']='glossary_entries.jsonl#'+r['evidence_id'];o={k:r.get(k,'') for k in fields if not k.endswith('_json')};o['source_json']=json.dumps(s,ensure_ascii=False);o['quality_flags_json']=json.dumps(r.get('quality_flags',[]),ensure_ascii=False);w.writerow(o)
 c={'format_version':1,'entry_count':len(rows),'counts_by_dataset':dict(collections.Counter(r['dataset_id'] for r in rows)),'counts_by_language':dict(collections.Counter(r['target_language'] for r in rows)),'languages':sorted({r['target_language'] for r in rows}),'nepal_note':f"66 original records plus {sum(r.get('kind')=='financial_form_label' for r in rows)} source-backed bilingual form labels visually checked by AI. Not human-reviewed; originating form context required.",'csv_note':'Compact source locators in CSV; complete provenance in JSONL.','review_note':'Source matches do not establish contextual correctness. Candidate records and AI-assisted checks retain explicit status.','files':{}}
 registry=ROOT/'datasets/language_packs/registry.json'
 if registry.exists():
  c['reference_language_packs']=[]
  c['benchmarks']=[]
  for pack in json.loads(registry.read_text())['packs']:
   if pack['decision'] not in ['accepted_reference','accepted_benchmark']:continue
   manifest=json.loads((ROOT/pack['path']/'manifest.json').read_text())
   if pack['decision']=='accepted_reference':
    c['reference_language_packs'].append({'dataset_id':pack['dataset_id'],'entry_count':manifest['entry_count'],'state':pack['state'],'manifest':manifest})
   else:
    base=(ROOT/pack['path']).resolve()
    if not base.is_relative_to((ROOT/'datasets/language_packs').resolve()):raise ValueError('Benchmark path escapes language packs')
    for name,digest in manifest['files_sha256'].items():
     file=(base/name).resolve()
     if not file.is_relative_to(base) or hashlib.sha256(file.read_bytes()).hexdigest()!=digest:
      raise ValueError('Benchmark artifact checksum or path invalid')
    c['benchmarks'].append({'dataset_id':pack['dataset_id'],'state':pack['state'],'manifest':manifest})
 c['benchmark_note']='Reference terminology is not an independent translation-quality benchmark. No live-model accuracy score is claimed.'
 for name in ['glossary_entries.csv','glossary_entries.jsonl']:
  b=(p/name).read_bytes();c['files'][name]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 (p/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
 with zipfile.ZipFile(ROOT/'dist/glossaries-data.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(p.iterdir()):
   if f.is_file():z.write(f,'glossaries-data/'+f.name)
  if registry.exists():
   for pack in json.loads(registry.read_text())['packs']:
    if pack['decision']!='accepted_benchmark':continue
    base=ROOT/pack['path'];manifest=json.loads((base/'manifest.json').read_text())
    for name in ['manifest.json',*manifest['files_sha256']]:
     z.write(base/name,'glossaries-data/benchmarks/'+pack['dataset_id']+'/'+name)
 with (p/'glossary_entries.csv').open(encoding='utf-8-sig',newline='') as f:assert len(list(csv.DictReader(f)))==len(rows)
 print(json.dumps(c,ensure_ascii=False))
if __name__=='__main__':export()
