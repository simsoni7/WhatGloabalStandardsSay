"""Resolve structural findings and publish a non-destructive retrieval overlay."""
from collections import Counter
from datetime import datetime,timezone
from decimal import Decimal
import hashlib,json,re,unicodedata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def numeric_values(text,language='en'):
    text=''.join(str(unicodedata.decimal(c)) if c.isdecimal() else c for c in text)
    if language=='ne':
        for phrase,value in [('एक लाख','100000'),('एक हजार','1000'),('दुई','2')]:
            text=text.replace(phrase,value)
    text=re.sub(r'(?<=\d)\s*,\s*(?=\d)',',',text)
    result=[]
    for token in re.findall(r'\d+(?:[.,]\d+)*',text):
        if ',' in token and re.fullmatch(r'\d{1,3}(?:,\d{2,3})+',token):token=token.replace(',','')
        try:result.append(str(Decimal(token).normalize()))
        except Exception:result.append(token)
    return Counter(result)


def resolve():
    pointer=json.loads((ROOT/'datasets/quality_audits/latest.json').read_text());audit=ROOT/pointer['path']
    issues=json.loads((audit/'issues.json').read_text());report=json.loads((audit/'report.json').read_text())
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out=ROOT/'datasets/derived/quality'/stamp;out.mkdir(parents=True)
    resolutions=[];aliases=[];blocked=[]
    for i,issue in enumerate(issues,1):
        kind=issue['issue_type'];details=issue['details'];status='controlled_not_semantically_reviewed'
        if kind=='mixed_script_english':
            proposed=details['english'].translate(str.maketrans({'А':'A','с':'c'}))
            aliases.append({'alias':proposed,'evidence_ids':issue['evidence_ids'],'status':'spelling_proposal','original':details['english']})
            action='Retain original spelling; expose proposed alias with review flag.'
        elif kind=='numeric_tokens_differ':
            if numeric_values(details['english'])==numeric_values(details['nepali'],'ne'):
                status='numeric_values_equivalent_only';action='Clear numeric-format/order false alarm; semantic review remains pending.'
            elif details['english']=='Download Apply Now':
                status='incorrect_alignment_excluded';action='UI controls were paired with benefits; exclude from reference translation.';blocked.extend(issue['evidence_ids'])
            elif '159 branches' in details['english']:
                status='source_versions_conflict';action='Preserve 159/231 branch-count conflict; do not choose a current value.';blocked.extend(issue['evidence_ids'])
            else:
                status='incorrect_alignment_excluded';action='Women savings benefit order differs; exclude ordinal pairing and use explicit source mapping.';blocked.extend(issue['evidence_ids'])
        elif kind=='same_english_multiple_translations':action='Keep source senses separate; require sense/context selection.'
        elif kind=='duplicate_pair_multiple_entries':action='Keep source IDs, definitions and groups; do not collapse source senses.'
        elif kind=='tentative_ordinal_alignment':action='Exclude unreviewed ordinal passages/short expressions from default translation index.'
        else:action='Keep unmatched source sections out of translation evidence; retain original files.'
        resolutions.append({'issue_id':i,'issue_type':kind,'status':status,'evidence_ids':issue['evidence_ids'],'action':action})
    ne_run=ROOT/report['input_runs']['nepalbank'];pages=json.loads((ne_run/'progress.json').read_text())['pages']
    page=next(p for p in pages if p['path']=='/personal/products/saving-account/women-special-saving')
    from bs4 import BeautifulSoup
    lists={}
    for lang in ['en','ne']:
        source=page['sources'][lang];path=ne_run/source['file']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=source['sha256']:raise ValueError('Reference source changed')
        soup=BeautifulSoup(path.read_text(),'html.parser')
        lists[lang]=[' '.join(e.get_text(' ',strip=True).split()) for e in soup.select('section.inner-content .col-lg-8 .tab-pane li')]
    if len(lists['en'])!=6 or len(lists['ne'])!=6:raise ValueError('Women savings source structure changed')
    patches=[]
    for i,j in enumerate([0,5,1,2,3,4]):
        patches.append({'evidence_id':f'nepalbank:alignment-review:{stamp}:{i}', 'dataset_id':'nepalbank',
            'dataset_version':'alignment-review-'+stamp,'english':lists['en'][i],'translation':lists['ne'][j],
            'source_language':'en','target_language':'ne','availability':'present','kind':'source_expression',
            'review_status':'ai_assisted_alignment_review','human_review':False,'publisher':'Nepal Bank Limited','jurisdiction':'NP',
            'source':{'type':'explicit_benefit_alignment','input_run':str(ne_run.relative_to(ROOT)),
                      'page':page,'english_locator':f'.tab-pane li[{i}]','nepali_locator':f'.tab-pane li[{j}]'},
            'quality_note':'Reference alignment checked against original benefits; not a jurisdiction/legal approval.'})
    correct_pairs={(p['english'],p['translation']) for p in patches}
    for line in (ne_run/'evidence.jsonl').read_text().splitlines():
        record=json.loads(line)
        women_features=any(o['page']['path']=='/personal/products/saving-account/women-special-saving'
            and ('.tab-pane li' in o['locator'] or (o['locator'].startswith('logical_content_line[')
                 and int(o['locator'].split('[')[1].split(']')[0]) in range(1,7)))
            for o in record['source']['occurrences'])
        if record['english']=='Download Apply Now' or (women_features and (record['english'],record['translation']) not in correct_pairs):
            blocked.append(record['evidence_id'])
    release={'input_runs':report['input_runs'],'audit_path':pointer['path'],'resolutions':resolutions,
             'aliases':aliases,'blocked_evidence_ids':sorted(set(blocked)),'patches':patches,
             'ordinal_policy':'exclude_unreviewed_passages_and_short_expressions_from_default_retrieval',
             'human_review_complete':False,'state':'derived_reference_overlay'}
    (out/'release.json').write_text(json.dumps(release,ensure_ascii=False,indent=2)+'\n')
    summary={'resolution_counts':dict(Counter(r['status'] for r in resolutions)),
             'reviewed_alignment_patch_count':len(patches),'alias_proposal_count':len(aliases),
             'release_sha256':hashlib.sha256((out/'release.json').read_bytes()).hexdigest()}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'datasets/derived/quality/latest.json').write_text(json.dumps({'path':str(out.relative_to(ROOT))},indent=2)+'\n')
    print(json.dumps({'path':str(out),**summary},ensure_ascii=False))


if __name__=='__main__':resolve()
