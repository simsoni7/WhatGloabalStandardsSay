# 은행 소프트웨어 추가 조사 6차

## 실제 확보

Mifos Initiative의 공식 `openMF/mifos-mobile` 저장소 고정 커밋 `18a6499ffef39c1cfac69be4a8fdbef84485e536`에서 금융 명사·명사구 65개 리소스 키를 선정했다. 실제 영어·현지어 동일 Android XML 키로 관측한 974쌍, 17개 언어다. 영어 fallback, 누락, placeholder, markup, 중복은 제외했다. 크메르어 56, 러시아어 56, 힌디어 63, 인도네시아어 55, 벵골어 56, 우르두어 57쌍을 포함한다.

이는 실제 금융계좌 조회·예금·대출·이자·상환·수취인·송금 화면의 upstream 문구이지 중앙은행 금융 사전이나 전문가 승인 번역이 아니다. 원문 저작자의 언어 품질을 인증하지 않는다. 정의를 새로 만들어 출처 정의로 표시하지 않았다. `Loan Account`, `Savings Account` 등 금융 문맥이 분명한 키만 수록하고 로그인 account, 일반 Share, 번역용 dotted identifier, 안내 오류 문장은 제외했다. `Principal`, `Interest`, `Nominal Interest Rate`, `Ann. Interest Rate`는 개별 영어 관측과 키를 유지한다. 모든 행은 생성 금지·언어전문가 검토필요·approved_translation null이다.

## 이용조건

실제 루트 LICENSE 및 모든 확보 XML의 파일별 헤더는 **MPL-2.0**이다. 상업 이용은 허용되지만 permissive 자료로 분류하지 않는다. 반드시 copyleft 보조팩에 분리하고 원문 LICENSE/저작권·MPL 헤더/공개 원문 및 수정사항을 보존해야 한다. 루트 NOTICE 파일은 관측되지 않았다. 일부 XML 헤더는 잘못된 upstream `mobile-mobile/LICENSE.md` 링크를 포함하므로 그 헤더 자체를 수정하지 않고 실제 저장소 LICENSE 링크를 provenance에 별도로 기록했다.

## 다른 조사와 전환

- `openMF/web-app` HEAD `e175e1cd021b97bc03e0245694bf13d98f6cc707`: 기대와 달리 실제 LICENSE는 MPL-2.0. Apache 기본팩 후보로 거절.
- `frappe/books`: 실제 LICENSE는 AGPL-3.0. 이번 차수 미수집. 명칭이나 저장소 공식성으로 permissive라고 추측하지 않았다.
- 모바일 저장소는 독립 소스이며 앞 차수 community-app/GnuCash/OFBiz 파일을 재포장하지 않았다. 타 소스와 동일 표현일 수는 있으므로 통합시 별도 증거 ID를 유지해야 한다.

재현: `python3 scripts/collect_banking_batch6.py`. 고정 commit 원문과 SHA256은 manifest 및 각 행 source에 있다. 독립 검수 전 자료는 후보다.

## 독립 검수에서 실제 발견한 위험

원본 관측이 존재한다는 이유로 금융 사전 등가표현이라고 채택하지 않는다. 검수 중 러시아어 Principal=Директор, Interest=Интерес; 인도네시아어 Principal=Direktur, Interest Type=Jenis minat; 크메르어 Principal=នាយក 등 금융 의미와 다른 원문이 발견됐다. 일부 Outstanding Balance는 '훌륭한/뛰어난 잔액'이라는 직역이며 Beneficiary는 '상속인'으로 번역됐다. 힌디어 Nominal Interest Rate의 nominal도 '작은/사소한'으로 번역된 의심이 있다.

이 원문은 증거 파일에서는 보존하되 독립 검수 accepted IDs에서 제거한다. 따라서 **974는 수집 관측 수이며 사전에 수록하는 검수 통과 수가 아니다**. 최종 수록은 별도 검수 결정과 실제 의미위험 제외 목록에 의해 줄어든다. 보조팩에 수록돼도 전문가 승인과 자동생성 가능성을 의미하지 않는다.
