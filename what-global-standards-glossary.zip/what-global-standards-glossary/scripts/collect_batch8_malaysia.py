#!/usr/bin/env python3
"""Collect actual bilingual financial labels from pinned official MIT metadata.
No translated inference, paragraph alignment or storage-host access bypass.
"""
import concurrent.futures, datetime, hashlib, json, pathlib, re, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'datasets/source_collection/batch8_malaysia'
COMMIT='a34682cf22a1da9de5520a27f5f3fc5f7c86b06f'
BASE=f'https://raw.githubusercontent.com/data-gov-my/datagovmy-meta/{COMMIT}/'
NAMES=['interestrates','interestrates_annual','monetary_aggregates','payment_instruments','payment_channels','payment_systems','state_finance_revenue','state_finance_expenditure','federal_finance_year_revenue','federal_finance_year_oe','federal_finance_year_debt_mat','federal_finance_year_de','federal_finance_year','bop_balance','fdi_flows','epf_dividend','gdp_annual_nominal_income','hh_income','hh_expenditure_dun','currency_in_circulation','currency_in_circulation_annual','exchangerates','exchangerates_daily_1700']
GENERIC={'x','y1','y2','date','series','state','district','parlimen','dun','variable','value','type','category','component','komponen','object','function','sector','measure','instrument','channel','system','bank','rate','volume','total','other','abs','growth-yoy','gdp','m1-total','m2-total','m3-total','0-3','3-5','5-10','10-15','15+','conventional','shariah'}
# Original labels fail sense/granularity check, even though key alignment is real.
CAUTIONS={('monetary_aggregates','m3-deposit-other'):'Malay adds Kadar (rate) absent from English deposits label',('state_finance_revenue','total'):'English says Total Expenditure but Malay says Total Revenue',('bop_balance','account'):'English Account Type vs generic Malay Account',('federal_finance_year_oe','retirement-charges'):'Malay Bayaraan appears misspelled; not silently corrected'}
FIELDS_RE=re.compile(r'interest|debt|income|expenditure|revenue|dividend|exchange rate|currency|bank|deposit|borrowing|maturity|balance|reserve|investment|tax|surplus|subsid|emolument',re.I)
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def fetch(path):
 url=BASE+path
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'FinancialGlossarySourceResearch/1.0'}),timeout=40) as r:b=r.read()
 dest=OUT/'raw'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 return path,{'url':url,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'file':str(dest.relative_to(ROOT))}
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 files=dict(concurrent.futures.ThreadPoolExecutor(6).map(fetch,['LICENSE']+[f'data-catalogue/{n}.json' for n in NAMES]))
 assert 'MIT License' in (OUT/'raw/LICENSE').read_text()
 seen=set()
 # Exact duplicates of source English/Malay strings, independent of source key/ID.
 for p in [ROOT/'dist/data/glossary_entries.jsonl',ROOT/'datasets/source_collection/batch7_asia/evidence.jsonl']:
  if p.exists():
   for line in p.read_text().splitlines():
    r=json.loads(line)
    if r.get('target_language')=='ms':seen.add((r.get('source_english',r.get('english','')).strip().casefold(),r.get('source_target',r.get('translation','')).strip().casefold()))
 rows=[];excluded=[]
 def add(name,pointer,en,ms,raw,context,reason=None):
  if not isinstance(en,str) or not isinstance(ms,str):return
  e,t=en.strip(),ms.strip();why=reason
  if not e or not t:why='empty source value'
  elif 'Acutal' in e or 'Perbelajaan' in t:why='source spelling error not silently corrected'
  elif name=='gdp_annual_nominal_income' and pointer=='fields.2.title':why='income component metadata incorrectly labels field Expenditure Type'
  elif e.casefold()==t.casefold():why='identical source strings / untranslated or borrowed expression'
  elif len(e)>130 or len(e.split())>19:why='not a short financial label'
  pair=(e.casefold(),t.casefold())
  if pair in seen:why='existing or intra-batch exact English/Malay pair'
  if why:excluded.append({'file':name,'source_key':pointer,'english':en,'translation':ms,'reason':why});return
  seen.add(pair);path=f'data-catalogue/{name}.json';m=files[path];eid=f'malaysia_financial_metadata:ms:{name}:{pointer}'
  rows.append({'evidence_id':eid,'dataset_id':'malaysia_financial_metadata','dataset_version':COMMIT,'source_concept_id':f'malaysia_financial_metadata:{name}:{pointer}','source_english':e,'source_target':t,'english':e,'translation':t,'source_language':'en','target_language':'ms','kind':'financial_statistical_indicator_label','category':name,'jurisdiction':'MY','license':'MIT','commercial_use':True,'approved_translation':None,'generation_eligible':False,'human_review':False,'context_required':True,'quality_flags':['official_government_metadata_label','not_normative_glossary','context_required','upstream_translation_not_expert_approved'],'source':{'url':m['url'],'raw_url':m['url'],'file':m['file'],'sha256':m['sha256'],'english_url':m['url'],'english_file':m['file'],'english_sha256':m['sha256'],'source_key':pointer,'raw_english_value':en,'raw_target_value':ms,'normalization':'outer_whitespace_trim_only','alignment':'same_metadata_file_same_field_or_dictionary_key','publisher':'Government of Malaysia / data-gov-my','repository':'https://github.com/data-gov-my/datagovmy-meta','commit':COMMIT,'context':context,'english_definition':raw.get('description_en'),'target_definition':raw.get('description_ms')}})
 for name in NAMES:
  d=json.loads((OUT/'raw/data-catalogue'/f'{name}.json').read_text());context={'dataset_title_en':d.get('title_en'),'dataset_title_ms':d.get('title_ms'),'data_source':d.get('data_source',[]),'scope':'statistical dataset metadata; not universal financial term equivalence'}
  add(name,'title',d.get('title_en'),d.get('title_ms'),d,context)
  en,ms=d.get('translations_en',{}),d.get('translations_ms',{})
  for key in sorted(en.keys() & ms.keys()):
   why=CAUTIONS.get((name,key)) or ('generic category/chart label' if key in GENERIC or key in {'avg','end','high','indicator','low','start','rate_type','y11','admin','agriculture','community','defence','economy','education','health','housing','social','trade','transport','utilities','internet-corp','internet-indiv','mobile'} else None)
   if name.startswith('currency_in_circulation'):why='denomination series labels; banknote Nota sense and numeric variation not admitted'
   if name=='hh_expenditure_dun':why='Malay Perbelajaan appears misspelled'
   if name=='state_finance_expenditure' and key=='oe_40000':why='Malay adds grants absent from English Fixed Payments'
   add(name,'translations.'+key,en[key],ms[key],d,context,why)
  for i,f in enumerate(d.get('fields',[])):
   if FIELDS_RE.search(f.get('title_en','')):
    add(name,f'fields.{i}.title',f.get('title_en'),f.get('title_ms'),f,context)
 rows.sort(key=lambda r:r['evidence_id'])
 (OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 dump(OUT/'excluded.json',excluded)
 manifest={'dataset_id':'malaysia_financial_metadata','publisher':'Government of Malaysia / data-gov-my','source_repository':'https://github.com/data-gov-my/datagovmy-meta','commit':COMMIT,'license':'MIT','commercial_use':True,'license_file':'raw/LICENSE','files':files,'entry_count':len(rows),'counts_by_language':{'ms':len(rows)},'evidence_sha256':hashlib.sha256((OUT/'evidence.jsonl').read_bytes()).hexdigest(),'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'human_review':False,'generation_eligible':False,'scope':'Short source-paired statistical financial labels; source observations, not expert approval.'}
 dump(OUT/'manifest.json',manifest)
 print(json.dumps({'entry_count':len(rows),'excluded':len(excluded)},ensure_ascii=False))
if __name__=='__main__':main()
