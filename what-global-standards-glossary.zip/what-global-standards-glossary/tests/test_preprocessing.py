import unittest
from glossary_app.index import Index
from glossary_app.engine import Engine
from glossary_app.preprocess import preprocess

class IntegrationTests(unittest.TestCase):
 def test_interest_rate_observations_not_silently_corrected(self):
  index=Index();observations=index.lookup('Interest rate','mn','mongolbank')
  by_id={str(r['source']['source_id']):r for r in observations}
  self.assertEqual(by_id['304']['source_target'],'Хүү')
  self.assertEqual(by_id['737']['source_target'],'Хүүгийн хувь')
  self.assertEqual(by_id['3377']['source_target'],'Хүүгийн хувь хэмжээ')
  for r in by_id.values():
   self.assertIsNone(r['approved_translation']);self.assertEqual(r['equivalence_status'],'needs_review')
   self.assertNotIn('translation',r);self.assertNotIn('english',r)
  self.assertEqual(by_id['304']['semantic_triage']['status'],'suspected_mismatch')
 def test_selected_suspect_source_still_requires_review(self):
  r=Engine().process({'operation':'translate','english_term':'Interest Rate','target_language':'mn','source_concept_id':'mongolbank:entry:304'})
  self.assertEqual(r['status'],'quality_review_required');self.assertIsNone(r['source_quoted_text']);self.assertIsNone(r['translated_text'])
 def test_model_cannot_approve_unreviewed_source(self):
  def model(request,evidence):return {'assessment':'supported','proposed_translation':'Хүү','citations':[evidence[0]['evidence_id']],'rationale':'simulated','questions':[]}
  r=Engine(model=model).process({'operation':'translate','english_term':'Interest Rate','target_language':'mn','source_concept_id':'mongolbank:entry:304','mode':'model'})
  self.assertEqual(r['contextual_verdict'],'needs_review');self.assertIsNone(r['approved_translation']);self.assertTrue(r['review_required'])
 def test_cross_source_spelling_does_not_merge_concepts(self):
  rows=[]
  for d in ['a','b']:
   rows.append(({'evidence_id':d+':1','dataset_id':d,'english':'Loan','translation':'X','target_language':'fr','jurisdiction':'US','source':{},'quality_flags':[]},d+':concept:1',True))
  records,issues,links,report=preprocess(rows)
  self.assertEqual(len({r[1] for r in records}),2);self.assertEqual(len(links),1);self.assertFalse(links[0]['merge_authorized'])
 def test_source_alignment_never_creates_approval(self):
  r=Engine().process({'operation':'translate','english_term':'Credit Card','target_language':'mn','context':'Banking label'})
  self.assertEqual(r['source_quoted_text'],'Зээлийн карт');self.assertIsNone(r['approved_translation']);self.assertIsNone(r['translated_text'])
if __name__=='__main__':unittest.main()
