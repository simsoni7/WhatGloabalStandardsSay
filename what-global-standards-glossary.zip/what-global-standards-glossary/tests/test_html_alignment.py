import sys
from pathlib import Path
import unittest
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from crawl_nepalbank import logical_lines,extract


class HtmlAlignmentTests(unittest.TestCase):
    def test_malformed_nested_breaks_preserve_all_text(self):
        soup=BeautifulSoup('<div><p>first<br>second<br>third</br></br></p></div>','html.parser')
        self.assertEqual(logical_lines(soup.div),['first','second','third'])

    def test_untranslated_content_is_not_bilingual_candidate(self):
        en='<select id="languageLink"><option selected value="en"></option></select><section class="inner-content"><h1>Loan</h1><div class="col-lg-8"><p>Loan description.</p></div></section>'
        ne=en.replace('value="en"','value="np"')
        rows,_,_=extract(en,ne)
        self.assertEqual(rows,[])

    def test_different_section_counts_are_not_forced(self):
        en='<select id="languageLink"><option selected value="en"></option></select><section class="inner-content"><div class="col-lg-8"><p>A</p><p>B</p></div></section>'
        ne='<select id="languageLink"><option selected value="np"></option></select><section class="inner-content"><div class="col-lg-8"><p>खाता</p></div></section>'
        rows,skipped,_=extract(en,ne)
        self.assertFalse(rows)
        self.assertTrue(any(s['reason']=='count_mismatch' for s in skipped))


if __name__=='__main__':
    unittest.main()
