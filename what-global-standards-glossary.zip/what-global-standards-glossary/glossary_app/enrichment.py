"""Activate only hash-bound independent-review accepted AI candidate artifacts."""
from pathlib import Path
import hashlib,json

def accepted_records(root,kind):
 base=(root/'datasets/enrichment').resolve();review=base/'review/decisions.json'
 if not review.exists():return []
 result=[]
 for artifact in json.loads(review.read_text()).get('accepted_inputs',[]):
  if artifact['kind']!=kind:continue
  path=(root/artifact['path']).resolve()
  if not path.is_relative_to(base) or hashlib.sha256(path.read_bytes()).hexdigest()!=artifact['sha256']:
   raise ValueError('Accepted enrichment artifact changed; independent re-review required')
  if path.suffix=='.jsonl':items=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
  else:
   value=json.loads(path.read_text());items=value.get('decisions',[]) if isinstance(value,dict) else value
  id_key={'financial_concepts':'concept_id','semantic_decisions':'decision_id','context_cases':'case_id'}[kind]
  accepted=set(artifact['accepted_ids']);ids={r[id_key] for r in items}
  if not accepted.issubset(ids):raise ValueError('Accepted enrichment ID missing')
  result.extend(r for r in items if r[id_key] in accepted)
 return result

def concept_cards(root,records):
 cards=accepted_records(root,'financial_concepts');evidence={r['evidence_id']:r for r,_,_ in records}
 for card in cards:
  if card.get('human_review') is not False or card.get('official_definition') is not False or card.get('approved_translation') is not None:
   raise ValueError('AI financial card cannot declare expert/source approval')
  if card.get('definition_origin')!='ai_written_explanation':raise ValueError('AI definition provenance required')
  for eid in card['source_evidence_ids']:
   if eid not in evidence or not evidence[eid]['reference_usable'] or not evidence[eid]['generation_eligible']:
    raise ValueError('Financial card maps invalid or quarantined evidence')
  if set(card['proposed_source_concept_ids'])!={evidence[e]['source_concept_id'] for e in card['source_evidence_ids']}:
   raise ValueError('Financial card source-concept mapping inconsistent')
 return cards

def commercial_cards(cards,approved):
 result=[]
 for original in cards:
  card=dict(original);sources=[r for r in card['source_evidence'] if r['dataset_id'] in approved and r.get('commercial_policy_allowed') is True]
  if not sources:continue
  card['source_evidence']=sources;card['source_evidence_ids']=[r['evidence_id'] for r in sources]
  card['proposed_source_concept_ids']=sorted({r['source_concept_id'] for r in sources})
  card.pop('suspected_references',None)
  if card['concept_id']=='finance:capital_financial':
   card['risk_notes']=['Broad capital labels require financial/accounting scope clarification.' if 'Source 1044' in note else note for note in card['risk_notes']]
  scope=dict(card['jurisdiction_scope']);scope['source_jurisdictions']=sorted({{'cfpd':'US','cfpb_remittance':'US','canada_government_financial_labels':'CA','eu_cpv_financial_services':'EU'}[r['dataset_id']] for r in sources});card['jurisdiction_scope']=scope
  card['export_note']='Only commercially permitted evidence retained; AI explanation remains a candidate, not source/expert definition.'
  result.append(card)
 return result
