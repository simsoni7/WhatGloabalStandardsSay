# EU 공식 금융·보험 서비스 언어팩 수집 결과

2026-10-14. IATE/EuroVoc 원서버 접근을 먼저 시도했지만 환경 프록시 CONNECT 403으로 원문·조건을 확보하지 못했다. 비공식 복제본을 대신 채택하지 않았다.

대체 공식 출처는 EU Publications Office가 직접 관리하는 [OP-TED/eForms-SDK](https://github.com/OP-TED/eForms-SDK)이다. 원본 README는 관리기관을 명시하고, LICENSE는 **Creative Commons Attribution 4.0 International**이다. 상업 이용 가능하며 출처 표시·라이선스 표시·변경 내역 표시가 필요하다. 이를 manifest에 보존했다. 원본은 commit `41adbdae8030f3f557845d477ace04310e1cc01a`로 고정했다.

## 확보 범위

- CPV 2008 분류 코드 **66: Financial and insurance services** 아래 **89개 개념**.
- 각 XML Genericode Row의 같은 CPV 코드에 있는 `eng_label`과 대상언어 label을 연결했다. 번역 생성과 문장 순서 추정은 하지 않았다.
- **22개 대상언어, 언어당 89건, 총 1,958개 영어–대상언어 쌍**.
- 언어: bg, cs, da, de, el, es, et, fi, fr, hr, hu, it, lt, lv, mt, nl, pl, pt, ro, sk, sl, sv.
- 아일랜드어 ga는 89개 모두 영어가 그대로 들어간 fallback이므로 **전량 제외**했다. excluded.json에 보존했다.
- 스페인어는 기존 언어의 다른 EU 조달 문맥을 추가하며 나머지 21개는 기존 7개 대상언어와 다른 언어다.

## 표본: 영어 → 독일어

| 코드 | 영어 | 독일어 |
|---|---|---|
| 66112000 | Deposit services | Einlagengeschäft |
| 66113000 | Credit granting services | Kreditgewährung |
| 66114000 | Financial leasing services | Finanzierungs-Leasing |
| 66510000 | Insurance services | Versicherungen |

## 도입 제약

이는 **정부조달용 금융·보험 서비스 분류명**이다. 일반 금융 소비자 사전, 개별 상품 정의 또는 독립 번역 품질평가 정답으로 확대 해석하면 안 된다. EU 조달 문맥과 원 CPV 코드 및 parent code를 유지해 참고 언어팩으로 사용할 수 있다. 공식 동일코드 대응이지만 별도 전문가 언어 검수는 하지 않았다. 원 분류에서 서비스 범주를 보존하므로 “Deposit services”를 단독 “deposit”과 같은 개념으로 자동 합치지 않는다.

## 파일과 검증

- `evidence.jsonl`: 1,958개 대응 레코드와 고정 commit URL, 원문 SHA256, CPV 코드, 라이선스.
- `manifest.json`: 22개 언어별 건수, 라이선스·기여표시와 파일 해시.
- `raw/cpv.gc.gz`: **전체 원본 XML을 무손실 gzip**. source_sha256는 압축 해제 XML, stored_sha256는 gzip 파일 기준.
- `raw/LICENSE`, `raw/README.md`: 원본 라이선스와 공식 발행기관 증거.
- `excluded.json`: 영어 fallback 89건.
- `scripts/collect_eu.py`: 고정 commit에서 재수집하거나 로컬 체크아웃에서 추출.

1,958 evidence ID의 유일성, 번역 공백·영어동일값 없음, 언어별 89건, 독일어 표본을 검증했다. 기존 DB와 배포 ZIP은 변경하지 않았다.

## 접근 실패 기록

정상 HTTPS로 접근했으나 다음 EU 원서버는 proxy CONNECT403이었다: `op.europa.eu`, `iate.europa.eu`, `publications.europa.eu`, `data.europa.eu`, `showvoc.op.europa.eu`. GitHub 공식 저장소 clone은 성공했다. 이 결과로 IATE/EuroVoc 수집 완료를 주장하지 않는다.
