"""Generate a self-contained, read-only financial dictionary from immutable source pairs."""
import collections,hashlib,json,pathlib,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
LANGUAGES={'ar': '아랍어', 'bg': '불가리아어', 'cs': '체코어', 'da': '덴마크어', 'de': '독일어', 'el': '그리스어', 'en': '영어', 'es': '스페인어', 'et': '에스토니아어', 'fi': '핀란드어', 'fr': '프랑스어', 'hr': '크로아티아어', 'ht': '아이티 크리올어', 'hu': '헝가리어', 'it': '이탈리아어', 'ko': '한국어', 'km': '크메르어', 'hi': '힌디어', 'th': '태국어', 'ja': '일본어', 'id': '인도네시아어', 'zh-Hans': '중국어 (간체)', 'lt': '리투아니아어', 'lv': '라트비아어', 'mn': '몽골어', 'mt': '몰타어', 'ne': '네팔어', 'nl': '네덜란드어', 'pl': '폴란드어', 'pt': '포르투갈어', 'ro': '루마니아어', 'ru': '러시아어', 'sk': '슬로바키아어', 'sl': '슬로베니아어', 'sv': '스웨덴어', 'tl': '타갈로그어', 'vi': '베트남어', 'zh-Hant': '중국어 (번체)'}
LANGUAGES.update({'bn':'벵골어','fa':'페르시아어','kn':'칸나다어','ml':'말라얄람어','my':'미얀마어','sw':'스와힐리어','te':'텔루구어','ur':'우르두어'})
def build():
 source=ROOT/'dist/data/glossary_entries.jsonl';rows=[]
 for r in map(json.loads,source.open()):
  row={k:r.get(k) for k in ('evidence_id','dataset_id','dataset_version','source_concept_id','source_english','source_target','target_language','jurisdiction','record_type','definition','source','alignment_basis','alignment_status')}
  row['source_notes']=[]
  if r.get('generation_eligible') is False:
   row['source_notes'].append('소프트웨어 문맥 원문이라 무조건적 자동 생성에서 기본 제외합니다.' if r.get('generation_policy_reason') else '원문 표현 또는 금융 의미의 대응에 문제가 의심되는 항목입니다. 원문은 보존하며 확정 번역 근거로 사용하지 않습니다.')
   if (r.get('semantic_review') or {}).get('rationale'):row['source_notes'].append(r['semantic_review']['rationale'])
  semantic=r.get('semantic_review') or {}
  if semantic.get('source_definition_scope_suspicion'):
   row['source_notes'].append('원문 정의의 범위에 관한 AI 분석상 의문이 있습니다. '+str(semantic.get('usage_constraint','')))
  rows.append(row)
 sources=json.loads((ROOT/'dictionary/sources.json').read_text())
 for entry in sources:
  if entry['dataset_id']=='canada_government_financial_labels':
   entry['license_notice']=(ROOT/'datasets/source_collection/canada/raw/LICENSE').read_text()
   entry['attribution']='Contains unchanged bilingual labels from Government of Canada Open Data / ckanext-canada, commit 779f849146a029e62f409ccff1f3bbc7b7cbc319. Crown Copyright, Government of Canada. MIT License; trademarks excluded.'
  if entry['dataset_id']=='apache_ofbiz_accounting':
   entry['license_notice']=(ROOT/'datasets/language_packs/apache_ofbiz_accounting/raw/LICENSE').read_text()+'\n\n'+(ROOT/'datasets/language_packs/apache_ofbiz_accounting/raw/NOTICE').read_text()
   entry['attribution']='Contains selected unchanged financial/accounting XML labels from Apache OFBiz, commit b8b72d556e829d4a0818f8a4fed57e0750efcacb, Apache-2.0; outer whitespace normalized and raw values retained. LICENSE and NOTICE preserved.'
  if entry['dataset_id']=='unicode_cldr_currency_names':
   entry['license_notice']=(ROOT/'datasets/language_packs/unicode_cldr_currency_names/raw/LICENSE').read_text()
   entry['attribution']='Contains unchanged displayName values from Unicode Consortium CLDR JSON 48.0.0, commit 4d06be52b51bb2f75688d0abe55c52a66afed790, Unicode-3.0. English paired by currency code with km/vi/ru; unknown/test/fallback labels excluded.'
  if entry['dataset_id']=='eu_cpv_financial_services':
   entry['license_notice']=(ROOT/'datasets/source_collection/eu/raw/LICENSE').read_text()
   entry['attribution']='Contains CPV labels from the Publications Office of the European Union, OP-TED/eForms-SDK, commit 41adbdae8030f3f557845d477ace04310e1cc01a, CC BY 4.0. Division 66 selected and English-fallback Irish labels omitted; no labels translated or edited.'
 assert set(r['dataset_id'] for r in rows)==set(s['dataset_id'] for s in sources if not s.get('copyleft'))
 assert set(r['target_language'] for r in rows)<=LANGUAGES.keys()
 community_catalog=json.loads((ROOT/'dist/community/catalog.json').read_text()) if (ROOT/'dist/community/catalog.json').exists() else {'components':[],'entry_count':0,'counts_by_language':{}}
 for component in community_catalog['components']:
  dataset=component['dataset_id'];pack=ROOT/component['source_pack'];terms=component['usage_terms'];license_path=terms.get('license_file','raw/LICENSE');license_notice=(pack/license_path).read_text()
  item={'dataset_id':dataset,'name':'GnuCash · 회계 커뮤니티 표현' if dataset.startswith('gnucash') else 'Mifos · 은행·소액금융 커뮤니티 표현','publisher':'Official upstream software project / localization contributors','authority':'공식 소프트웨어 프로젝트의 고정 커밋·원본 로케일·라이선스를 확인했습니다. 금융기관 공인 번역이나 전문 번역 정답은 아닙니다.','collection':'동일 gettext 문맥/메시지 또는 JSON key의 영어·대상언어 원문을 대응했습니다. 빈 값·fuzzy·영어 그대로인 항목·placeholder/숫자 불일치 후보를 제외하고 원문·수집 스크립트를 제공합니다.','scope':'회계·대출·예금·담보·원금·이자 등 금융 소프트웨어 표현. 원출처 문맥과 번역 품질의 한계를 유지합니다.','limitations':'커뮤니티 번역에는 의미 혼동이 있습니다. 모든 행을 자동 생성 참고에서 기본 제외하며 명시적 위험 목록도 완전한 오류 목록이 아닙니다.','license':terms['license']+' · 상업 사용은 가능하지만 copyleft·대응 소스 제공·고지 조건을 지켜야 합니다. 기본 상업 데이터팩과 별도 파일로 배포합니다.','commercial':True,'community':True,'entry_count':component['entry_count'],'license_notice':license_notice,'urls':['https://github.com/Gnucash/gnucash' if dataset.startswith('gnucash') else 'https://github.com/openMF/community-app'],'conditional_download':'https://raw.githubusercontent.com/simsoni7/WhatGloabalStandardsSay/dictionary-20261015-r6/conditional-community-language-packs.zip'}
  
  if dataset=='mifos_mobile_banking':
   item.update(name='Mifos Mobile · 모바일 금융 커뮤니티 표현',collection='동일 Android XML resource key의 영어·대상언어 원문을 고정 commit에서 수집했습니다. fallback·placeholder·중복 및 금융 의미 의심 47개를 제외했습니다.',urls=['https://github.com/openMF/mifos-mobile'])
  sources.append(item);component['url']='https://raw.githubusercontent.com/simsoni7/WhatGloabalStandardsSay/dictionary-20261015-r6/community/'+component['file']
 candidates_file=ROOT/'datasets/expansion_research/candidates.json'
 payload={'offline_bundle':False,'snapshot':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':rows,'sources':sources,'community_entries':community_catalog['entry_count'],'community_catalog':community_catalog,'languages':LANGUAGES,'candidates':json.loads(candidates_file.read_text()) if candidates_file.exists() else {'candidates':[]},'built_date':'2026-10-15','release_ref':'dictionary-20261015-r6','downloads':{'community_zip':'https://raw.githubusercontent.com/simsoni7/WhatGloabalStandardsSay/dictionary-20261015-r6/conditional-community-language-packs.zip','data_zip':'https://raw.githubusercontent.com/simsoni7/WhatGloabalStandardsSay/dictionary-20261015-r6/glossaries-data.zip','dictionary_zip':'https://raw.githubusercontent.com/simsoni7/WhatGloabalStandardsSay/dictionary-20261015-r6/financial-dictionary.zip'}}
 encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 out=ROOT/'dist/financial-dictionary.html';out.write_text((ROOT/'dictionary/template.html').read_text().replace('__DATA__',encoded))
 with zipfile.ZipFile(ROOT/'dist/financial-dictionary.zip','w',zipfile.ZIP_DEFLATED) as z:
  z.writestr('financial-dictionary.html',out.read_text().replace('"offline_bundle":false','"offline_bundle":true',1));z.write(ROOT/'docs/financial-dictionary.md','README.md')
  z.writestr('OFFLINE-BUNDLE.md','Offline wrappers serialize the unchanged separately licensed source JSON for browser loading. Canonical JSON, source files, licenses, and modification notices are under community-components/. The independent components retain their individual licenses. Keep all extracted directories alongside financial-dictionary.html.')
  # Separate source files remain separate, including offline wrappers and corresponding licenses/source.
  for component in community_catalog['components']:
   body=(ROOT/'dist/community'/component['file']).read_text()
   wrapper='window.offlineCommunityData['+json.dumps(component['dataset_id'])+']='+json.dumps(body,ensure_ascii=False)+';\n'
   z.writestr('community/'+component['file']+'.js',wrapper)
  with zipfile.ZipFile(ROOT/'dist/conditional-community-language-packs.zip') as components_zip:
   for name in components_zip.namelist():z.writestr(name,components_zip.read(name))

  z.write(ROOT/'datasets/language_packs/apache_ofbiz_accounting/raw/LICENSE','licenses/apache-2.0.txt')
  z.write(ROOT/'datasets/language_packs/apache_ofbiz_accounting/raw/NOTICE','licenses/apache-NOTICE.txt')
  z.write(ROOT/'datasets/language_packs/unicode_cldr_currency_names/raw/LICENSE','licenses/unicode-3.0.txt')
  z.write(ROOT/'datasets/source_collection/canada/raw/LICENSE','licenses/canada-MIT.txt')
  z.write(ROOT/'datasets/source_collection/eu/raw/LICENSE','licenses/eu-CC-BY-4.0.txt')
  z.writestr('licenses/ATTRIBUTION.txt','\n\n'.join(s.get('attribution','')+'\n'+s['name']+'\n'+'\n'.join(s['urls']) for s in sources))
 print(json.dumps({'rows':len(rows),'target_languages':len(set(r['target_language'] for r in rows)),'html_bytes':out.stat().st_size,'source_snapshot':payload['snapshot']}))
if __name__=='__main__':build()
