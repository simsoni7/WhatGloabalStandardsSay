"""Derive source observations and review queues without approving translations."""
from collections import defaultdict,Counter
import hashlib,json,unicodedata

def key(text):return ' '.join(unicodedata.normalize('NFC',text or '').split()).casefold()
def preprocess(rows):
 records=[];forward=defaultdict(list);reverse=defaultdict(list);cross=defaultdict(list)
 for raw,concept,usable in rows:
  r=dict(raw);english=r.pop('english');target=r.pop('translation',None)
  r.update(schema_version=2,source_english=english,source_target=target,source_concept_id=concept,
           alignment_status='source_pair_observed' if target else 'missing_in_source',
           equivalence_status='unreviewed' if target else 'not_applicable',approved_translation=None,
           approval=None,integration_issue_ids=[],reference_usable=bool(usable))
  r['publisher']=r.get('publisher') or r['source'].get('publisher')
  r['source_jurisdiction']=r.get('jurisdiction');r['jurisdiction']={'Canada':'CA'}.get(r.get('jurisdiction'),r.get('jurisdiction'))
  r['record_type']=r.get('entry_type') or r.get('kind') or 'source_term'
  if r['record_type']=='term':r['record_type']='source_term'
  r['quality_flags']=list(r.get('quality_flags',[]))
  if target and any(f.get('priority') in ('high','medium') for f in r['quality_flags'] if isinstance(f,dict)):
   r['equivalence_status']='needs_review'
  if r['dataset_id'] in ['mongolbank','canada_government_financial_labels','eu_cpv_financial_services']:
   r['alignment_basis']='shared_source_identifier'
  elif r['dataset_id']=='cfpd':r['alignment_basis']='bilingual_source_table'
  else:r['alignment_basis']=r['source'].get('alignment_method') or r.get('review_status') or 'source_candidate'
  i=len(records);records.append((r,concept,usable))
  if target and usable:
   forward[(r['dataset_id'],r['target_language'],key(english))].append(i)
   reverse[(r['dataset_id'],r['target_language'],key(target))].append(i)
   cross[key(english)].append(i)
 issues=[];links=[]
 def issue(kind,indices,priority='medium',notes=None):
  ids=sorted({records[i][0]['evidence_id'] for i in indices});iid='integration:'+hashlib.sha256((kind+'\0'+'\0'.join(ids)).encode()).hexdigest()[:20]
  item={'issue_id':iid,'issue_type':kind,'priority':priority,'status':'needs_review','evidence_ids':ids,'notes':notes}
  issues.append(item)
  for i in indices:
   r=records[i][0];r['equivalence_status']='needs_review';r['integration_issue_ids'].append(iid)
   r['quality_flags'].append({'issue_id':iid,'issue_type':kind,'priority':priority,'status':'needs_review'})
 for indices in forward.values():
  if len({key(records[i][0]['source_target']) for i in indices})>1:issue('same_source_english_multiple_targets',indices)
 for indices in reverse.values():
  if len({key(records[i][0]['source_english']) for i in indices})>1:issue('same_source_target_multiple_english',indices)
 for en,indices in cross.items():
  if len({records[i][0]['dataset_id'] for i in indices})>1:
   links.append({'relation':'same_english_cross_source_candidate','normalized_english':en,
                 'source_concept_ids':sorted({records[i][1] for i in indices}),
                 'equivalence_status':'not_established','merge_authorized':False})
 # Documented AI triage of the user-reported example; preserve the source pair.
 for i,(r,_,_) in enumerate(records):
  if r['dataset_id']=='mongolbank' and str(r['source'].get('source_id'))=='304':
   issue('source_definition_mismatch_suspected',[i],'high',
         'Source labels Interest Rate as Хүү; definition describes an interest payment. Compare source IDs 733, 737, 3377. AI triage only; no replacement or approved translation.')
   r['semantic_triage']={'status':'suspected_mismatch','human_review':False,'related_source_ids':[733,737,3377]}
 report={'schema_version':2,'entry_count':len(records),'approved_translation_count':0,
         'equivalence_counts':dict(Counter(r['equivalence_status'] for r,_,_ in records)),
         'issue_counts':dict(Counter(i['issue_type'] for i in issues)),
         'cross_source_candidate_links':len(links),
         'rules':['Raw datasets unchanged','Source alignment is not semantic equivalence','No automatic cross-source concept merge','AI triage does not approve a translation']}
 return records,issues,links,report
