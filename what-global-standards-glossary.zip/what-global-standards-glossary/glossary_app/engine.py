from collections import defaultdict
import re
from .index import Index,normalize
from .model import infer,ModelUnavailable,configuration,validate_output


class Engine:
    def __init__(self,index=None,model=infer):self.index=index or Index();self.model=model

    def health(self):return {'status':'ready','reference_index':self.index.stats(),'model':configuration(),
                             'capabilities':{'lookup':True,'source_observation_quotes':True,'approved_translation':False,'source_comparison':True,
                                             'model_adapter':True,
                                             'freeform_model_generation':'configured_unverified' if configuration()['configured'] else 'unavailable'}}

    def process(self,request):
        if not isinstance(request,dict):raise ValueError('Request must be a JSON object')
        operation=request.get('operation','check')
        if operation=='concepts':
            cards=self.index.concept_search(request.get('query'),request.get('domain'),request.get('limit',10))
            return {'status':'concept_candidates_found' if cards else 'no_concept_candidates','concepts':cards,
                    'information_origin':'ai_financial_analysis_candidate','expert_approved':False,'translation_approval':False}
        if operation not in ['lookup','translate','check']:raise ValueError('Invalid operation')
        language=request.get('target_language')
        if not isinstance(language,str) or not re.fullmatch(r'[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*',language):raise ValueError('Valid target_language required')
        query=request.get('english_term') or request.get('expression')
        if not isinstance(query,str) or not query.strip() or len(query)>2000:raise ValueError('english_term or expression is required (max 2000 characters)')
        expression=request.get('expression')
        if expression is not None and (not isinstance(expression,str) or not expression.strip() or len(expression)>10000):raise ValueError('Invalid expression')
        if operation=='check' and expression is None:raise ValueError('check requires expression')
        context=request.get('context','')
        if not isinstance(context,str) or len(context)>10000:raise ValueError('Invalid context')
        source_text=request.get('source_text')
        if source_text is not None and (not isinstance(source_text,str) or not source_text.strip() or len(source_text)>10000):raise ValueError('Invalid source_text')
        country=request.get('jurisdiction')
        if country is not None and (not isinstance(country,str) or not re.fullmatch('[A-Za-z]{2}',country)):raise ValueError('jurisdiction must be a two-letter country code')
        mode=request.get('mode','reference')
        if mode not in ['reference','model']:raise ValueError('mode must be reference or model')
        dataset=request.get('dataset_id');concept=request.get('source_concept_id')
        if dataset is not None and (not isinstance(dataset,str) or len(dataset)>80):raise ValueError('Invalid dataset_id')
        if concept is not None and (not isinstance(concept,str) or len(concept)>200):raise ValueError('Invalid source_concept_id')
        evidence=self.index.lookup(query,language,dataset,concept_id=concept)
        financial_id=request.get('financial_concept_id');financial_card=None
        if financial_id is not None:
            if not isinstance(financial_id,str):raise ValueError('Invalid financial concept ID')
            found=self.index.concept_search(financial_id)
            financial_card=next((c for c in found if c['concept_id']==financial_id),None)
            if financial_card is None:raise ValueError('Unknown financial concept candidate')
        use_case=request.get('use_case')
        if use_case is not None and use_case not in ['consumer_ui','government_procurement','financial_reporting','educational_reference']:
            raise ValueError('Invalid use_case')
        if country:
            scoped=[e for e in evidence if e['jurisdiction']==country.upper()]
            if scoped:evidence=scoped
        group=request.get('source_group_id')
        if group is not None:
            if not isinstance(group,int) or isinstance(group,bool):raise ValueError('source_group_id must be an integer')
            evidence=[e for e in evidence if e['source'].get('group_id')==group]
        present=[e for e in evidence if e.get('source_target') and e['availability']=='present']
        concept_excluded=[]
        if financial_card:
            matched=[e for e in present if e['source_concept_id'] in financial_card['proposed_source_concept_ids']]
            concept_excluded=[e['evidence_id'] for e in present if e not in matched]
            if matched:present=matched
        concept_mismatch=bool(financial_card and present and not any(e['source_concept_id'] in financial_card['proposed_source_concept_ids'] for e in present))
        context_scope_conflict=concept_mismatch or bool(use_case=='consumer_ui' and any(e.get('entry_type')=='procurement_service_classification_label' for e in present))
        scope_conflict=bool(country and present and all(e['jurisdiction']!=country.upper() for e in present))
        direct=[e for e in present if e['match_type'] in ['exact_source_text','source_acronym']]
        options=defaultdict(list)
        for e in present:options[e['source_target']].append(e['evidence_id'])
        ambiguous=len(options)>1
        high_flags=any(f['priority']=='high' and not (concept and f['issue_type']=='same_english_multiple_translations')
                       for e in present for f in e.get('quality_flags',[]))
        result={'schema_version':2,'operation':operation,'english_term':request.get('english_term'),'target_language':language,
                'jurisdiction':country,'context':context,'evidence':evidence,'source_candidates':
                    [{'text':k,'citation_ids':v,'origin':'source_observation','approved':False,
                      'generation_eligible':any(e.get('generation_eligible',True) for e in present if e['evidence_id'] in v)} for k,v in options.items()],
                'translated_text':None,'approved_translation':None,'source_quoted_text':None,'generated_expression':None,'contextual_verdict':'not_assessed',
                'assessment_scope':'source_comparison_only','review_required':True,'questions':[],
                'model_assessment':None,'model_status':'not_requested'}
        result['financial_concept_candidate']=financial_card
        result['concept_excluded_evidence_ids']=concept_excluded
        result['context_scope_conflict']=context_scope_conflict
        result['use_case']=use_case
        if not present:
            result['status']='missing_in_source' if evidence else 'no_target_language_evidence'
            result['reference_evidence']=self.index.lookup(query,dataset=dataset,limit=10)
        elif scope_conflict:result['status']='jurisdiction_needs_review'
        elif context_scope_conflict:result['status']='context_scope_needs_review'
        elif ambiguous:
            result['status']='sense_selection_required'
            result['questions'].append('Which financial meaning, source concept or source group applies?')
        elif high_flags:result['status']='quality_review_required'
        elif not direct:result['status']='candidate_match_needs_review'
        else:result['status']='source_evidence_found'
        if operation=='check':
            matched=[e for e in present if normalize(expression)==normalize(e['source_target'])]
            contains=[e for e in present if normalize(expression) in normalize(e['source_target'])]
            result['source_comparison']='exact_source_match' if matched else ('source_variant_candidate' if contains else ('differs_from_source' if present else 'no_source_to_compare'))
            result['matched_citations']=[e['evidence_id'] for e in matched]
        elif operation=='translate' and result['status']=='source_evidence_found':
            result['source_quoted_text']=next(iter(options))
            result['quote_kind']='unreviewed_source_observation'
        if not context and operation!='lookup':result['questions'].append('What product, audience and display context will this expression be used in?')
        if mode=='model':
            try:
                if context_scope_conflict:
                    result.update(model_status='blocked_context_review',contextual_verdict='needs_review')
                    return result
                model_evidence=[e for e in present if e.get('generation_eligible',True)]
                result['model_excluded_evidence_ids']=[e['evidence_id'] for e in present if not e.get('generation_eligible',True)]
                if present and not model_evidence:
                    result.update(model_status='blocked_source_review',contextual_verdict='needs_review')
                    return result
                model_request=dict(request)
                if financial_card:model_request['financial_concept_candidate']=financial_card
                output=validate_output(self.model(model_request,model_evidence),model_evidence)
                result.update(model_status='responded',model_assessment=output,
                              generated_expression=output['proposed_translation'],assessment_scope='model_assisted_not_human_reviewed')
                if scope_conflict or ambiguous or high_flags or not direct or any(e['equivalence_status']!='approved' for e in present):
                    result['contextual_verdict']='needs_review' if present else 'unverified_proposal'
                else:result['contextual_verdict']=output['assessment']
                if source_text and output['proposed_translation']:
                    from scripts.resolve_quality import numeric_values
                    if numeric_values(source_text)!=numeric_values(output['proposed_translation'],language):
                        result['contextual_verdict']='needs_review'
                        result['model_numeric_conflict']=True
                if not present:result['status']='unverified_model_proposal'
                # A model cannot remove deterministic review requirements.
                result['review_required']=True
            except ModelUnavailable as exc:
                result.update(model_status='unavailable',status='model_unavailable',model_error=str(exc))
        return result
