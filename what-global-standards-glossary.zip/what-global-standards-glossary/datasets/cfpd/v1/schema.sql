PRAGMA foreign_keys = ON;
CREATE TABLE languages (
    code TEXT PRIMARY KEY,
    name TEXT NOT NULL
);
CREATE TABLE sources (
    id INTEGER PRIMARY KEY,
    filename TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    publisher TEXT NOT NULL,
    publication_month TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    page_count INTEGER NOT NULL,
    language_code TEXT NOT NULL REFERENCES languages(code)
);
-- A term identifies an English spelling, not a verified semantic concept.
CREATE TABLE terms (
    id INTEGER PRIMARY KEY,
    english TEXT NOT NULL,
    normalized_key TEXT NOT NULL UNIQUE
);
CREATE TABLE translations (
    id INTEGER PRIMARY KEY,
    term_id INTEGER NOT NULL REFERENCES terms(id),
    language_code TEXT NOT NULL REFERENCES languages(code),
    source_id INTEGER NOT NULL REFERENCES sources(id),
    source_row INTEGER NOT NULL,
    english_raw TEXT NOT NULL,
    translation_raw TEXT NOT NULL,
    translation TEXT,
    availability TEXT NOT NULL DEFAULT 'present'
        CHECK (availability IN ('present', 'missing_in_source')),
    pdf_page_start INTEGER NOT NULL CHECK (pdf_page_start >= 3),
    pdf_page_end INTEGER NOT NULL CHECK (pdf_page_end >= pdf_page_start),
    printed_page_start INTEGER NOT NULL,
    printed_page_end INTEGER NOT NULL,
    review_status TEXT NOT NULL DEFAULT 'unreviewed'
        CHECK (review_status IN ('unreviewed', 'reviewed')),
    UNIQUE(source_id, source_row),
    CHECK ((availability = 'present' AND translation IS NOT NULL AND length(trim(translation)) > 0)
        OR (availability = 'missing_in_source' AND translation IS NULL))
);
CREATE INDEX translations_by_term_language ON translations(term_id, language_code);
CREATE VIEW glossary_pairs AS
SELECT t.id AS term_id, t.english, tr.language_code, tr.translation, tr.availability,
       s.filename AS source_filename, s.publication_month,
       tr.pdf_page_start, tr.pdf_page_end,
       tr.printed_page_start, tr.printed_page_end, tr.review_status
FROM terms t JOIN translations tr ON tr.term_id = t.id
JOIN sources s ON s.id = tr.source_id;
