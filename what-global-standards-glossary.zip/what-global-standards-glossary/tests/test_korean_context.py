import unittest
from glossary_app.korean_labels import attach_label
class KoreanContextTests(unittest.TestCase):
 def test_account_context_does_not_change_source_or_approval(self):
  labels={'current account':{'key':'current account','english':'Current Account','korean':'경상수지','status':'ai_translated_unreviewed'}}
  row={'evidence_id':'bank-account','source_english':'Current Account','source_target':'चल्ती खाता','approved_translation':None,'generation_eligible':False}
  overrides={'bank-account':{'key':'current account','english':'Current Account','korean':'당좌예금계좌','status':'ai_translated_unreviewed','context':'bank product'}}
  attach_label(row,labels,overrides)
  self.assertEqual(row['source_english_korean'],'당좌예금계좌');self.assertEqual(row['source_target'],'चल्ती खाता');self.assertIsNone(row['approved_translation']);self.assertFalse(row['generation_eligible']);self.assertFalse(row['korean_expression']['target_equivalence_approval'])
 def test_wrong_context_english_is_rejected(self):
  with self.assertRaises(ValueError):attach_label({'evidence_id':'x','source_english':'Current Account'}, {}, {'x':{'key':'deposit','english':'Deposit','korean':'예금'}})
