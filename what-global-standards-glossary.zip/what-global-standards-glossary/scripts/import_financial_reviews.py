"""Validate human financial reviews; store separately, never approve translations."""
import argparse,datetime,hashlib,json,pathlib
from build_review_html import ROOT,fingerprint
DECISIONS={'consistent','conditional','mismatch','language_review','pending'}
def validate(document,source):
    if document.get('schema_version')!=1 or document.get('review_scope')!='financial_meaning_only':
        raise ValueError('Unsupported review schema/scope')
    if document.get('snapshot')!=hashlib.sha256(source.read_bytes()).hexdigest():
        raise ValueError('Source snapshot changed; re-review required')
    records={r['evidence_id']:r for r in map(json.loads,source.open())}
    reviews=document.get('reviews')
    if not isinstance(reviews,list): raise ValueError('reviews must be a list')
    seen=set(); result=[]
    for r in reviews:
        eid=r.get('evidence_id')
        if eid not in records or eid in seen:raise ValueError('Unknown or duplicate evidence ID')
        seen.add(eid)
        if r.get('source_fingerprint')!=fingerprint(records[eid]):raise ValueError('Source fingerprint mismatch')
        if r.get('reviewer_role')!='financial_reviewer' or r.get('translation_approval') is not False:raise ValueError('Financial review cannot approve translations')
        if r.get('decision') not in DECISIONS:raise ValueError('Unknown decision')
        for k in ('reviewer','context','note','reviewed_at'):
            if not isinstance(r.get(k),str):raise ValueError('Missing review text fields')
        if not r['reviewer'].strip():raise ValueError('Reviewer identity required')
        datetime.datetime.fromisoformat(r['reviewed_at'].replace('Z','+00:00'))
        if r['decision']=='conditional' and not r['context'].strip():raise ValueError('Conditional decision requires context')
        if r['decision']!='pending' and not r['note'].strip():raise ValueError('Decision requires rationale')
        result.append({k:r[k] for k in ('evidence_id','source_fingerprint','reviewer','reviewer_role','decision','context','note','reviewed_at','translation_approval')})
    return result
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('review_file',type=pathlib.Path);p.add_argument('--validate-only',action='store_true');args=p.parse_args()
    document=json.loads(args.review_file.read_text());rows=validate(document,ROOT/'dist/data/glossary_entries.jsonl')
    if not args.validate_only:
        folder=ROOT/'datasets/human_financial_reviews';folder.mkdir(exist_ok=True)
        digest=hashlib.sha256(args.review_file.read_bytes()).hexdigest()
        out=folder/(digest+'.json');out.write_text(json.dumps({'schema_version':1,'snapshot':document['snapshot'],'review_scope':'financial_meaning_only','reviews':rows},ensure_ascii=False,indent=2))
    print(json.dumps({'validated_reviews':len(rows),'stored':not args.validate_only,'translation_approvals':0}))
