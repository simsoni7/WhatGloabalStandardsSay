# Unicode CLDR currency-name reference

743 source pairs: km166/vi297/ru280. Explicit same currency-code displayName fields from official CLDR JSON48.0.0, commit4d06be52b51bb2f75688d0abe55c52a66afed790.

Unicode-3.0 permits commercial reuse; preserve raw/LICENSE notice. Includes historical currencies and uninflected displayName forms. Not a currently valid currency-code registry, ordinary banking glossary, or expert-approved translation benchmark.

Excluded: XXX3, XTS2, Khmer ESP without displayName1. No source values edited or translated.
