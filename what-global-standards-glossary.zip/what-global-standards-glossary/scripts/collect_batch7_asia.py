#!/usr/bin/env python3
"""Normal verified-HTTPS official Asian source acquisition; no inferred reuse rights."""
import concurrent.futures,datetime,hashlib,json,pathlib,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]/'datasets/source_collection/batch7_asia'
URLS=['https://shabdavali.rbi.org.in/','https://www.rbi.org.in/Scripts/Disclaimer.aspx','https://www.bnm.gov.my/terms-of-use','https://www.bnm.gov.my/terms-of-use-bnm-datasets','https://www.cbsl.gov.lk/en/privacy-policy-statement','https://www.cbsl.gov.lk/en/glossary','https://www.bi.go.id/id/glossarium/Pages/default.aspx','https://www.ojk.go.id/en/Pages/syarat-dan-kondisi.aspx','https://www.sbp.org.pk/our-operations/disclaimer','https://www.sbp.org.pk/glossary']
def fetch(u):
 r={'url':u,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'FinancialGlossarySourceResearch/1.0'}),timeout=35) as f:
   b=f.read();name='followup-'+hashlib.sha256(u.encode()).hexdigest()[:12]+'.html';(ROOT/'raw'/name).write_bytes(b);r.update(status=f.status,final_url=f.url,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),path='raw/'+name)
 except Exception as e:r.update(error=str(e))
 return r
COMMIT='a34682cf22a1da9de5520a27f5f3fc5f7c86b06f'
NAMES=['interest-rates','currency-in-circulation','household-debt','international-reserves','money-supply','reserve-money','electronic-payments','retirement-readiness','income-taxation','public-pension']
def collect_malaysia():
 urls=[f'https://raw.githubusercontent.com/data-gov-my/datagovmy-meta/{COMMIT}/i18n/{lang}/dashboard-{name}.json' for name in NAMES for lang in ['en-GB','ms-MY']]
 rows=list(concurrent.futures.ThreadPoolExecutor(8).map(fetch,urls))
 (ROOT/'malaysia_localization_acquisition.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
 return rows

def extract_malaysia():
 import shutil,collections,re
 acq=json.loads((ROOT/'malaysia_localization_acquisition.json').read_text())
 adopted=ROOT/'adopted_material';adopted.mkdir(exist_ok=True)
 files={};rows=[];excluded=[];seen=set()
 allow={
 'interest-rates':['opr','base','walr','deposit_saving','deposit_fixed_12mo'],
 'currency-in-circulation':[],
 'household-debt':['applied','approved','disbursed','repaid','credit_card','vehicles_passenger','property_residental','personal_total','securities'],
 'international-reserves':['reserves_usd','import_months','ed_scale'],
 'money-supply':['m1_total','m2_total','m1_currency','m1_deposit_demand','m2_deposit_saving','m2_deposit_fixed','m2_nid','m2_repo','m2_deposit_fx','m2_deposit_other','m3_deposit_other'],
 'reserve-money':['total','currency','reserves_required','reserves_excess','net_claims_gov','claims_gov','deposits_gov','claims_private','external','others'],
 'electronic-payments':['credit_f2f','credit_online','debit_f2f','debit_online','charge_f2f','charge_online','emoney','cheque','ibg','dd','rpp','atm_cwd','atm_fin','mobile','internet_indiv','internet_corp'],
 'retirement-readiness':[], 'income-taxation':[],'public-pension':[]}
 for name in NAMES:
  pair={}
  for lang in ['en-GB','ms-MY']:
   a=next(x for x in acq if f'/i18n/{lang}/dashboard-{name}.json' in x['url'])
   if a.get('status')!=200:raise RuntimeError(a)
   dest=adopted/lang/f'dashboard-{name}.json';dest.parent.mkdir(exist_ok=True);shutil.copyfile(ROOT/a['path'],dest)
   rel=dest.relative_to(ROOT).as_posix();files[rel]={'url':a['url'],'sha256':a['sha256']};pair[lang]=(json.loads(dest.read_text())['translation'],a,rel)
  pointers=['header']+['keys.'+k for k in allow[name]]
  if name=='retirement-readiness':pointers+=['median_balance','timeseries_header','withdrawals','contributions']
  for pointer in pointers:
   vals={}
   for lang,(j,a,rel) in pair.items():
    v=j
    for key in pointer.split('.'):v=v[key]
    vals[lang]=v
   en,ms=vals['en-GB'],vals['ms-MY'];key=(en.strip().casefold(),ms.strip().casefold())
   if key in seen:excluded.append({'dashboard':name,'key':pointer,'reason':'duplicate_exact_pair','english':en,'translation':ms});continue
   if not en.strip() or not ms.strip() or '{{' in en or '{{' in ms:
    excluded.append({'dashboard':name,'key':pointer,'reason':'empty_or_placeholder_value','english':en,'translation':ms});continue
   seen.add(key);j,a,rel=pair['ms-MY'];ej,ea,erel=pair['en-GB'];cid=name+':'+pointer
   rows.append({'evidence_id':'malaysia_financial_dashboard:ms:'+cid,'dataset_id':'malaysia_financial_dashboard','dataset_version':COMMIT,'source_concept_id':'malaysia_financial_dashboard:'+cid,'english':en.strip(),'translation':ms.strip(),'source_english':en,'source_target':ms,'target_language':'ms','source_language':'en','kind':'financial_statistical_indicator_label','category':name,'jurisdiction':'MY','license':'MIT','commercial_use':True,'approved_translation':None,'generation_eligible':False,'human_review':False,'context_required':True,'quality_flags':['official_government_dashboard_label','not_normative_glossary','context_required','upstream_translation_not_expert_approved'],'source':{'url':a['url'],'raw_url':a['url'],'file':str((ROOT/rel).relative_to(ROOT.parents[2])),'sha256':a['sha256'],'english_url':ea['url'],'english_file':str((ROOT/erel).relative_to(ROOT.parents[2])),'english_sha256':ea['sha256'],'source_key':'translation.'+pointer,'raw_english_value':en,'raw_target_value':ms,'normalization':'outer_whitespace_trim_only','alignment':'same_dashboard_same_json_pointer','publisher':'Government of Malaysia / data-gov-my','repository':'https://github.com/data-gov-my/datagovmy-meta','commit':COMMIT}})
 license_src=ROOT/'raw/followup-cedf0aa17a6c.html'
 if not license_src.exists():
  got=fetch(f'https://raw.githubusercontent.com/data-gov-my/datagovmy-meta/{COMMIT}/LICENSE')
  if got.get('status')!=200:raise RuntimeError(got)
  license_src=ROOT/got['path']
 if hashlib.sha256(license_src.read_bytes()).hexdigest()!='4038990612ddc2eccfb2ac7221bed225f4e01d37098c97c25ed79c5bf00a8a24':raise ValueError('Unexpected license bytes')
 shutil.copyfile(license_src,adopted/'LICENSE')
 files['adopted_material/LICENSE']={'url':f'https://raw.githubusercontent.com/data-gov-my/datagovmy-meta/{COMMIT}/LICENSE','sha256':hashlib.sha256(license_src.read_bytes()).hexdigest()}
 notice='Derived financial statistical dashboard labels from Government of Malaysia data-gov-my/datagovmy-meta, commit '+COMMIT+'. MIT License copyright (c) 2023 data-gov-my retained. Original JSON values retained; selected by identical JSON pointers, exact duplicate English/Malay pairs removed. Not a bank-authorised general translation glossary; no human semantic approval. BNM website terms are NOT used as a license for this software localization pack.\n'
 (adopted/'NOTICE.txt').write_text(notice)
 (ROOT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
 (ROOT/'excluded.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2))
 manifest={'dataset_id':'malaysia_financial_dashboard','publisher':'Government of Malaysia / data-gov-my','source_repository':'https://github.com/data-gov-my/datagovmy-meta','commit':COMMIT,'license':'MIT','commercial_use':True,'license_file':'adopted_material/LICENSE','notice_file':'adopted_material/NOTICE.txt','adopted_raw_directory':'adopted_material','files':files,'entry_count':len(rows),'counts_by_language':{'ms':len(rows)},'collection_scope':'10 official financial dashboards, selected financial header/indicator labels, identical translation JSON pointers. Generic controls/descriptive paragraphs/demographics/numeric denominations omitted. Source M3 formula-like label omitted; cannot be treated as a financial definition. Exact duplicate English/Malay pairs removed.','evidence_sha256':hashlib.sha256((ROOT/'evidence.jsonl').read_bytes()).hexdigest(),'generation_eligible':False,'human_review':False,'research_raw_not_for_redistribution':'raw/ includes unrelated official bank snapshots with unconfirmed rights; do not copy wholesale into a public pack.'}
 (ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(json.dumps({'entry_count':len(rows),'duplicates_removed':len(excluded)},ensure_ascii=False))

if __name__=='__main__':
 ROOT.mkdir(parents=True,exist_ok=True);(ROOT/'raw').mkdir(exist_ok=True)
 collect_malaysia();extract_malaysia()
