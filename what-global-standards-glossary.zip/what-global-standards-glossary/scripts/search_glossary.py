"""Search English or translated text in the local glossary database."""
import argparse
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('query', help='Substring of an English or translated term')
    parser.add_argument('--language', choices=['es', 'zh-Hant', 'ko', 'vi', 'ru'])
    parser.add_argument('--limit', type=int, default=20)
    args = parser.parse_args()
    if not args.query.strip() or not 1 <= args.limit <= 500:
        parser.error('Provide a nonempty query and a limit from 1 to 500.')
    conn = sqlite3.connect((ROOT / 'datasets' / 'cfpd' / 'v1' / 'glossary.sqlite').as_uri() + '?mode=ro', uri=True)
    conn.row_factory = sqlite3.Row
    # Bind data, and escape LIKE wildcards so user text is searched literally.
    pattern = '%' + args.query.replace('!', '!!').replace('%', '!%').replace('_', '!_') + '%'
    sql = """SELECT * FROM glossary_pairs
             WHERE (english LIKE ? ESCAPE '!' OR translation LIKE ? ESCAPE '!')"""
    params = [pattern, pattern]
    if args.language:
        sql += ' AND language_code = ?'
        params.append(args.language)
    sql += ' ORDER BY english, language_code LIMIT ?'
    params.append(args.limit)
    try:
        print(json.dumps([dict(r) for r in conn.execute(sql, params)], ensure_ascii=False, indent=2))
    finally:
        conn.close()
