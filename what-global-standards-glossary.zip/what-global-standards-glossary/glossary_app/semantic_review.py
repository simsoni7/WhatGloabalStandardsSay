"""Source-definition triage; never expert approval or automatic concept merging."""
from collections import Counter
from pathlib import Path
import hashlib,json,re
from .preprocess import key
from .enrichment import accepted_records

def signature(record):
 return hashlib.sha256(json.dumps({k:record.get(k) for k in ['source_english','source_target','definition','source_concept_id']},ensure_ascii=False,sort_keys=True).encode()).hexdigest()

def apply_review(rows,issues,links,report,root):
 records={r['evidence_id']:r for r,_,_ in rows};path=root/'datasets/derived/semantic_review/decisions.json'
 decisions=json.loads(path.read_text())['decisions'] if path.exists() else []
 decisions += accepted_records(root,'semantic_decisions')
 if len({d['decision_id'] for d in decisions})!=len(decisions):raise ValueError('Duplicate semantic decision IDs')
 for r in records.values():r.update(generation_eligible=bool(r['reference_usable']),generation_safety_assessed=False,semantic_review={'status':'not_reviewed','human_review':False})
 by_evidence={}
 for decision in decisions:
  for eid in decision['evidence_ids']:
   if eid not in records or signature(records[eid])!=decision['source_signatures'][eid]:raise ValueError('Semantic review evidence changed; re-review required')
   if decision.get('semantic_approval') or decision.get('human_review'):raise ValueError('AI triage cannot declare expert approval')
   r=records[eid];r['semantic_review']={'status':'ai_triaged','decision_id':decision['decision_id'],'classification':decision['classification'],'rationale':decision['rationale'],'human_review':False}
   for field in ['generation_safety_assessed','source_definition_scope_suspicion','usage_constraint']:
    if field in decision:r['semantic_review'][field]=decision[field]
   r['equivalence_status']='needs_review';by_evidence[eid]=decision
   if decision.get('quarantine_for_generation'):
    r['generation_eligible']=False
    r['quality_flags'].append({'issue_type':'semantic_generation_quarantine','priority':'high','status':'needs_review','decision_id':decision['decision_id']})
  if decision.get('proposed_relationship'):
   links.append({'relation':decision['proposed_relationship'],'source_concept_ids':sorted({records[eid]['source_concept_id'] for eid in decision['evidence_ids']}),'decision_id':decision['decision_id'],'equivalence_status':'ai_candidate_not_approved','merge_authorized':False})
 def source_acronym(a,b):
  return a==''.join(re.findall(r'\b[A-Z]',b)) or a in re.findall(r'\(([A-Z][A-Z0-9-]{1,11})\)',b)
 for item in issues:
  rs=[records[eid] for eid in item['evidence_ids']];manual=[by_evidence[eid] for eid in item['evidence_ids'] if eid in by_evidence]
  definitions=[key((r.get('definition') or {}).get('text')) for r in rs]
  if manual:classification='ai_definition_review_attached'
  elif item['issue_type']=='same_source_english_multiple_targets':
   if all(definitions) and len(set(definitions))==1:classification='identical_definition_variant_candidate'
   elif len({r['source'].get('group_id') for r in rs})>1:classification='cross_domain_meaning_review_required'
   else:classification='target_variant_semantics_unresolved'
  elif item['issue_type']=='same_source_target_multiple_english':
   english=[r['source_english'] for r in rs]
   if any(source_acronym(a,b) for a in english for b in english if a!=b):classification='source_acronym_alias_candidate'
   else:classification='shared_target_sense_review_required'
  else:classification='source_mismatch_review_required'
  item['triage_classification']=classification;item['semantic_review_complete']=False;item['human_review']=False
  item['decision_ids']=sorted({d['decision_id'] for d in manual})
  item['review_packet']=[{'evidence_id':r['evidence_id'],'source_concept_id':r['source_concept_id'],'source_english':r['source_english'],'source_target':r['source_target'],'definition':r.get('definition'),'source_group_id':r['source'].get('group_id'),'source_context':r['source'].get('context'),'jurisdiction':r['jurisdiction'],'commercial_use':r.get('usage_terms',{}).get('commercial_use'),'generation_eligible':r['generation_eligible']} for r in rs]
 report['semantic_review']={'ai_decisions':len(decisions),'ai_triaged_records':len(by_evidence),'generation_quarantined_records':sum(not r['generation_eligible'] and r['reference_usable'] for r in records.values()),'triage_group_counts':dict(Counter(i['triage_classification'] for i in issues)),'human_approved_translations':0,'complete_semantic_validation':False}
 report['equivalence_counts']=dict(Counter(r['equivalence_status'] for r in records.values()))
 return rows,issues,links,report
