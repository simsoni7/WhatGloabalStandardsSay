#!/usr/bin/env python3
"""Reproducibly extract conservative financial noun labels from pinned Apache OFBiz."""
import collections
import hashlib
import json
from pathlib import Path
import re
import urllib.request
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'datasets/source_collection/permissive_finance_batch5'
COMMIT = 'b8b72d556e829d4a0818f8a4fed57e0750efcacb'
REPO = 'https://github.com/apache/ofbiz-framework'
XML_PATH = 'applications/accounting/config/AccountingUiLabels.xml'
LANG = '{http://www.w3.org/XML/1998/namespace}lang'
# Explicit, inspectable noun-label selection. No broad keyword sweep of dialog text.
LABELS = '''Account|Accounting|Account Limit|Account Number|Accounts Payable|Accounts Receivable|Account Type|Accounting Transactions|Account Reconciliation|Account Reconciliations|Actual Currency Amount|Payments|Applied Payments|Assets|Balance Due|Balance Of The Account|Balance Sheet|Bank|Bank Account|Bank Name|Bank Reconciliation|Billing Account|Available Balance|Billing Accounts|Net Balance|Budget Type|Cash Flow Statement|Chart of Accounts|Closing Cash Balance|Company Name on Account|Comparative Balance Sheet|Comparative Cash Flow Statement|Comparative Income Statement|Credit Amount|Credit Card|Credit Card Information|Currency|Current Asset|Current Assets|Current Liabilities|Debit Amount|Debit Or Credit Of The Balance|Deposit|Deposit Slip|Deposit Slips|Deposit/Withdraw|EFT Account|EFT Account Information|Ending Balance|Ending Cash Balance|Exchange Rate|Expenses|Foreign Exchange Rates|Financial Account|Financial Account Transaction|Transactions|Financial Accounts|Fixed Asset|Fixed Asset Name|Asset Group|Standard Cost Type|Standard Costs|Asset Type|Fixed Assets|General Ledger|Gift Card Balance|GL Account|GL Account Class|GL Account Trial Balance|GL Accounts|Income|Income From Operations|Income Statement|Invoice|Invoice Date|Invoice Item|Invoice Item Type|Purchase Invoice|Sales Invoice|Invoice Total|Invoices|Payments applied to Invoices|Invoices Due Soon|Liabilities|Long Term Assets|Monthly Trial Balance|Name on Account|Net Income|Offline Payment|Opening Balance|Opening Cash Balance|Operating Expenses|Operational Cash|Original Currency|Accounts Summary|Past Due Invoices|Payment|Payment Amount|Payment Date|Payment Information|Payment Method|Payment Method Information|Payment Status|Payment Type|Payments Applied|Payments Received|Payments Sent|Period Cash Balance|Purchase Invoices|Sales Invoices|Service Credit|Single Use Credit Card|Single Use EFT Account|Accounting Status|Subsidiary Ledger|Tax Authorities|Tax Authority|Tax Summary Report|Total Assets|Total Cash Balance|Total Closing Cash Balance|Total Credit (Disbursement)|Total Current Asset Balance|Total Debit (Receipts)|Total Ending Cash Balance|Total excl. tax|Total Liabilities and Equities|Total Liabilities|Total Opening Cash Balance|Total Operational Cash Balance|Total Period Cash Balance|Transaction Totals|Transaction Type|Trial Balance|Accumulated depreciation GL account|Account Code|Account Name|Actual Balance|Asset GL account|Base Currency|Closing Balance|Closing Balance Credit|Closing Balance Debit|Cost Of Goods Sold (COGS) Method|Cost Centers|Credit|Debit|Depreciation GL account|Fixed Asset Name|GL Account Category|GL Account Category Type|Invoice Amount|Invoice Sequence|Invoice Type|Last Invoice Number|Loss GL account|Month Amount Credit|Month Amount Debit|Opening Balance Credit|Opening Balance Debit|Posted Balance|Profit GL account|Purchase Cost|Reconciled Balance|Tax Percentage|Transaction Date|Year To Date Balance Credit|Year To Date Balance Debit|Batch Payments|Budget Overview|Financial Account Summary|Fixed Asset Depreciation Method|Fixed Asset Depreciation Report|Tax Report|Un-posted Accounting Transactions'''
ALLOW = set(LABELS.split('|'))
# Use observed primary locales; do not infer variants or fallback translations.
LOCALES = {'ar':'ar','cs':'cs','de':'de','es':'es','fr':'fr','hi-IN':'hi','it':'it',
           'ja':'ja','nl':'nl','pt':'pt','ro':'ro','ru':'ru','th':'th','vi':'vi',
           'zh':'zh-Hans','zh-TW':'zh-Hant'}
SCOPE_CAUTION = {
    ('ru','Account'): 'Russian source label may refer to a login record rather than a financial account.',
    ('ru','Account Number'): 'Russian source label may refer to a login record rather than a financial account.',
    ('vi','Debit'): 'Source label appears to refer to a spending limit; accounting debit equivalence needs specialist review.',
    ('vi','Credit'): 'Credit may mean lending rather than the credit side of an accounting entry.',
    ('vi','Income Statement'): 'Source label appears to refer to income; full financial-statement equivalence needs specialist review.',
    ('vi','Deposit'): 'Deposit may mean security deposit/collateral; do not infer bank-deposit equivalence.',
    ('ru','Income Statement'): 'Accounting statement label requires Russian financial terminology review.',
}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2)+'\n')

def main():
    raw = OUT / 'raw'; raw.mkdir(parents=True, exist_ok=True)
    files = {'AccountingUiLabels.xml':XML_PATH,'LICENSE':'LICENSE','NOTICE':'NOTICE'}
    for name, upstream in files.items():
        p = raw/name
        if not p.exists():
            p.write_bytes(urllib.request.urlopen(f'https://raw.githubusercontent.com/apache/ofbiz-framework/{COMMIT}/{upstream}', timeout=60).read())
    assert b'Apache License' in (raw/'LICENSE').read_bytes()
    tree = ET.parse(raw/'AccountingUiLabels.xml')
    rows=[]; excluded=[]; counts=collections.Counter(); seen=set(); keys=[]
    source_hash=sha(raw/'AccountingUiLabels.xml')
    for prop in tree.getroot():
        key=prop.attrib['key']; values={v.attrib.get(LANG):(v.text or '') for v in prop}
        english=values.get('en','').strip()
        if english not in ALLOW:
            continue
        keys.append(key)
        for locale, language in LOCALES.items():
            target=values.get(locale,'').strip()
            reason=None
            if not target: reason='missing_or_empty_actual_locale'
            elif target.casefold()==english.casefold(): reason='identical_to_english_unverified_translation'
            elif re.search(r'\$\{|\{\d+\}|%[sd]|[<>]',target):reason='placeholder_or_markup'
            elif not any(c.isalpha() for c in target): reason='nonlexical'
            fingerprint=(language,english.casefold(),target.casefold())
            if fingerprint in seen:reason='exact_pair_duplicate_other_source_key'
            if reason:
                excluded.append({'source_key':key,'english':english,'source_locale':locale,'target':target,'reason':reason});continue
            seen.add(fingerprint);counts[language]+=1
            row={'evidence_id':f'apache_ofbiz_accounting:{language}:{key}',
                'dataset_id':'apache_ofbiz_accounting','dataset_name':'Apache OFBiz accounting software financial labels',
                'dataset_version':COMMIT,'dataset_state':'candidate','source_concept_id':f'apache_ofbiz_accounting:{key}',
                'source_language':'en','english':english,'target_language':language,'translation':target,
                'availability':'present','kind':'financial_software_label','category':'accounting_software',
                'publisher':'Apache Software Foundation','jurisdiction':'international_software_context',
                'review_status':'explicit_upstream_resource_key_alignment','human_review':False,'context_required':True,
                'license':'Apache-2.0','commercial_use':True,
                'source':{'type':'official_open_source_localization','url':f'{REPO}/blob/{COMMIT}/{XML_PATH}',
                    'raw_url':f'https://raw.githubusercontent.com/apache/ofbiz-framework/{COMMIT}/{XML_PATH}',
                    'file':str((raw/'AccountingUiLabels.xml').relative_to(ROOT)),'sha256':source_hash,
                    'commit':COMMIT,'source_key':key,'source_locale':locale,'english_locale':'en',
                    'raw_english_value':values['en'],'raw_target_value':values[locale],
                    'normalization':'outer_whitespace_trim_only',
                    'alignment_method':'explicit_same_property_key_two_actual_locale_values',
                    'software_context':'Apache OFBiz ERP accounting module; financial/accounting noun labels',
                    'license_url':f'{REPO}/blob/{COMMIT}/LICENSE','notice_url':f'{REPO}/blob/{COMMIT}/NOTICE',
                    'license_sha256':sha(raw/'LICENSE'),'notice_sha256':sha(raw/'NOTICE')},
                'quality_flags':['software_label_not_financial_institution_glossary','context_required',
                    'upstream_translation_not_expert_approved'],
                'approved_translation':None}
            if (language,english) in SCOPE_CAUTION:
                row['quality_flags'].append('possible_lexical_scope_mismatch')
                row['semantic_scope_caution']=SCOPE_CAUTION[language,english]
                row['generation_eligible']=False
            rows.append(row)
    (OUT/'evidence.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
    dump(OUT/'excluded.json',excluded)
    dump(OUT/'manifest.json',{'source_repository':REPO,'commit':COMMIT,'license':'Apache-2.0',
        'commercial_use':True,'license_obligations':['Preserve LICENSE and NOTICE','State extraction/selection modifications; do not imply Apache endorsement'],
        'file_sha256':{name:sha(raw/name) for name in files},'counts':dict(sorted(counts.items())),
        'total_pairs':len(rows),'selected_source_keys':keys,'locale_mapping':LOCALES,
        'km_available':False,'no_locale_fallback':True,'deduplication':'same language + normalized English + normalized target',
        'trust_scope':'Official Apache upstream resource-key observations only; not official bank terminology or financial/language expert approval',
        'translation_quality_limitations':['Some upstream translations may confuse financial accounts and login accounts','Context remains accounting ERP software','No definitions or linguistic accuracy certification']})
    print(json.dumps({'pairs':len(rows),'counts':dict(counts)},ensure_ascii=False))

if __name__=='__main__':main()
