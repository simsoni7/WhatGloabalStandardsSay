# 금융 문맥 기능 진단 세트

`datasets/enrichment/context_cases/cases.jsonl`은 기존 출처 증거를 이용해 작성한 26개 실제 제품 상황 진단입니다. 모든 요청은 현재 `Engine.process`로 실행했으며 외부 모델은 호출하지 않고 명시적인 unavailable fixture를 사용했습니다. manifest에 입력 DB와 출력 파일 SHA256을 기록합니다.

## 무엇을 검증하는가

원문 인용을 승인 번역으로 승격하지 않는지, 원본 누락을 누락으로 반환하는지, 관할 충돌을 경고하는지, 격리된 증거만 있는 모델 요청을 차단하는지를 확인합니다. 이자 금액/금리, APR/명목금리, 수수료/이자, 결제/보험 고객, 실물/재무 자본, 공공조달 분류/소비자 화면 문구도 별도의 상황으로 기록합니다.

`expected_structural_behavior`는 현재 구현에 대한 구조적 안전 요구입니다. `observed_current_behavior`는 실행 결과입니다. `required_context_capability`는 필요한 문맥 기능의 개발 과제를 표시하며 현재 구현이 없는 경고를 통과했다고 표현하지 않습니다. 문맥을 request.context에 넣는 것만으로 자동 의미검증이 수행되지는 않습니다.

## 정답셋과의 구분

annotation_origin은 ai_authored_diagnostic이고 human_review는 false입니다. translation_gold는 모두 null입니다. 실제 source_evidence_ids는 검색된 원문 증거를 추적하기 위한 값이며 올바른 번역 정답을 뜻하지 않습니다. 구조 assertion 성공은 금융 의미 정확도나 모델 성능 수치가 아닙니다. 검수와 독립 전문가 정답 확보 전에는 학습/성능 보고용 골드 벤치마크로 사용하지 않습니다.

## 평가 누수와 재현성

현재 cases는 제작 과정에서 원문과 엔진 출력을 보았으므로 blind holdout이 아닙니다. 향후 전문가가 독립 작성한 숨겨진 문맥·답변을 별도 보관하고, 이 개발용 진단과 분리해야 합니다. 같은 source_concept_id 및 대응 언어를 여러 평가 분할로 나누면 근거 유출이 생기므로 개념/출처/문맥 단위 분할이 필요합니다. DB가 바뀌면 manifest 입력 해시를 갱신하고 각 source_evidence_ids와 안전 요구를 재실행해 확인해야 합니다.
