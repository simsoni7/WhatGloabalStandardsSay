"""Source-grounded terminology lookup, translation and checking."""
