"""Export copyleft localization components as separately licensed source files."""
import collections,hashlib,json,pathlib,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from glossary_app.preprocess import preprocess
from glossary_app.korean_labels import load_labels,attach_label

def export():
 labels=load_labels(ROOT);out=ROOT/'dist/community';out.mkdir(parents=True,exist_ok=True);reviews=[json.loads((ROOT/f'datasets/source_collection/{batch}/decisions.json').read_text()) for batch in ('batch5_review','batch6_review')];review={'accepted_inputs':[item for report in reviews for item in report['accepted_inputs']]};registry=json.loads((ROOT/'datasets/community_language_packs/registry.json').read_text());catalog={'format_version':2,'entry_count':0,'counts_by_language':{},'components':[],'generation_policy':'All community copyleft observations blocked for default model generation; not expert-approved equivalents.'};totals=collections.Counter()
 for entry in registry['packs']:
  pack=ROOT/entry['path'];m=json.loads((pack/'manifest.json').read_text())
  for name,digest in m['files_sha256'].items():
   file=(pack/name).resolve();assert file.is_relative_to(pack) and hashlib.sha256(file.read_bytes()).hexdigest()==digest
  originals=[json.loads(l) for l in (pack/'evidence.jsonl').read_text().splitlines()];accepted=set()
  for decision in review['accepted_inputs']:
   if decision['dataset_id']==entry['dataset_id']:
    assert hashlib.sha256((ROOT/decision['path']).read_bytes()).hexdigest()==decision['sha256'], 'Reviewed source changed'
    accepted.update(decision['accepted_ids'])
  assert all(r['evidence_id'] in accepted for r in originals), 'Unreviewed or excluded evidence in source pack'
  rows,_,_,_=preprocess([(r,r['source_concept_id'],True) for r in originals]);guards={eid:s for s in review['accepted_inputs'] if s['dataset_id']==entry['dataset_id'] for eid in s.get('generation_block_ids',[])};result=[]
  for r,_,_ in rows:
   r.update(generation_eligible=False,generation_safety_assessed=False,approved_translation=None,equivalence_status='needs_review',reference_layer='conditional_copyleft');r['source_notes']=['금융 소프트웨어의 커뮤니티 번역 원문입니다. 금융기관 공인 용어나 전문가 승인 번역이 아니며, 자동 생성 참고에서는 기본 제외합니다.'];r['semantic_review']={'status':'context_restricted','classification':'community_translation_unreviewed','human_review':False}
   if r['evidence_id'] in guards and any(r['evidence_id'] in c.get('evidence_ids',[c.get('evidence_id')]) for c in guards[r['evidence_id']].get('semantic_cautions',[])):
    caution=guards[r['evidence_id']];notes=[c['reason'] for c in caution.get('semantic_cautions',[]) if r['evidence_id'] in c.get('evidence_ids',[c.get('evidence_id')])];r['source_notes'].append('독립 AI 점검에서 금융 의미의 혼동이 의심되었습니다. '+ ' '.join(notes));r['quality_flags'].append({'issue_type':'semantic_generation_quarantine','priority':'high','status':'needs_review'});r['semantic_review']['classification']='source_financial_sense_mismatch_suspected'
   attach_label(r,labels);result.append(r)
  data={'license_notice':(pack/m['usage_terms']['license_file']).read_text(),'corresponding_source_url':'https://raw.githubusercontent.com/simsoni7/WhatGloabalStandardsSay/dictionary-20261015-r8/conditional-community-language-packs.zip','schema_version':2,'dataset_id':entry['dataset_id'],'usage_terms':m['usage_terms'],'rows':result,'source_manifest':m};file=out/(entry['dataset_id']+'.json');file.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')));counts=dict(collections.Counter(r['target_language'] for r in result));totals.update(counts)
  component={'dataset_id':entry['dataset_id'],'entry_count':len(result),'counts_by_language':counts,'file':file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'usage_terms':m['usage_terms'],'source_pack':entry['path'],'named_semantic_cautions':sum(r['semantic_review']['classification']=='source_financial_sense_mismatch_suspected' for r in result)};catalog['components'].append(component);catalog['entry_count']+=len(result)
 catalog['counts_by_language']=dict(totals);(out/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(ROOT/'dist/conditional-community-language-packs.zip','w',zipfile.ZIP_DEFLATED) as z:
  z.write(out/'catalog.json','community-components/catalog.json')
  for c in catalog['components']:
   z.write(out/c['file'],'community-components/'+c['file']);pack=ROOT/c['source_pack']
   for f in pack.rglob('*'):
    if f.is_file():z.write(f,'community-components/'+c['dataset_id']+'/'+str(f.relative_to(pack)))
  z.write(ROOT/'docs/community-reference-policy.md','community-components/README.md')
 print(json.dumps({'components':len(catalog['components']),'conditional_rows':catalog['entry_count'],'counts':catalog['counts_by_language']}))
if __name__=='__main__':export()
