# FinQA numerical reasoning benchmark

1,147 official public test records, English only. This is a financial numerical-reasoning task, not a translation benchmark or language reference pack. It adds no glossary languages or term pairs. No model evaluation was run.

The original repository README states the project contains both the FinQA dataset and code. Its MIT license and original copyright notice are included. Underlying annual-report content retains its source attribution; the repository license is not a blanket guarantee about every third-party document.

`benchmark.jsonl` separates input from reference answers. Evaluation prompts must use only `input`: program and execution answers are gold labels. Retrieved annotations/model-input fields from the source are deliberately excluded from this normalized benchmark. Do not train on public test answers and claim an independent test score. Public benchmark contamination in pretrained models is unknown.

Fourteen source records have empty answer text; their execution answer and program are preserved. Use execution/program evaluation, not fabricated textual answers. Source spelling and possible question defects remain unchanged. Original test split and all 1,147 IDs are retained.
