# Apache OFBiz 금융·회계 소프트웨어 레이블 조사

## 수집 결과와 근거

Apache Software Foundation의 공식 `apache/ofbiz-framework` 저장소에서
`b8b72d556e829d4a0818f8a4fed57e0750efcacb` 커밋에 고정한
`applications/accounting/config/AccountingUiLabels.xml`을 수집했다.
공식 ERP 회계 모듈의 동일한 property key 아래 실제 `en`과 대상 locale의
value가 함께 존재하는 경우만 관측했다. 번역을 생성하거나 다른 locale로 대체하지 않았다.

명시적으로 선택한 금융·회계 명사 및 명사구에 해당하는 원본 key는 187개,
수록된 서로 다른 영어 레이블은 172개이며, 실제 번역 관측은 2,223쌍이다.
일반 로그인·검색·선택·추가·삭제 버튼, 오류 메시지, 대화문은 선정하지 않았다.

| 언어 | 쌍 수 |
|---|---:|
| 아랍어 | 170 |
| 체코어 | 35 |
| 독일어 | 173 |
| 스페인어 | 173 |
| 프랑스어 | 175 |
| 힌디어 | 160 |
| 이탈리아어 | 104 |
| 일본어 | 170 |
| 네덜란드어 | 130 |
| 포르투갈어 | 161 |
| 루마니아어 | 76 |
| 러시아어 | 82 |
| 태국어 | 92 |
| 베트남어 | 175 |
| 중국어 간체 | 174 |
| 중국어 번체 | 173 |

크메르어 locale는 이 파일에 존재하지 않는다. `hi-IN`은 관측 locale를
source 필드에 보존하면서 대상 언어 코드를 `hi`로 정규화했다.
`zh`, `zh-TW`는 각각 간체·번체로 표기했으며 실제 upstream locale는 그대로 보존했다.

## 믿을 수 있는 범위와 한계

공식 Apache 원본이므로 누가 배포한 어떤 버전의 소프트웨어 레이블인지
commit·원본 파일·SHA-256·resource key로 재현할 수 있다.
이 신뢰는 **원문 관측과 대응 key의 정확성**에 관한 것이며,
중앙은행이 확정한 금융용어 또는 금융·언어 전문가의 정답이라는 의미가 아니다.
ERP 회계 레이블에는 회계계정, 은행계좌, 사용자 계정이 섞일 수 있다.

예를 들어 베트남어 `Debit` 원문이 `Hạn mức tiêu (Debit)`이고,
`Credit`은 `Tín dụng`, `Deposit`은 `Ký quỹ`이다.
차변·대변·은행예금의 보편적인 확정 번역으로 쓰면 부정확할 수 있다.
이 사례들과 일부 account/손익계산서 레이블 총 7쌍에는 의미 범위 의심 근거를
별도 기록하고 `generation_eligible:false`를 지정했다.
다른 행도 전문가 승인 없이 소프트웨어 문맥의 참고 관측만 제공한다.

## 이용조건과 변경 내역

공식 저장소의 Apache License 2.0 및 NOTICE 원본을 동봉했다.
상업 이용이 허용되는 라이선스이며 재배포 시 LICENSE·NOTICE 보존과
변경 내역 표시 등 해당 조건을 준수해야 한다. Apache의 보증·승인을 주장하지 않는다.
원본 XML을 변경하지 않고 명시 명사구 목록으로 선택·언어 코드 정규화·중복 제거한
추출물을 제공한다. 비상업 데이터의 번역을 복사하거나 다시 포장하지 않았다.

빈 locale 636건, 영어와 동일해 번역 여부를 확인할 수 없는 9건,
같은 언어·영어·대상 표현의 다른 resource key 중복 124건을 제외 내역에 기록했다.

## 재현 파일

- `scripts/collect_permissive_finance_batch5.py`
- `datasets/source_collection/permissive_finance_batch5/raw/AccountingUiLabels.xml`
- `datasets/source_collection/permissive_finance_batch5/raw/LICENSE`
- `datasets/source_collection/permissive_finance_batch5/raw/NOTICE`
- `datasets/source_collection/permissive_finance_batch5/evidence.jsonl`
- `datasets/source_collection/permissive_finance_batch5/excluded.json`
- `datasets/source_collection/permissive_finance_batch5/manifest.json`

실행: `python3 scripts/collect_permissive_finance_batch5.py`.
Registry·공통 인덱스·공개 배포는 독립 검수 후 총괄이 반영한다.
