"""Refresh generated delivery without modifying frozen source datasets."""
from pathlib import Path
import zipfile,json,hashlib,tempfile,subprocess
ROOT=Path(__file__).resolve().parents[1]
def refresh():
 p=ROOT/'dist/what-global-standards-glossary.zip';tmp=p.with_suffix('.refresh.zip')
 updates=['glossary_app/index.py','datasets/derived/reference_index.sqlite','datasets/derived/reference_index_manifest.json','evaluation/results.json','scripts/build_nepal_documents.py','scripts/export_delivery_data.py','scripts/refresh_delivery_package.py','scripts/probe_nepal_official.py','docs/nepal-expansion.md','datasets/nepal_official/candidate/probe.json']
 folder=ROOT/'datasets/nepalbank/candidate/document-expansion'
 updates += [str(f.relative_to(ROOT)) for f in folder.iterdir() if f.suffix in ['.pdf','.txt','.json','.tsv']]
 prefix='what-global-standards-glossary/'
 with zipfile.ZipFile(p) as a,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as b:
  for i in a.infolist():
   if i.filename[len(prefix):] not in updates and i.filename!=prefix+'NEPAL-UPDATE.md':b.writestr(i,a.read(i.filename))
  for name in updates:b.write(ROOT/name,prefix+name)
  b.writestr(prefix+'NEPAL-UPDATE.md',(ROOT/'docs/nepal-expansion.md').read_text())
 with tempfile.TemporaryDirectory() as t:
  with zipfile.ZipFile(tmp) as z:assert z.testzip() is None;z.extractall(t);count=len(z.namelist())
  r=subprocess.run(['python3','-m','evaluation.run'],cwd=Path(t)/prefix,capture_output=True,text=True);assert r.returncode==0,r.stderr;print(r.stdout)
 tmp.replace(p);catalog=json.loads((ROOT/'dist/data/catalog.json').read_text());m=json.loads((ROOT/'dist/delivery.json').read_text());m.update(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size,file_count=count,nepal_entries=catalog['counts_by_language']['ne'],data_entries=catalog['entry_count']);(ROOT/'dist/delivery.json').write_text(json.dumps(m,indent=2)+'\n')
 files=['glossaries-data.zip','what-global-standards-glossary.zip','delivery.json','data/catalog.json'];(ROOT/'dist/SHA256SUMS').write_text(''.join(hashlib.sha256((ROOT/'dist'/f).read_bytes()).hexdigest()+'  '+('catalog.json' if f=='data/catalog.json' else f)+'\n' for f in files));print(json.dumps(m))
if __name__=='__main__':refresh()
