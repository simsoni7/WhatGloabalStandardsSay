"""Local HTTP API. No model calls occur unless mode=model is requested."""
import argparse,json
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from .engine import Engine


class Handler(BaseHTTPRequestHandler):
    engine=None
    def log_message(self,*args):pass

    def reply(self,status,body):
        payload=json.dumps(body,ensure_ascii=False).encode()
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(payload)));self.send_header('Cache-Control','no-store')
        self.end_headers();self.wfile.write(payload)

    def do_GET(self):
        if self.path=='/health':self.reply(200,self.engine.health())
        else:self.reply(404,{'error':'not_found'})

    def do_POST(self):
        routes={'/v1/lookup':'lookup','/v1/translate':'translate','/v1/check':'check','/v1/concepts':'concepts'}
        if self.path not in routes:return self.reply(404,{'error':'not_found'})
        if self.headers.get('Transfer-Encoding'):return self.reply(400,{'error':'transfer_encoding_not_supported'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=65536:return self.reply(413,{'error':'body_size_limit'})
            request=json.loads(self.rfile.read(length))
            if not isinstance(request,dict):raise ValueError('JSON object required')
            request['operation']=routes[self.path]
            result=self.engine.process(request)
            self.reply(503 if result['status']=='model_unavailable' else 200,result)
        except (ValueError,UnicodeDecodeError,json.JSONDecodeError) as exc:self.reply(400,{'error':'invalid_request','message':str(exc)})
        except Exception:self.reply(500,{'error':'internal_error'})


def serve(host='127.0.0.1',port=8765,engine=None):
    handler=type('AppHandler',(Handler,),{'engine':engine or Engine()})
    return ThreadingHTTPServer((host,port),handler)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765)
    args=p.parse_args()
    if args.host not in ['127.0.0.1','localhost']:p.error('Bind to loopback; use an authenticated deployment gateway for remote access')
    server=serve(args.host,args.port)
    print(json.dumps({'status':'started','port':server.server_port,'model':server.RequestHandlerClass.engine.health()['model']}),flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
