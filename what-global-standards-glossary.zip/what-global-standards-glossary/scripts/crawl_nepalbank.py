"""Bounded bilingual financial-page crawl; candidates retain source provenance."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import tempfile
import time
from urllib.parse import urlsplit
from urllib.robotparser import RobotFileParser

from bs4 import BeautifulSoup
from collect_public_glossaries import ROOT, NEPAL, MOBILE, fetch, Labels


def financial_path(path):
    return (any(part in path for part in ('/products/', '/services/', '/service-charge/', '/interest-rate/'))
            or (path.startswith('/institutional/') and 'loan' in path)
            or path in ('/nbl-remit', '/remittance-services', '/forex', '/personal/forex')) and '.' not in path.rsplit('/', 1)[-1]


def text(element):
    return ' '.join(element.get_text(' ', strip=True).split())


def useful_nepali(value):
    return any('\u0900' <= c <= '\u097f' for c in value)


def logical_lines(main):
    """Normalize p/br/li layout differences without inventing text translations."""
    if main is None:
        return []
    soup = BeautifulSoup(str(main), 'html.parser')
    for node in soup.select('script,style,img,.applyonline,.nav-tabs'):
        node.decompose()
    marker = '\u241e'
    for node in soup.select('br'):
        # Some pages contain malformed nested <br> tags. Preserve their children.
        node.insert_before(marker)
        node.unwrap()
    for node in soup.select('p,li,h2,h3,h4,tr'):
        node.insert_before(marker)
        node.insert_after(marker)
    flat = ' '.join(soup.stripped_strings)
    return [line for part in flat.split(marker)
            if (line := ' '.join(part.strip().lstrip('•').split()))]


def extract(en_html, ne_html):
    en, ne = BeautifulSoup(en_html, 'html.parser'), BeautifulSoup(ne_html, 'html.parser')
    if any((s.select_one('#languageLink option[selected]') is None or
            s.select_one('#languageLink option[selected]').get('value') != lang)
           for s, lang in [(en, 'en'), (ne, 'np')]):
        raise ValueError('Language selection mismatch')
    records, skipped = [], []
    # Navigation labels are paired by exact link targets, not screen order.
    labels = []
    for html in [en_html, ne_html]:
        p = Labels(); p.feed(html); labels.append(p.links)
    for path in sorted(labels[0].keys() & labels[1].keys()):
        if not financial_path(path):
            continue
        if len(labels[0][path]) == len(labels[1][path]) == 1:
            a, b = next(iter(labels[0][path])), next(iter(labels[1][path]))
            if useful_nepali(b):
                records.append(dict(english=a, nepali=b, kind='term', method='same_link_target_unique_labels', locator=path))
    for selector, kind in [('section.inner-content h1', 'term'),
                           ('section.inner-content .col-lg-8 button[data-bs-target]', 'heading'),
                           ('section.inner-content .col-lg-8 h2', 'heading'),
                           ('section.inner-content .col-lg-8 h3', 'heading'),
                           ('section.inner-content .col-lg-8 th', 'table_header')]:
        left, right = en.select(selector), ne.select(selector)
        if len(left) != len(right):
            skipped.append({'selector': selector, 'reason': 'count_mismatch', 'en': len(left), 'ne': len(right)})
            continue
        for i, (a, b) in enumerate(zip(left, right)):
            a, b = text(a), text(b)
            if a and b and useful_nepali(b):
                records.append(dict(english=a, nepali=b, kind=kind,
                                    method='same_page_selector_ordinal_candidate', locator=f'{selector}[{i}]'))
    # Sentence/table alignment is explicitly tentative and never counted as terminology.
    for selector in ['section.inner-content .col-lg-8 p', 'section.inner-content .col-lg-8 .tab-pane li',
                     'section.inner-content .col-lg-8 > ol > li',
                     'section.inner-content .col-lg-8 tbody tr']:
        left = [text(e) for e in en.select(selector) if text(e)]
        right = [text(e) for e in ne.select(selector) if text(e)]
        if len(left) != len(right):
            skipped.append({'selector': selector, 'reason': 'count_mismatch', 'en': len(left), 'ne': len(right)})
            continue
        for i, (a, b) in enumerate(zip(left, right)):
            if useful_nepali(b) and a != b:
                records.append(dict(english=a, nepali=b, kind='parallel_passage_candidate',
                                    method='same_page_selector_ordinal_candidate', locator=f'{selector}[{i}]'))
    left = logical_lines(en.select_one('section.inner-content .col-lg-8'))
    right = logical_lines(ne.select_one('section.inner-content .col-lg-8'))
    if len(left) == len(right) and len(left) > 2:
        for i,(a,b) in enumerate(zip(left,right)):
            if useful_nepali(b) and a != b:
                short = len(a.split()) <= 8 and len(a) <= 120 and not any(c.isdigit() for c in a)
                records.append(dict(english=a,nepali=b,
                                    kind='short_expression_candidate' if short else 'parallel_passage_candidate',
                                    method='normalized_p_br_li_ordinal_candidate',locator=f'logical_content_line[{i}]'))
    elif left and right:
        skipped.append({'selector':'normalized_content_lines','reason':'count_mismatch','en':len(left),'ne':len(right)})
    discovered = {p for p in labels[0] if financial_path(p)}
    return records, skipped, discovered


def crawl(max_pages=100, workers=3, seed_run=None):
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    candidate = ROOT / 'datasets/nepalbank/candidate'
    run = candidate / 'crawls' / stamp
    run.mkdir(parents=True)
    fetch(NEPAL + '/robots.txt', run / 'robots.txt')
    robots = RobotFileParser(); robots.parse((run / 'robots.txt').read_text().splitlines())
    page_records, failures, raw_records, skips = [], [], [], []
    cached, cached_failures = {}, {}
    if seed_run:
        seed_run = seed_run.resolve()
        if not seed_run.is_relative_to(candidate.resolve() / 'crawls'):
            raise ValueError('Seed must be a previous Nepal Bank crawl.')
        seed = json.loads((seed_run / 'progress.json').read_text())
        cached = {p['path']: p for p in seed['pages']}
        cached_failures = {p['path']: p for p in seed['failures']}
    with tempfile.TemporaryDirectory() as temp:
        temp = Path(temp)
        base_cookies = {}
        for lang, locale in [('en', 'en'), ('ne', 'np')]:
            cookie = temp / (lang + '.cookies')
            if not robots.can_fetch('GlossaryResearchCollector', NEPAL + '/locale/' + locale):
                raise RuntimeError('Locale switch prohibited by robots')
            fetch(NEPAL + '/locale/' + locale, temp / (lang + '.switch'), cookie)
            base_cookies[lang] = cookie

        def page_pair(path):
            url = NEPAL + path
            if not robots.can_fetch('GlossaryResearchCollector', url):
                return {'path': path, 'error': 'robots_disallowed'}
            page_id = hashlib.sha256(path.encode()).hexdigest()[:16]
            folder = run / 'pages' / page_id; folder.mkdir(parents=True)
            sources = {}
            try:
                if path in cached:
                    for language in ['en', 'ne']:
                        source = cached[path]['sources'][language]
                        old_file = seed_run / source['file']
                        if hashlib.sha256(old_file.read_bytes()).hexdigest() != source['sha256']:
                            raise ValueError('Cached source hash mismatch')
                        target = folder / (language + '.html'); shutil.copy2(old_file, target)
                        sources[language] = {**source, 'file':str(target.relative_to(run)), 'reused_from_run':str(seed_run.relative_to(ROOT))}
                elif path in cached_failures:
                    return {**cached_failures[path], 'reused_failure': True}
                else:
                    with tempfile.TemporaryDirectory(dir=temp) as local:
                        for language, locale in [('en', 'en'), ('ne', 'np')]:
                            cookie = Path(local) / (language + '.cookies')
                            shutil.copy2(base_cookies[language], cookie)
                            target = folder / (language + '.html')
                            sources[language] = fetch(url, target, cookie)
                            sources[language].update(file=str(target.relative_to(run)), site_locale=locale,
                                                     locale_endpoint=NEPAL + '/locale/' + locale)
                            time.sleep(.2)
                rows, omitted, links = extract((folder / 'en.html').read_text(), (folder / 'ne.html').read_text())
                return {'path': path, 'page_id': page_id, 'sources': sources, 'records': rows, 'skipped': omitted, 'links': links}
            except (RuntimeError, ValueError) as exc:
                return {'path': path, 'error': str(exc)}

        pending, visited = {'/personal/services/mobile-banking'}, set()
        with ThreadPoolExecutor(max_workers=workers) as pool:
            while pending and len(visited) < max_pages:
                batch = sorted(pending, key=lambda p: (0 if '/products/' in p or 'loan' in p else 1, p))[:max_pages - len(visited)]
                pending.difference_update(batch); visited.update(batch)
                futures = {pool.submit(page_pair, path): path for path in batch}
                for future in as_completed(futures):
                    result = future.result()
                    if 'error' in result:
                        failures.append(result)
                        print('Failed:', result['path'], flush=True)
                        continue
                    page_records.append({k: result[k] for k in ['path', 'page_id', 'sources']})
                    for record in result['records']:
                        record.update(page_id=result['page_id'], page_path=result['path'], review_status='unreviewed')
                        raw_records.append(record)
                    skips.extend([dict(page_path=result['path'], **s) for s in result['skipped']])
                    pending.update(result['links'] - visited)
                    print(f"Captured {len(page_records)} bilingual pages: {result['path']}", flush=True)
                # Persist progress so a failure does not erase completed captures.
                (run / 'progress.json').write_text(json.dumps({'pages': page_records, 'failures': failures}, ensure_ascii=False, indent=2))

    unique = {}
    for record in raw_records:
        key = (record['english'], record['nepali'], record['kind'])
        if key not in unique:
            unique[key] = {k: record[k] for k in ['english', 'nepali', 'kind', 'review_status']}
            unique[key]['occurrences'] = []
        unique[key]['occurrences'].append({k: record[k] for k in ['page_id', 'page_path', 'locator', 'method']})
    records = list(unique.values())
    by_page = {p['page_id']: p for p in page_records}
    with sqlite3.connect(run / 'candidate.sqlite') as db:
        db.executescript('''CREATE TABLE pages(id TEXT PRIMARY KEY,path TEXT,sources_json TEXT);
        CREATE TABLE candidates(id INTEGER PRIMARY KEY,english TEXT,nepali TEXT,kind TEXT,review_status TEXT);
        CREATE TABLE occurrences(candidate_id INTEGER REFERENCES candidates(id),page_id TEXT REFERENCES pages(id),locator TEXT,method TEXT);
        PRAGMA foreign_keys=ON;''')
        db.executemany('INSERT INTO pages VALUES (?,?,?)', [(p['page_id'],p['path'],json.dumps(p['sources'])) for p in page_records])
        for i, row in enumerate(records, 1):
            db.execute('INSERT INTO candidates VALUES (?,?,?,?,?)',(i,row['english'],row['nepali'],row['kind'],row['review_status']))
            db.executemany('INSERT INTO occurrences VALUES (?,?,?,?)',[(i,o['page_id'],o['locator'],o['method']) for o in row['occurrences']])
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
    for name, subset in [('term_candidates.csv',[r for r in records if r['kind'] != 'parallel_passage_candidate']),
                         ('parallel_passages.csv',[r for r in records if r['kind'] == 'parallel_passage_candidate'])]:
        with (run / name).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=['english','nepali','kind','review_status','occurrence_count']);writer.writeheader()
            writer.writerows({**{k:r[k] for k in ['english','nepali','kind','review_status']},'occurrence_count':len(r['occurrences'])} for r in subset)
    with (run / 'evidence.jsonl').open('w') as f:
        for i,row in enumerate(records,1):
            source=[{'page':by_page[o['page_id']],'locator':o['locator'],'alignment_method':o['method']} for o in row['occurrences']]
            f.write(json.dumps({'evidence_id':f'nepalbank:candidate:{stamp}:{i}','dataset_id':'nepalbank','dataset_version':'candidate-'+stamp,
                               'english':row['english'],'source_language':'en','target_language':'ne','translation':row['nepali'],
                               'kind':row['kind'],'review_status':'unreviewed','availability':'present','publisher':'Nepal Bank Limited',
                               'jurisdiction':'NP','source':{'type':'parallel_bank_pages','occurrences':source}},ensure_ascii=False)+'\n')
    counts={kind:sum(r['kind']==kind for r in records) for kind in sorted({r['kind'] for r in records})}
    report={'bilingual_page_count':len(page_records),'html_document_count':len(page_records)*2,'candidate_counts':counts,
            'unique_candidate_count':len(records),'failed_pages':failures,'unaligned_sections':skips,
            'pending_pages_at_limit':sorted(pending),'max_pages':max_pages,'review_status':'unreviewed',
            'note':'Ordinal alignment is tentative; equal section length does not verify meaning.',
            'files_sha256':{str(p.relative_to(run)):hashlib.sha256(p.read_bytes()).hexdigest() for p in run.rglob('*') if p.is_file()}}
    (run / 'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    manifest_path=candidate/'manifest.json';manifest=json.loads(manifest_path.read_text())
    manifest.update(last_crawl=str(run.relative_to(ROOT)),bilingual_page_count=len(page_records),
                    pair_count=sum(r['kind']!='parallel_passage_candidate' for r in records),
                    parallel_passage_count=counts.get('parallel_passage_candidate',0),inspection_status='crawled_candidate',
                    last_observation='Verified HTTPS bilingual pages captured; candidate alignments remain unreviewed.')
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'run':str(run),'bilingual_pages':len(page_records),'counts':counts,'failures':len(failures)},ensure_ascii=False),flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-pages',type=int,default=100)
    parser.add_argument('--workers',type=int,choices=[1,2,3],default=3)
    parser.add_argument('--seed-run',type=Path)
    args=parser.parse_args()
    if not 1<=args.max_pages<=200:parser.error('--max-pages must be 1..200')
    crawl(args.max_pages,args.workers,args.seed_run)
