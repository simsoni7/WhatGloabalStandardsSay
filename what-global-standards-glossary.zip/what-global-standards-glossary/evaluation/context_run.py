"""Run accepted AI-authored structural diagnostics; not translation accuracy."""
import json
from pathlib import Path
from glossary_app.enrichment import accepted_records
from glossary_app.engine import Engine
from glossary_app.model import ModelUnavailable
ROOT=Path(__file__).resolve().parents[1]
def unavailable(*args):raise ModelUnavailable('Diagnostic fixture: no live model')
def run():
 engine=Engine(model=unavailable);results=[]
 for case in accepted_records(ROOT,'context_cases'):
  out=engine.process(case['request']);expected=case['expected_structural_behavior'];failures=[]
  if expected.get('approved_translation_must_be_null') and out['approved_translation'] is not None:failures.append('approval')
  if expected.get('source_candidates_must_not_be_approved') and any(c['approved'] for c in out['source_candidates']):failures.append('source_approval')
  if expected.get('review_required') and not out['review_required']:failures.append('review_required')
  if expected.get('quarantine_excluded_from_model'):
   quarantined={e['evidence_id'] for e in out['evidence'] if not e['generation_eligible']}
   if not quarantined.issubset(set(out.get('model_excluded_evidence_ids',[]))):failures.append('quarantine')
  required=case.get('required_context_capability',{}).get('semantic_scope_warning_or_selection',False)
  results.append({'case_id':case['case_id'],'passed':not failures,'failures':failures,'status':out['status'],
                  'freeform_semantic_context_check':'not_implemented' if required else 'not_required'})
 return {'scope':'ai_authored_structural_diagnostic_not_translation_accuracy','passed':sum(c['passed'] for c in results),'total':len(results),'failed':sum(not c['passed'] for c in results),'unimplemented_freeform_semantic_cases':sum(c['freeform_semantic_context_check']=='not_implemented' for c in results),'live_model_evaluation':False,'cases':results}
if __name__=='__main__':
 result=run();(ROOT/'evaluation/context_results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cases'}));raise SystemExit(bool(result['failed']))
