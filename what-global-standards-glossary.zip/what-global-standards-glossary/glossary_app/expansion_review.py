"""Apply immutable independent source-review decisions without semantic approval."""
import hashlib,json

def reviewed_inputs(root):
 result=[]
 for batch in ('batch5_review','batch7_review','batch8_review'):
  path=root/f'datasets/source_collection/{batch}/decisions.json'
  if not path.exists():continue
  doc=json.loads(path.read_text())
  if doc.get('human_review') or doc.get('semantic_approval'):raise ValueError('Source intake is not expert translation approval')
  for item in doc['accepted_inputs']:
   file=(root/item['path']).resolve()
   if not file.is_relative_to(root.resolve()) or hashlib.sha256(file.read_bytes()).hexdigest()!=item['sha256']:
    raise ValueError('Source intake evidence changed; independent re-review required')
   rows=[json.loads(line) for line in file.read_text().splitlines() if line.strip()]
   ids={r['evidence_id'] for r in rows};accepted=set(item['accepted_ids'])
   if len(ids)!=len(rows) or not accepted<=ids or len(accepted)!=len(item['accepted_ids']) or len(accepted)!=item['record_count']:
    raise ValueError('Source intake acceptance ID mismatch')
   excluded={x if isinstance(x,str) else x['evidence_id'] for x in item.get('excluded_ids',[])}
   if accepted&excluded:raise ValueError('Accepted and excluded evidence overlap')
   result.append((item,[r for r in rows if r['evidence_id'] in accepted]))
 return result

def apply_expansion_review(rows,report,root):
 observed={r['evidence_id']:r for r,_,_ in rows};named=set();scope_block=set()
 for item,raw_rows in reviewed_inputs(root):
  blocks=set(item.get('generation_block_ids',item.get('quarantined_ids',[])))
  for raw in raw_rows:
   r=observed.get(raw['evidence_id'])
   if r is None:continue # Community/copyleft datasets deliberately remain separate.
   en=raw.get('source_english',raw.get('english'));target=raw.get('source_target',raw.get('translation'))
   if raw.get('source',{}).get('normalization')=='outer_whitespace_trim_only':en=en.strip();target=target.strip()
   if r['source_english']!=en or r['source_target']!=target or r['dataset_id']!=raw['dataset_id']:
    raise ValueError('Imported observation differs from independently reviewed source: '+r['evidence_id']+' '+repr((r['source_english'],en,r['source_target'],target)))
   r['source_intake_review']={'type':'independent_ai_source_review','human_review':False,'semantic_approval':False,'source_file_sha256':item['sha256']}
   if r['dataset_id']=='apache_ofbiz_accounting' or item.get('generation_policy_block_all'):
    r['generation_eligible']=False;r['generation_policy_reason']='software_context_not_approved_for_unqualified_generation';scope_block.add(r['evidence_id'])
   if r['evidence_id'] in blocks:
    r['generation_eligible']=False;r['equivalence_status']='needs_review';named.add(r['evidence_id'])
    reasons=[x['reason'] for x in item.get('semantic_cautions',[]) if r['evidence_id'] in x['evidence_ids']]
    r['semantic_review']={'status':'ai_source_scope_caution','human_review':False,'classification':'source_meaning_scope_suspected','rationale':' '.join(reasons) or 'Source receipt/category wording differs from the financial field scope; retain and block.'}
    r['quality_flags'].append({'issue_type':'source_meaning_scope_quarantine','priority':'high','source':'independent_source_review','human_review':False})
 report['expansion_source_review']={'new_core_records_reviewed':sum('source_intake_review' in r for r in observed.values()),'named_semantic_quarantines':len(named),'software_context_generation_policy_blocks':len(scope_block),'expert_translation_approvals':0}
 report['generation_ineligible_records']=sum(not r.get('generation_eligible') and r['reference_usable'] for r in observed.values())
 return rows,report
