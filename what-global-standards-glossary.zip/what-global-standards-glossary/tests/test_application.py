from pathlib import Path
import io,json,os,sys,threading,unittest
from unittest.mock import patch
from urllib.request import Request,urlopen,build_opener,ProxyHandler
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from glossary_app.engine import Engine
from glossary_app.model import infer,validate_output
from glossary_app.server import serve
from scripts.resolve_quality import numeric_values


class ApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.engine=Engine()

    def request(self,**fields):
        return self.engine.process(dict(operation='translate',english_term='Credit Card',target_language='mn',**fields))

    def test_real_mongolian_term_translation(self):
        result=self.request(jurisdiction='MN',context='Bank app label')
        self.assertEqual(result['translated_text'],'Зээлийн карт')
        self.assertEqual(result['translation_kind'],'source_term_quote')
        self.assertIsNone(result['generated_expression'])
        self.assertEqual(result['evidence'][0]['dataset_state'],'candidate')

    def test_real_nepali_comparison(self):
        result=self.engine.process(dict(operation='check',english_term='Saving Account',target_language='ne',expression='बचत खाता',jurisdiction='NP'))
        self.assertEqual(result['source_comparison'],'exact_source_match')
        self.assertEqual(result['contextual_verdict'],'not_assessed')
        self.assertTrue(result['review_required'])

    def test_corrected_benefit_does_not_quote_wrong_card(self):
        result=self.engine.process(dict(operation='translate',english_term='25% discount on locker facility for first year',target_language='ne'))
        self.assertEqual(result['translated_text'],'पहिलो बर्ष लकर सेवाको वार्षिक शुल्कमा २५% छुट सुविधा।')
        self.assertNotIn('भिसा डेबिट कार्ड',[e['translation'] for e in result['evidence']])
        self.assertFalse(result['evidence'][0]['human_review'])

    def test_ui_contamination_not_used(self):
        result=self.engine.process(dict(operation='translate',english_term='Download Apply Now',target_language='ne'))
        self.assertFalse(any(e['english']=='Download Apply Now' for e in result['evidence']))
        self.assertIsNone(result['translated_text'])

    def test_ambiguous_senses_not_chosen_automatically(self):
        result=self.engine.process(dict(operation='translate',english_term='Capital',target_language='mn'))
        self.assertEqual(result['status'],'sense_selection_required')
        self.assertIsNone(result['translated_text'])
        selected=self.engine.process(dict(operation='translate',english_term='Capital',target_language='mn',source_concept_id=result['evidence'][0]['source_concept_id']))
        self.assertLess(len(selected['evidence']),len(result['evidence']))

    def test_alias_proposal_does_not_correct_original(self):
        result=self.engine.process(dict(operation='translate',english_term='Tier 2 capital',target_language='mn'))
        self.assertEqual(result['status'],'quality_review_required')
        self.assertEqual(result['evidence'][0]['english'],'Tier 2 сapital')
        self.assertIsNone(result['translated_text'])

    def test_jurisdiction_mismatch_not_approved(self):
        result=self.request(jurisdiction='US')
        self.assertEqual(result['status'],'jurisdiction_needs_review')
        self.assertIsNone(result['translated_text'])

    def test_missing_korean_source_not_invented(self):
        result=self.engine.process(dict(operation='translate',english_term='Ghost mortgage, silent second mortgage',target_language='ko'))
        self.assertEqual(result['status'],'missing_in_source')
        self.assertIsNone(result['translated_text'])

    def test_unsupported_language_not_invented(self):
        result=self.engine.process(dict(operation='translate',english_term='Credit Card',target_language='ja'))
        self.assertEqual(result['status'],'no_target_language_evidence')
        self.assertIsNone(result['translated_text'])

    def test_no_model_is_explicit_failure(self):
        with patch.dict(os.environ,{},clear=True):result=self.request(mode='model')
        self.assertEqual(result['status'],'model_unavailable')
        self.assertIsNone(result['generated_expression'])

    def test_model_cannot_invent_citations(self):
        with self.assertRaises(ValueError):validate_output({'assessment':'supported','proposed_translation':'x','rationale':'x','citations':['invented'],'questions':[]},[])

    def test_model_cannot_remove_number_conflict(self):
        def fake(request,evidence):
            return {'assessment':'supported','proposed_translation':'न्यूनतम मौज्दात १०००','rationale':'test fixture',
                    'citations':[evidence[0]['evidence_id']],'questions':[]}
        result=Engine(model=fake).process(dict(operation='translate',english_term='Saving Account',target_language='ne',mode='model',source_text='Minimum balance 500'))
        self.assertTrue(result['model_numeric_conflict'])
        self.assertEqual(result['contextual_verdict'],'needs_review')

    def test_numeric_grouping_and_word_numbers(self):
        self.assertEqual(numeric_values('150,000'),numeric_values('१,५०,०००','ne'))
        self.assertEqual(numeric_values('100000'),numeric_values('एक लाख','ne'))
        self.assertEqual(numeric_values('2 ways'),numeric_values('दुई तरिकामा','ne'))

    def test_remote_model_requires_tls(self):
        with patch.dict(os.environ,{'MODEL_BASE_URL':'http://remote.example/v1','MODEL_NAME':'test'}):
            with self.assertRaises(ValueError):infer({},[])

    def test_model_transport_contract_is_simulated_only(self):
        evidence=[{'evidence_id':'source-1'}]
        def fake(request,timeout):
            data=json.loads(request.data);self.assertEqual(data['model'],'fixture-model')
            self.assertEqual(data['messages'][0]['role'],'system')
            output={'assessment':'needs_review','proposed_translation':'fixture text','rationale':'fixture only','citations':['source-1'],'questions':[]}
            return io.BytesIO(json.dumps({'choices':[{'message':{'content':json.dumps(output)}}]}).encode())
        with patch.dict(os.environ,{'MODEL_BASE_URL':'http://127.0.0.1:9999/v1','MODEL_NAME':'fixture-model'}):
            result=infer({'context':'test'},evidence,opener=fake)
        self.assertEqual(result['proposed_translation'],'fixture text')


class HttpApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=serve(port=0);cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.base='http://127.0.0.1:'+str(cls.server.server_port)

    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join()

    def post(self,path,body):
        req=Request(self.base+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'},method='POST')
        try:
            with build_opener(ProxyHandler({})).open(req) as response:return response.status,json.load(response)
        except HTTPError as e:return e.code,json.load(e)

    def test_real_http_translation_and_check(self):
        status,result=self.post('/v1/translate',dict(english_term='Credit Card',target_language='mn',jurisdiction='MN'))
        self.assertEqual(status,200);self.assertEqual(result['translated_text'],'Зээлийн карт')
        status,result=self.post('/v1/check',dict(english_term='Credit Card',target_language='mn',expression='Зээлийн карт'))
        self.assertEqual(status,200);self.assertEqual(result['source_comparison'],'exact_source_match')

    def test_invalid_request_rejected(self):
        status,_=self.post('/v1/check',dict(english_term='Credit Card',target_language='mn'))
        self.assertEqual(status,400)

    def test_model_unavailable_uses_service_failure_status(self):
        with patch.dict(os.environ,{'MODEL_BASE_URL':'','MODEL_NAME':''}):
            status,result=self.post('/v1/translate',dict(english_term='Credit Card',target_language='mn',mode='model'))
        self.assertEqual(status,503);self.assertEqual(result['model_status'],'unavailable')


if __name__=='__main__':unittest.main()
