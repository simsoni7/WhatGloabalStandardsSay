import argparse,json
from .engine import Engine


if __name__=='__main__':
    p=argparse.ArgumentParser(description='Source-grounded glossary requests; JSON in, JSON out.')
    p.add_argument('--request',required=True,help='JSON request object')
    args=p.parse_args()
    try:print(json.dumps(Engine().process(json.loads(args.request)),ensure_ascii=False,indent=2))
    except ValueError as exc:p.exit(2,str(exc)+'\n')
